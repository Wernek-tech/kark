#!/bin/bash

echo "🔧 KARK Website Simple VPS Build Fix"
echo "===================================="

cd /var/www/kark || exit 1

# 1. Stop PM2
echo "1. Stopping PM2..."
pm2 stop all 2>/dev/null || true
pm2 delete all 2>/dev/null || true

# 2. Create a simple build script for package.json
echo "2. Updating build script..."
# Backup original package.json
cp package.json package.json.backup

# Update build script to use tsx for compilation
npm pkg set scripts.build:client="vite build"
npm pkg set scripts.build:server="tsx --experimental-specifier-resolution=node server/index.ts --compile --outdir=dist"
npm pkg set scripts.build="npm run build:client && npm run build:server"

# 3. Install tsx if not present
echo "3. Installing tsx..."
npm install --save-dev tsx

# 4. Build client
echo "4. Building client..."
npm run build:client

# 5. Create a production wrapper script
echo "5. Creating production wrapper..."
cat > start-production.js << 'EOF'
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Set environment variables
process.env.NODE_ENV = 'production';
process.env.PORT = process.env.PORT || '5000';
process.env.HOST = process.env.HOST || '0.0.0.0';

// Start the server using tsx
const server = spawn('node', [
  '--experimental-specifier-resolution=node',
  join(__dirname, 'server/index.ts')
], {
  stdio: 'inherit',
  env: process.env
});

server.on('error', (err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

server.on('exit', (code) => {
  console.log(`Server exited with code ${code}`);
  process.exit(code);
});

// Handle signals
process.on('SIGTERM', () => {
  server.kill('SIGTERM');
});

process.on('SIGINT', () => {
  server.kill('SIGINT');
});
EOF

# 6. Create PM2 ecosystem config
echo "6. Creating PM2 config..."
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: './start-production.js',
    cwd: '/var/www/kark',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    interpreter: 'node',
    interpreter_args: '--experimental-specifier-resolution=node',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      HOST: '0.0.0.0',
      DATABASE_URL: process.env.DATABASE_URL,
      SESSION_SECRET: process.env.SESSION_SECRET || 'kark-session-secret-2025',
      FRONTEND_URL: 'https://kibrisaramakurtarma.org',
      CORS_ORIGIN: 'https://kibrisaramakurtarma.org'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
};
EOF

# 7. Create logs directory
echo "7. Creating logs directory..."
mkdir -p logs

# 8. Add health check to server/index.ts if not present
echo "8. Adding health check..."
if ! grep -q "/api/health" server/index.ts; then
  # Find the line with "app.use("/api", routes)"
  LINE_NUM=$(grep -n 'app.use("/api", routes' server/index.ts | cut -d: -f1)
  if [ ! -z "$LINE_NUM" ]; then
    # Insert health check before that line
    sed -i "${LINE_NUM}i\\
  // Health check endpoint\\
  app.get('/api/health', (req, res) => {\\
    res.json({ \\
      status: 'ok', \\
      timestamp: new Date().toISOString(),\\
      environment: process.env.NODE_ENV || 'production'\\
    });\\
  });\\
" server/index.ts
  fi
fi

# 9. Start with PM2
echo "9. Starting application..."
pm2 start ecosystem.config.cjs

# 10. Save PM2 config
pm2 save

# 11. Wait and test
echo "10. Waiting for startup..."
sleep 10

# 12. Check PM2 logs for any errors
echo "11. Recent logs:"
pm2 logs --lines 20 --nostream

# 13. Test endpoints
echo -e "\n12. Testing endpoints..."
echo "Health check:"
curl -s http://localhost:5000/api/health || echo "Failed - server may still be starting"

echo -e "\nVisitor count:"
curl -s http://localhost:5000/api/visitor-count | head -c 50 || echo "Failed"

echo -e "\n\nPM2 Status:"
pm2 status

echo -e "\n✅ Simple build fix complete!"
echo "Monitor logs: pm2 logs -f"
echo "If still having issues, check: pm2 logs --err"