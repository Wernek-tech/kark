#!/bin/bash

# PM2 Setup and Configuration Script for KARK Website
echo "🚀 Starting PM2 Configuration for KARK Website..."

# 1. Install PM2 globally (if not already installed)
echo "📦 Installing PM2..."
npm install -g pm2 2>/dev/null || echo "PM2 already installed or using npx"

# 2. Stop current development server
echo "🛑 Stopping current development server..."
pkill -f "npm run dev" 2>/dev/null || echo "No dev server running"

# 3. Create necessary directories
echo "📁 Creating necessary directories..."
mkdir -p data/sessions
mkdir -p logs
chmod 755 data/sessions

# 4. Show current PM2 status
echo "📊 Current PM2 status:"
npx pm2 status

# 5. Start with ecosystem.config.js
echo "🚀 Starting KARK with PM2 using ecosystem.config.js..."
npx pm2 start ecosystem.config.js --env production

# 6. Show PM2 status after start
echo "📊 PM2 status after start:"
npx pm2 status

# 7. Show PM2 logs
echo "📋 PM2 logs (last 10 lines):"
npx pm2 logs --lines 10

# 8. Test if application is responding
echo "🔍 Testing application response..."
sleep 3
curl -s http://localhost:5000/api/visitor-count | grep -q "count" && echo "✅ Application is responding" || echo "❌ Application not responding"

# 9. Save PM2 configuration
echo "💾 Saving PM2 configuration..."
npx pm2 save

# 10. Show PM2 monitoring info
echo "📈 PM2 monitoring info:"
npx pm2 monit --no-daemon || echo "PM2 monit not available in this environment"

echo "✅ PM2 setup completed!"
echo "📝 Available PM2 commands:"
echo "   - npx pm2 status        # Check app status"
echo "   - npx pm2 logs          # View logs"
echo "   - npx pm2 restart kark-website  # Restart app"
echo "   - npx pm2 stop kark-website     # Stop app"
echo "   - npx pm2 delete kark-website   # Delete app from PM2"