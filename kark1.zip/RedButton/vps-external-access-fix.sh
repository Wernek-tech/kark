#!/bin/bash

echo "=== VPS External Access Configuration ==="
echo "Making your KARK site accessible from outside the VPS..."

# 1. Update PM2 to bind to all interfaces (0.0.0.0)
echo "Step 1: Updating PM2 configuration for external access..."
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      HOST: '0.0.0.0',
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-kibris-secret-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    }
  }]
}
EOF

# 2. Update .env file
echo "Step 2: Updating environment configuration..."
cat > .env << 'EOF'
NODE_ENV=production
PORT=5000
HOST=0.0.0.0
DB_TYPE=json
SESSION_SECRET=kark-vps-kibris-secret-2025
TRUST_PROXY=true
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
EOF

# 3. Restart PM2 with new configuration
echo "Step 3: Restarting PM2 with external access..."
pm2 stop kark-website 2>/dev/null || true
pm2 delete kark-website 2>/dev/null || true
pm2 start ecosystem.config.cjs

# 4. Check if firewall is blocking port 5000
echo "Step 4: Checking firewall and port access..."
echo "Checking if port 5000 is open..."
if command -v ufw >/dev/null 2>&1; then
    echo "UFW firewall detected, opening port 5000..."
    ufw allow 5000
    ufw status
elif command -v firewall-cmd >/dev/null 2>&1; then
    echo "Firewalld detected, opening port 5000..."
    firewall-cmd --permanent --add-port=5000/tcp
    firewall-cmd --reload
    firewall-cmd --list-ports
else
    echo "No common firewall detected, checking iptables..."
    iptables -L INPUT | grep -q "dpt:5000" || echo "Port 5000 may be blocked by iptables"
fi

# 5. Test local access
echo "Step 5: Testing local server access..."
sleep 3
if curl -s http://localhost:5000 | grep -q "html"; then
    echo "✓ Local access working"
else
    echo "✗ Local access failed"
fi

# 6. Show network status
echo "Step 6: Network status check..."
echo "Processes listening on port 5000:"
netstat -tlnp | grep :5000 || ss -tlnp | grep :5000
echo ""

# 7. Show PM2 status
echo "Step 7: PM2 status:"
pm2 status

echo ""
echo "=== External Access Configuration Complete ==="
echo ""
echo "Your site should now be accessible at:"
echo "  http://YOUR-VPS-IP:5000"
echo "  http://kibrisaramakurtarma.org:5000 (if DNS points to VPS)"
echo ""
echo "NGINX Proxy Setup (Optional):"
echo "If you want to use port 80 instead of 5000, configure NGINX:"
echo ""
cat << 'NGINX_EOF'
# Add this to your NGINX config (/etc/nginx/sites-available/kibrisaramakurtarma.org):
server {
    listen 80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
NGINX_EOF
echo ""
echo "Then run: systemctl reload nginx"
EOF