import { Express, Request, Response } from 'express';

export function registerSecurityRoutes(app: Express) {
  // Security status endpoint (admin only)
  app.get('/api/security/status', (req: Request, res: Response) => {
    // Check if user is authenticated and is an admin
    if (!req.isAuthenticated() || !req.user || 
        (req.user.role !== 'admin' && req.user.role !== 'major_admin')) {
      return res.status(403).json({ message: 'Unauthorized' });
    }

    // Return security status
    res.json({
      status: 'active',
      features: {
        authentication: {
          enabled: true,
          passwordHashing: 'scrypt',
          sessionManagement: true,
          loginAttemptTracking: true,
          accountLockout: '5 attempts in 15 minutes'
        },
        rateLimiting: {
          enabled: true,
          endpoints: {
            general: '100 requests per 15 minutes',
            authentication: '5 requests per 15 minutes',
            contact: '3 messages per hour',
            uploads: '20 uploads per hour'
          }
        },
        headers: {
          helmet: true,
          contentSecurityPolicy: true,
          xFrameOptions: 'SAMEORIGIN',
          xContentTypeOptions: 'nosniff',
          xssProtection: true,
          referrerPolicy: 'strict-origin-when-cross-origin',
          permissionsPolicy: true
        },
        inputValidation: {
          xssProtection: true,
          noSqlInjectionPrevention: true,
          parameterPollutionPrevention: true,
          maxFieldLength: 10000
        },
        fileUpload: {
          mimeTypeValidation: true,
          maxFileSize: '50MB',
          allowedTypes: ['image/*', 'application/pdf', 'video/*']
        },
        cors: {
          enabled: true,
          credentials: true
        },
        adminSecurity: {
          roleBasedAccess: true,
          actionLogging: true,
          securityAlerts: true
        }
      },
      environment: process.env.NODE_ENV || 'development',
      timestamp: new Date().toISOString()
    });
  });

  // Security test endpoint (for testing rate limiting)
  app.get('/api/security/test-rate-limit', (req: Request, res: Response) => {
    res.json({
      message: 'Rate limit test successful',
      ip: req.ip,
      timestamp: new Date().toISOString()
    });
  });
}