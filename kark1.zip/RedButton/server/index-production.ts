import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { adminActionLogger } from "./admin-logger";
import { applySecurityMiddleware } from "./middleware/security";
import { config } from "./config";
import cors from "cors";
import path from "path";

const app = express();

// Simple log function for production (no Vite dependency)
function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}

// CORS configuration for VPS deployment
const corsOptions = {
  origin: function (origin: string | undefined, callback: (err: Error | null, allow?: boolean) => void) {
    // Allow requests with no origin (like mobile apps or Postman)
    if (!origin) return callback(null, true);
    
    // Check if origin is allowed
    if (config.api.corsOrigins.includes(origin) || 
        config.api.corsOrigins.includes('*') ||
        origin.includes('kibrisaramakurtarma.org') ||
        origin.includes('localhost')) {
      return callback(null, true);
    }
    
    // Log rejected origins for debugging
    log(`CORS rejected origin: ${origin}`, "cors");
    callback(new Error('Not allowed by CORS'));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['Content-Type', 'Authorization']
};

app.use(cors(corsOptions));

// Apply security middleware
applySecurityMiddleware(app);

// Trust proxy for VPS deployment
app.set('trust proxy', config.server.trustProxy);

// Serve static files in production (no Vite middleware)
function serveStatic(app: express.Express) {
  const staticPath = path.join(process.cwd(), 'dist/public');
  
  // Serve static files with proper cache headers
  app.use(express.static(staticPath, {
    maxAge: process.env.NODE_ENV === 'production' ? '1d' : 0,
    etag: true,
    lastModified: true
  }));

  // Handle SPA routing - serve index.html for all non-API routes
  app.get('*', (req: Request, res: Response, next: NextFunction) => {
    // Skip if it's an API route
    if (req.path.startsWith('/api/')) {
      return next();
    }
    
    // Serve index.html for all other routes
    const indexPath = path.join(staticPath, 'index.html');
    res.sendFile(indexPath, (err) => {
      if (err) {
        log(`Error serving index.html: ${err.message}`, "static");
        res.status(500).send('Server Error');
      }
    });
  });
}

// Configure middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Add admin action logger
app.use(adminActionLogger);

// Register API routes
registerRoutes(app);

// Serve static files
serveStatic(app);

const PORT = config.server.port;

app.listen(PORT, "0.0.0.0", () => {
  log(`serving on 0.0.0.0:${PORT}`);
});

export { log };