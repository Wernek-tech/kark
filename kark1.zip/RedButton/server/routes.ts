import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { registerAdminRoutes } from "./admin-routes";
import { registerSecurityRoutes } from "./routes/security";
import { logAdminAction } from "./admin-logger";
import { users } from "@shared/schema";
// Removed MySQL imports - using JSON storage only

// Check if we should use MySQL or JSON storage
const useMySQL = process.env.DB_TYPE === 'mysql';
import { 
  insertContactMessageSchema, 
  insertEventSchema, 
  insertMediaItemSchema, 
  insertAlbumSchema, 
  insertTeamMemberSchema, 
  insertSettingSchema,
  insertDonationMethodSchema,
  insertDonationCampaignSchema,
  insertHeroSliderSchema,
  insertArchiveItemSchema,
  eventCategoryEnum 
} from "@shared/schema";
// Removed drizzle-orm imports - using JSON storage only

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint
  app.get("/api/health", (req: Request, res: Response) => {
    res.json({ 
      status: "ok", 
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || "development"
    });
  });

  // Setup authentication routes
  setupAuth(app);
  
  // Register admin management routes
  registerAdminRoutes(app);
  
  // Register security routes
  registerSecurityRoutes(app);
  
  // Import and register activities routes (unified for both MySQL and JSON storage)
  const activitiesRoutes = (await import('./routes/activities-unified')).default;
  app.use('/api/activities', activitiesRoutes);
  
  // Public API routes for operations, news, and reports
  app.get("/api/operations", async (req, res) => {
    try {
      const operations = await storage.getAllOperations();
      res.json(operations);
    } catch (error) {
      console.error("Error fetching operations:", error);
      res.status(500).json({ message: "Error fetching operations" });
    }
  });
  
  app.get("/api/operations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid operation ID" });
      }
      
      const operation = await storage.getOperation(id);
      if (!operation) {
        return res.status(404).json({ message: "Operation not found" });
      }
      
      res.json(operation);
    } catch (error) {
      console.error("Error fetching operation:", error);
      res.status(500).json({ message: "Error fetching operation" });
    }
  });
  
  app.get("/api/news", async (req, res) => {
    try {
      const newsItems = await storage.getPublishedNews();
      res.json(newsItems);
    } catch (error) {
      console.error("Error fetching news:", error);
      res.status(500).json({ message: "Error fetching news" });
    }
  });
  
  app.get("/api/reports", async (req, res) => {
    try {
      const reports = await storage.getAllReports();
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ message: "Error fetching reports" });
    }
  });
  
  // Ziyaretçi sayısı takibi
  let visitorCount = 0; // Sıfırdan başla
  const visitorIPs = new Set<string>();
  
  // Ana sayfa ziyaretini kaydet
  app.post("/api/visitor-count/increment", async (req, res) => {
    try {
      const clientIP = req.ip || req.connection.remoteAddress || req.socket.remoteAddress || 'unknown';
      
      // Eğer bu IP adresi daha önce kaydedilmemişse sayacı artır
      if (!visitorIPs.has(clientIP)) {
        visitorIPs.add(clientIP);
        visitorCount++;
      }
      
      res.json({ success: true, count: visitorCount });
    } catch (error) {
      console.error("Error incrementing visitor count:", error);
      res.status(500).json({ message: "Error incrementing visitor count" });
    }
  });
  
  // Ziyaretçi sayısını getir
  app.get("/api/visitor-count", async (req, res) => {
    try {
      res.json({ count: visitorCount });
    } catch (error) {
      console.error("Error getting visitor count:", error);
      res.status(500).json({ message: "Error getting visitor count" });
    }
  });
  
  // Ziyaretçi sayısını sıfırla (admin için)
  app.post("/api/visitor-count/reset", async (req, res) => {
    try {
      visitorCount = 0;
      visitorIPs.clear();
      res.json({ success: true, count: visitorCount });
    } catch (error) {
      console.error("Error resetting visitor count:", error);
      res.status(500).json({ message: "Error resetting visitor count" });
    }
  });
  
  // Tüm kullanıcıları getir (sadece admin erişebilir)
  app.get("/api/users", async (req, res) => {
    if (!req.isAuthenticated() || (!req.user.isAdmin && req.user.role !== "admin" && req.user.role !== "major_admin")) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error getting users:", error);
      res.status(500).json({ message: "Error getting users" });
    }
  });
  
  // Kullanıcı banlama
  app.post("/api/users/:id/ban", async (req, res) => {
    if (!req.isAuthenticated() || (!req.user.isAdmin && req.user.role !== "admin" && req.user.role !== "major_admin")) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const id = req.params.id;
      
      // Önce kullanıcı bilgilerini alalım
      const numericId = parseInt(id);
      const user = await storage.getUser(numericId);
      
      if (!user) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Kullanıcıyı banla
      await storage.banUser(id);
      
      // Log the action
      await logAdminAction(
        req.user.id, 
        "Kullanıcı Banlama", 
        `Kullanıcı banlandı: ${user.username} (ID: ${id})`,
        "users",
        id,
        req
      );
      
      // Kullanıcı oturumlarını sonlandır (JSON storage doesn't need session cleanup)
      // Session cleanup is handled automatically
      
      console.log(`${user.username} kullanıcısı banlandı ve aktif oturumları sonlandırıldı`);
      
      res.status(200).json({ message: "User banned successfully" });
    } catch (error) {
      console.error("Error banning user:", error);
      res.status(500).json({ 
        message: "Error banning user", 
        error: (error as Error).message 
      });
    }
  });
  
  // Kullanıcı yasağını kaldırma
  app.post("/api/users/:id/unban", async (req, res) => {
    if (!req.isAuthenticated() || (!req.user.isAdmin && req.user.role !== "admin" && req.user.role !== "major_admin")) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const id = req.params.id;
      
      // Önce kullanıcı bilgilerini alalım
      const numericId = parseInt(id);
      const user = await storage.getUser(numericId);
      
      if (!user) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Kullanıcı yasağını kaldır
      await storage.unbanUser(id);
      
      // Log the action
      await logAdminAction(
        req.user.id, 
        "Kullanıcı Yasağı Kaldırma", 
        `Kullanıcı yasağı kaldırıldı: ${user.username} (ID: ${id})`,
        "users",
        id,
        req
      );
      
      console.log(`${user.username} kullanıcısının yasağı kaldırıldı`);
      
      res.status(200).json({ message: "User unbanned successfully" });
    } catch (error) {
      console.error("Error unbanning user:", error);
      res.status(500).json({ 
        message: "Error unbanning user",
        error: (error as Error).message 
      });
    }
  });
  
  // Remove direct admin login route for security
  // This route has been removed to prevent security issues

  // API endpoints
  // Events
  app.get("/api/events", async (req, res) => {
    try {
      const category = req.query.category?.toString();
      let events;

      if (category && Object.values(eventCategoryEnum.enumValues).includes(category as any)) {
        events = await storage.getEventsByCategory(category as "rescue" | "training" | "donation" | "awareness");
      } else {
        events = await storage.getAllEvents();
      }
      
      res.json(events);
    } catch (error) {
      console.error("Error getting events:", error);
      res.status(500).json({ message: "Error getting events" });
    }
  });

  app.get("/api/events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const event = await storage.getEvent(id);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json(event);
    } catch (error) {
      console.error("Error getting event:", error);
      res.status(500).json({ message: "Error getting event" });
    }
  });

  app.post("/api/events", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      console.log("Creating new event with data:", JSON.stringify(req.body));
      
      // Convert string date to Date object and handle date format properly
      const reqBody = {
        ...req.body,
        date: req.body.date ? new Date(req.body.date) : new Date()
      };
      
      // Make sure required fields are present
      if (!reqBody.title || !reqBody.description || !reqBody.location || !reqBody.category) {
        return res.status(400).json({ 
          message: "Missing required fields", 
          fields: {
            title: !reqBody.title ? "Title is required" : null,
            description: !reqBody.description ? "Description is required" : null,
            location: !reqBody.location ? "Location is required" : null,
            category: !reqBody.category ? "Category is required" : null
          } 
        });
      }
      
      // Create the event with validated data
      try {
        const eventData = insertEventSchema.parse(reqBody);
        console.log("Validated event data:", JSON.stringify(eventData));
        
        const newEvent = await storage.createEvent({
          ...eventData,
          createdBy: req.user.id,
        });
        
        console.log("Event created successfully:", JSON.stringify(newEvent));
        
        // Etkinlik ekleme işlemini güvenlik kayıtlarına ekleyelim
        await logAdminAction(
          req.user.id,
          "Etkinlik Ekleme",
          `Yeni etkinlik oluşturuldu: ${eventData.title}`,
          "events",
          newEvent.id.toString(),
          req
        );
        
        res.status(201).json(newEvent);
      } catch (parseError) {
        console.error("Validation error creating event:", parseError);
        res.status(400).json({ message: "Invalid event data", error: parseError });
      }
    } catch (error) {
      console.error("Unexpected error creating event:", error);
      res.status(500).json({ message: "Error creating event" });
    }
  });

  app.put("/api/events/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      
      // Convert string date to Date object
      const reqBody = {
        ...req.body,
        date: req.body.date ? new Date(req.body.date) : undefined
      };
      
      const eventData = insertEventSchema.parse(reqBody);
      const updatedEvent = await storage.updateEvent(id, eventData);
      
      if (!updatedEvent) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json(updatedEvent);
    } catch (error) {
      console.error("Error updating event:", error);
      res.status(400).json({ message: "Invalid event data" });
    }
  });

  app.delete("/api/events/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      
      // Get event details before deletion to include in log
      const event = await storage.getEvent(id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Delete the event
      await storage.deleteEvent(id);
      
      // Log the deletion action
      await logAdminAction(
        req.user.id,
        "Etkinlik Silme",
        `Etkinlik silindi: ${event.title}`,
        "events",
        id.toString(),
        req
      );
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting event:", error);
      res.status(500).json({ message: "Error deleting event" });
    }
  });

  // Media Items
  app.get("/api/media", async (req, res) => {
    try {
      const mediaType = req.query.type?.toString();
      const albumId = req.query.albumId ? parseInt(req.query.albumId.toString()) : undefined;
      const eventId = req.query.eventId ? parseInt(req.query.eventId.toString()) : undefined;
      
      let mediaItems;
      
      if (mediaType === 'photo' && albumId) {
        mediaItems = await storage.getPhotosByAlbum(albumId);
      } else if (mediaType === 'video') {
        mediaItems = await storage.getAllVideos();
      } else if (mediaType) {
        mediaItems = await storage.getMediaByType(mediaType as any);
      } else if (eventId) {
        mediaItems = await storage.getMediaByEvent(eventId);
      } else {
        mediaItems = await storage.getAllMedia();
      }
      
      res.json(mediaItems);
    } catch (error) {
      console.error("Error getting media:", error);
      res.status(500).json({ message: "Error getting media" });
    }
  });

  app.post("/api/media", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const mediaData = insertMediaItemSchema.parse(req.body);
      const newMedia = await storage.createMediaItem({
        ...mediaData,
        createdBy: req.user.id,
      });
      
      // Direct admin log entry for media creation
      await logAdminAction(
        req.user.id,
        "Medya Ekleme",
        `Yeni medya eklendi: ${mediaData.title || mediaData.filePath || 'Başlıksız'}`,
        "media",
        newMedia.id.toString(),
        req
      );
      
      res.status(201).json(newMedia);
    } catch (error) {
      console.error("Error creating media:", error);
      res.status(400).json({ message: "Invalid media data" });
    }
  });

  app.put("/api/media/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const mediaData = insertMediaItemSchema.parse(req.body);
      
      const updatedMedia = await storage.updateMedia(id, mediaData);
      
      if (!updatedMedia) {
        return res.status(404).json({ message: "Media not found" });
      }
      
      // Log the update action
      await logAdminAction(
        req.user.id,
        "Medya Güncelleme",
        `Medya öğesi güncellendi: ${mediaData.title || 'Başlıksız'} (ID: ${id})`,
        "media",
        id.toString(),
        req
      );
      
      res.json(updatedMedia);
    } catch (error) {
      console.error("Error updating media:", error);
      res.status(400).json({ message: "Invalid media data" });
    }
  });

  app.delete("/api/media/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      
      // Delete the media item
      await storage.deleteMediaItem(id);
      
      // Log the deletion action
      await logAdminAction(
        req.user.id,
        "Medya Silme",
        `Medya öğesi silindi (ID: ${id})`,
        "media",
        id.toString(),
        req
      );
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting media:", error);
      res.status(500).json({ message: "Error deleting media" });
    }
  });

  // Albums
  app.get("/api/albums", async (req, res) => {
    try {
      const albums = await storage.getAllAlbums();
      res.json(albums);
    } catch (error) {
      console.error("Error getting albums:", error);
      res.status(500).json({ message: "Error getting albums" });
    }
  });

  app.get("/api/albums/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const album = await storage.getAlbum(id);
      
      if (!album) {
        return res.status(404).json({ message: "Album not found" });
      }
      
      res.json(album);
    } catch (error) {
      console.error("Error getting album:", error);
      res.status(500).json({ message: "Error getting album" });
    }
  });

  app.get("/api/albums/:id/photos", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const photos = await storage.getPhotosByAlbum(id);
      res.json(photos);
    } catch (error) {
      console.error("Error getting album photos:", error);
      res.status(500).json({ message: "Error getting album photos" });
    }
  });

  app.post("/api/albums", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const albumData = insertAlbumSchema.parse(req.body);
      const newAlbum = await storage.createAlbum({
        ...albumData,
        createdBy: req.user.id,
      });
      res.status(201).json(newAlbum);
    } catch (error) {
      console.error("Error creating album:", error);
      res.status(400).json({ message: "Invalid album data" });
    }
  });

  app.put("/api/albums/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const albumData = insertAlbumSchema.parse(req.body);
      const updatedAlbum = await storage.updateAlbum(id, albumData);
      
      if (!updatedAlbum) {
        return res.status(404).json({ message: "Album not found" });
      }
      
      res.json(updatedAlbum);
    } catch (error) {
      console.error("Error updating album:", error);
      res.status(400).json({ message: "Invalid album data" });
    }
  });

  app.delete("/api/albums/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      
      // Get album details before deletion for log
      const album = await storage.getAlbum(id);
      if (!album) {
        return res.status(404).json({ message: "Album not found" });
      }
      
      // Delete the album
      await storage.deleteAlbum(id);
      
      // Log the deletion action
      await logAdminAction(
        req.user.id,
        "Albüm Silme",
        `Fotoğraf albümü silindi: ${album.title}`,
        "media",
        id.toString(),
        req
      );
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting album:", error);
      res.status(500).json({ message: "Error deleting album" });
    }
  });

  // Team Members
  app.get("/api/team", async (req, res) => {
    try {
      const teamMembers = await storage.getAllTeamMembers();
      res.json(teamMembers);
    } catch (error) {
      console.error("Error getting team members:", error);
      res.status(500).json({ message: "Error getting team members" });
    }
  });

  app.post("/api/team", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const memberData = insertTeamMemberSchema.parse(req.body);
      const newMember = await storage.createTeamMember({
        ...memberData,
        createdBy: req.user.id,
      });
      
      // Log the team member creation action
      await logAdminAction(
        req.user.id,
        "Ekip Üyesi Ekleme",
        `Yeni ekip üyesi eklendi: ${memberData.firstName} ${memberData.lastName}`,
        "team",
        newMember.id.toString(),
        req
      );
      
      res.status(201).json(newMember);
    } catch (error) {
      console.error("Error creating team member:", error);
      res.status(400).json({ message: "Invalid team member data" });
    }
  });

  app.put("/api/team/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const memberData = insertTeamMemberSchema.parse(req.body);
      const updatedMember = await storage.updateTeamMember(id, memberData);
      
      if (!updatedMember) {
        return res.status(404).json({ message: "Team member not found" });
      }
      
      // Log the team member update action
      await logAdminAction(
        req.user.id,
        "Ekip Üyesi Güncelleme",
        `Ekip üyesi güncellendi: ${memberData.firstName} ${memberData.lastName}`,
        "team",
        id.toString(),
        req
      );
      
      res.json(updatedMember);
    } catch (error) {
      console.error("Error updating team member:", error);
      res.status(400).json({ message: "Invalid team member data" });
    }
  });

  app.delete("/api/team/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      
      // Delete the team member
      await storage.deleteTeamMember(id);
      
      // Log the deletion action
      await logAdminAction(
        req.user.id,
        "Ekip Üyesi Silme",
        `Ekip üyesi silindi (ID: ${id})`,
        "team",
        id.toString(),
        req
      );
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting team member:", error);
      res.status(500).json({ message: "Error deleting team member" });
    }
  });

  // Contact Messages
  app.post("/api/contact", async (req, res) => {
    try {
      const messageData = insertContactMessageSchema.parse(req.body);
      const newMessage = await storage.createContactMessage(messageData);
      res.status(201).json(newMessage);
    } catch (error) {
      console.error("Error creating contact message:", error);
      res.status(400).json({ message: "Invalid contact message data" });
    }
  });

  app.get("/api/contact", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const messages = await storage.getAllContactMessages();
      res.json(messages);
    } catch (error) {
      console.error("Error getting contact messages:", error);
      res.status(500).json({ message: "Error getting contact messages" });
    }
  });

  app.put("/api/contact/:id/read", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const updatedMessage = await storage.markContactMessageAsRead(id);
      
      if (!updatedMessage) {
        return res.status(404).json({ message: "Message not found" });
      }
      
      res.json(updatedMessage);
    } catch (error) {
      console.error("Error marking message as read:", error);
      res.status(500).json({ message: "Error marking message as read" });
    }
  });

  // Settings
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getAllSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error getting settings:", error);
      res.status(500).json({ message: "Error getting settings" });
    }
  });

  app.put("/api/settings", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const settingsData = req.body;
      const results = [];
      const updatedKeys = [];
      
      for (const key in settingsData) {
        const value = settingsData[key];
        const settingData = insertSettingSchema.parse({ key, value });
        const result = await storage.updateSetting(
          key, 
          value, 
          req.user.id
        );
        results.push(result);
        updatedKeys.push(key);
      }
      
      // Log the settings update action
      await logAdminAction(
        req.user.id,
        "Ayarlar Güncelleme",
        `Güncellenen ayarlar: ${updatedKeys.join(', ')}`,
        "settings",
        updatedKeys.join(','),
        req
      );
      
      res.json(results);
    } catch (error) {
      console.error("Error updating settings:", error);
      res.status(400).json({ message: "Invalid settings data" });
    }
  });

  // Donation Methods
  app.get("/api/donation/methods", async (req, res) => {
    try {
      const methods = await storage.getAllDonationMethods();
      res.json(methods);
    } catch (error) {
      console.error("Error getting donation methods:", error);
      res.status(500).json({ message: "Error getting donation methods" });
    }
  });

  app.post("/api/donation/methods", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const methodData = insertDonationMethodSchema.parse(req.body);
      console.log("Creating donation method with data:", methodData);
      
      const newMethod = await storage.createDonationMethod({
        ...methodData,
        createdBy: req.user.id,
        updatedBy: req.user.id,
      });
      
      // Direct admin log entry for donation method creation
      await logAdminAction(
        req.user.id,
        "Bağış Yöntemi Ekleme",
        `Yeni bağış yöntemi eklendi: ${methodData.bankName || 'Başlıksız'}`,
        "donation-methods",
        newMethod.id.toString(),
        req
      );
      
      res.status(201).json(newMethod);
    } catch (error: any) {
      console.error("Error creating donation method:", error);
      res.status(400).json({ message: "Invalid donation method data", error: error.message });
    }
  });

  app.put("/api/donation/methods/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const methodData = insertDonationMethodSchema.parse(req.body);
      const updatedMethod = await storage.updateDonationMethod(id, {
        ...methodData,
        updatedBy: req.user.id,
      });
      
      if (!updatedMethod) {
        return res.status(404).json({ message: "Donation method not found" });
      }
      
      res.json(updatedMethod);
    } catch (error) {
      console.error("Error updating donation method:", error);
      res.status(400).json({ message: "Invalid donation method data" });
    }
  });

  app.delete("/api/donation/methods/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      
      // Get donation method details before deletion for log
      const method = await storage.getDonationMethod(id);
      if (!method) {
        return res.status(404).json({ message: "Donation method not found" });
      }
      
      // Delete the donation method
      await storage.deleteDonationMethod(id);
      
      // Log the deletion action
      await logAdminAction(
        req.user.id,
        "Bağış Yöntemi Silme",
        `Bağış yöntemi silindi: ${method.bankName || 'ID: ' + id}`,
        "donation-methods",
        id.toString(),
        req
      );
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting donation method:", error);
      res.status(500).json({ message: "Error deleting donation method" });
    }
  });

  // Donation Campaigns
  app.get("/api/donation/campaigns", async (req, res) => {
    try {
      const campaigns = await storage.getAllDonationCampaigns();
      res.json(campaigns);
    } catch (error) {
      console.error("Error getting donation campaigns:", error);
      res.status(500).json({ message: "Error getting donation campaigns" });
    }
  });

  app.post("/api/donation/campaigns", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      // Prepare the data with proper conversions
      const reqBody = {
        ...req.body,
        targetAmount: req.body.targetAmount !== undefined ? String(req.body.targetAmount) : undefined,
        currentAmount: req.body.currentAmount !== undefined ? String(req.body.currentAmount) : undefined,
        // Keep endDate as string to match the schema expectation
        endDate: req.body.endDate || undefined
      };
      
      console.log("Processing donation campaign data:", reqBody);
      
      const campaignData = insertDonationCampaignSchema.parse(reqBody);
      const newCampaign = await storage.createDonationCampaign({
        ...campaignData,
        createdBy: req.user.id,
        updatedBy: req.user.id,
      });
      
      // Log the donation campaign creation in admin logs
      await logAdminAction(
        req.user.id,
        "Bağış Kampanyası Ekleme",
        `Yeni bağış kampanyası eklendi: ${newCampaign.title}`,
        "donation-campaigns",
        newCampaign.id.toString(),
        req
      );
      
      res.status(201).json(newCampaign);
    } catch (error) {
      console.error("Error creating donation campaign:", error);
      res.status(400).json({ message: "Invalid donation campaign data" });
    }
  });

  app.put("/api/donation/campaigns/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      
      // Keep endDate as string for compatibility with schema
      const reqBody = {
        ...req.body,
        targetAmount: req.body.targetAmount !== undefined ? String(req.body.targetAmount) : undefined,
        currentAmount: req.body.currentAmount !== undefined ? String(req.body.currentAmount) : undefined,
        endDate: req.body.endDate || undefined
      };
      
      console.log("Updating campaign data:", reqBody);
      
      const campaignData = insertDonationCampaignSchema.parse(reqBody);
      const updatedCampaign = await storage.updateDonationCampaign(id, {
        ...campaignData,
        updatedBy: req.user.id,
      });
      
      if (!updatedCampaign) {
        return res.status(404).json({ message: "Donation campaign not found" });
      }
      
      // Log the donation campaign update in admin logs
      await logAdminAction(
        req.user.id,
        "Bağış Kampanyası Güncelleme",
        `Bağış kampanyası güncellendi: ${updatedCampaign.title}`,
        "donation-campaigns",
        updatedCampaign.id.toString(),
        req
      );
      
      res.json(updatedCampaign);
    } catch (error) {
      console.error("Error updating donation campaign:", error);
      res.status(400).json({ message: "Invalid donation campaign data" });
    }
  });

  app.delete("/api/donation/campaigns/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      
      // Get campaign details before deletion for log
      const campaign = await storage.getDonationCampaign(id);
      if (!campaign) {
        return res.status(404).json({ message: "Donation campaign not found" });
      }
      
      // Delete the campaign
      await storage.deleteDonationCampaign(id);
      
      // Log the deletion action
      await logAdminAction(
        req.user.id,
        "Bağış Kampanyası Silme",
        `Bağış kampanyası silindi: ${campaign.title}`,
        "donation-campaigns",
        id.toString(),
        req
      );
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting donation campaign:", error);
      res.status(500).json({ message: "Error deleting donation campaign" });
    }
  });

  // Hero Slider API Endpoints
  app.get("/api/hero-sliders", async (req, res) => {
    try {
      const activeOnly = req.query.active === "true";
      const sliders = activeOnly 
        ? await storage.getActiveHeroSliders() 
        : await storage.getAllHeroSliders();
      res.json(sliders);
    } catch (error) {
      console.error("Error getting hero sliders:", error);
      res.status(500).json({ message: "Error getting hero sliders" });
    }
  });

  app.get("/api/hero-sliders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const slider = await storage.getHeroSlider(id);
      
      if (!slider) {
        return res.status(404).json({ message: "Slider not found" });
      }
      
      res.json(slider);
    } catch (error) {
      console.error("Error getting hero slider:", error);
      res.status(500).json({ message: "Error getting hero slider" });
    }
  });

  app.post("/api/hero-sliders", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const sliderData = insertHeroSliderSchema.parse(req.body);
      const newSlider = await storage.createHeroSlider({
        ...sliderData,
        createdBy: req.user.id,
        updatedBy: req.user.id,
      });
      
      // Log entry is created automatically through the middleware
      
      res.status(201).json(newSlider);
    } catch (error) {
      console.error("Error creating hero slider:", error);
      res.status(400).json({ message: "Invalid hero slider data" });
    }
  });

  app.put("/api/hero-sliders/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const sliderData = insertHeroSliderSchema.parse(req.body);
      const updatedSlider = await storage.updateHeroSlider(id, {
        ...sliderData,
        updatedBy: req.user.id,
      });
      
      if (!updatedSlider) {
        return res.status(404).json({ message: "Hero slider not found" });
      }
      
      res.json(updatedSlider);
    } catch (error) {
      console.error("Error updating hero slider:", error);
      res.status(400).json({ message: "Invalid hero slider data" });
    }
  });

  app.delete("/api/hero-sliders/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      
      // Get slider details before deletion for log
      const slider = await storage.getHeroSlider(id);
      if (!slider) {
        return res.status(404).json({ message: "Hero slider not found" });
      }
      
      // Delete the slider
      await storage.deleteHeroSlider(id);
      
      // Log the deletion action
      await logAdminAction(
        req.user.id,
        "Slider Silme",
        `Ana sayfa slider silindi: ${slider.title}`,
        "sliders",
        id.toString(),
        req
      );
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting hero slider:", error);
      res.status(500).json({ message: "Error deleting hero slider" });
    }
  });

  app.put("/api/hero-sliders/:id/order", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const { order } = req.body;
      
      if (typeof order !== 'number') {
        return res.status(400).json({ message: "Invalid order value" });
      }
      
      await storage.updateHeroSliderOrder(id, order);
      res.status(204).end();
    } catch (error) {
      console.error("Error updating hero slider order:", error);
      res.status(500).json({ message: "Error updating hero slider order" });
    }
  });

  // Archive Management Routes
  app.get("/api/admin/archive", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const archiveItems = await storage.getAllArchiveItems();
      res.json(archiveItems);
    } catch (error) {
      console.error("Error fetching archive items:", error);
      res.status(500).json({ message: "Error fetching archive items" });
    }
  });

  app.post("/api/admin/archive", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      // Parse the request without validation first to handle date conversion
      const requestData = { ...req.body };
      if (requestData.date && typeof requestData.date === 'string') {
        requestData.date = new Date(requestData.date);
      }
      
      // Use a simplified validation that doesn't include the problematic date validation
      const validatedData = {
        title: requestData.title,
        description: requestData.description,
        content: requestData.content || null,
        itemType: requestData.itemType,
        date: requestData.date,
        location: requestData.location || null,
        participants: requestData.participants || null,
        outcome: requestData.outcome || null,
        imageUrl: requestData.imageUrl || null,
        videoUrl: requestData.videoUrl || null,
        documentUrl: requestData.documentUrl || null,
        tags: requestData.tags || null,
        isPublished: requestData.isPublished || false,
        isFeatured: requestData.isFeatured || false,
      };
      const archiveItem = await storage.createArchiveItem({
        ...validatedData,
        createdBy: req.user.id,
        updatedBy: req.user.id,
      });

      // Log the creation action
      await logAdminAction(
        req.user.id,
        "Arşiv Oluşturma",
        `Yeni arşiv öğesi oluşturuldu: ${archiveItem.title}`,
        "archive",
        archiveItem.id.toString(),
        req
      );

      res.status(201).json(archiveItem);
    } catch (error) {
      console.error("Error creating archive item:", error);
      res.status(400).json({ message: "Invalid archive item data" });
    }
  });

  app.put("/api/admin/archive/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const validatedData = insertArchiveItemSchema.parse(req.body);
      
      const archiveItem = await storage.updateArchiveItem(id, {
        ...validatedData,
        updatedBy: req.user.id,
      });

      if (!archiveItem) {
        return res.status(404).json({ message: "Archive item not found" });
      }

      // Log the update action
      await logAdminAction(
        req.user.id,
        "Arşiv Güncelleme",
        `Arşiv öğesi güncellendi: ${archiveItem.title}`,
        "archive",
        id.toString(),
        req
      );

      res.json(archiveItem);
    } catch (error) {
      console.error("Error updating archive item:", error);
      res.status(400).json({ message: "Invalid archive item data" });
    }
  });

  app.delete("/api/admin/archive/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const archiveItem = await storage.getArchiveItem(id);
      
      if (!archiveItem) {
        return res.status(404).json({ message: "Archive item not found" });
      }

      await storage.deleteArchiveItem(id);

      // Log the deletion action
      await logAdminAction(
        req.user.id,
        "Arşiv Silme",
        `Arşiv öğesi silindi: ${archiveItem.title}`,
        "archive",
        id.toString(),
        req
      );

      res.status(204).end();
    } catch (error) {
      console.error("Error deleting archive item:", error);
      res.status(500).json({ message: "Error deleting archive item" });
    }
  });

  app.patch("/api/admin/archive/:id/toggle-publish", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const { isPublished } = req.body;
      
      const archiveItem = await storage.toggleArchiveItemPublish(id, isPublished);
      
      if (!archiveItem) {
        return res.status(404).json({ message: "Archive item not found" });
      }

      // Log the publish toggle action
      await logAdminAction(
        req.user.id,
        "Arşiv Yayın Durumu",
        `Arşiv öğesi ${isPublished ? 'yayınlandı' : 'yayından kaldırıldı'}: ${archiveItem.title}`,
        "archive",
        id.toString(),
        req
      );

      res.json(archiveItem);
    } catch (error) {
      console.error("Error toggling archive item publish status:", error);
      res.status(500).json({ message: "Error toggling publish status" });
    }
  });

  app.patch("/api/admin/archive/:id/toggle-featured", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const { isFeatured } = req.body;
      
      const archiveItem = await storage.toggleArchiveItemFeatured(id, isFeatured);
      
      if (!archiveItem) {
        return res.status(404).json({ message: "Archive item not found" });
      }

      // Log the featured toggle action
      await logAdminAction(
        req.user.id,
        "Arşiv Öne Çıkarma",
        `Arşiv öğesi ${isFeatured ? 'öne çıkarıldı' : 'öne çıkarmadan kaldırıldı'}: ${archiveItem.title}`,
        "archive",
        id.toString(),
        req
      );

      res.json(archiveItem);
    } catch (error) {
      console.error("Error toggling archive item featured status:", error);
      res.status(500).json({ message: "Error toggling featured status" });
    }
  });

  // Public archive routes
  app.get("/api/archive", async (req, res) => {
    try {
      const archiveItems = await storage.getPublishedArchiveItems();
      res.json(archiveItems);
    } catch (error) {
      console.error("Error fetching published archive items:", error);
      res.status(500).json({ message: "Error fetching archive items" });
    }
  });

  // Timeline routes
  app.get("/api/timeline", async (req, res) => {
    try {
      const items = await storage.getActiveTimelineItems();
      res.json(items);
    } catch (error) {
      console.error("Error fetching timeline items:", error);
      res.status(500).json({ message: "Error fetching timeline items" });
    }
  });

  app.get("/api/admin/timeline", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      const items = await storage.getAllTimelineItems();
      res.json(items);
    } catch (error) {
      console.error("Error fetching timeline items:", error);
      res.status(500).json({ message: "Error fetching timeline items" });
    }
  });

  app.post("/api/admin/timeline", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const newItem = await storage.createTimelineItem({
        ...req.body,
        createdBy: req.user.id,
        updatedBy: req.user.id,
      });
      
      await logAdminAction(
        req.user.id,
        "Tarihçe Ekleme",
        `Yeni tarihçe öğesi oluşturuldu: ${newItem.title}`,
        "timeline",
        newItem.id.toString(),
        req
      );
      
      res.status(201).json(newItem);
    } catch (error) {
      console.error("Error creating timeline item:", error);
      res.status(500).json({ message: "Error creating timeline item" });
    }
  });

  app.put("/api/admin/timeline/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const updatedItem = await storage.updateTimelineItem(id, {
        ...req.body,
        updatedBy: req.user.id,
      });
      
      if (!updatedItem) {
        return res.status(404).json({ message: "Timeline item not found" });
      }
      
      await logAdminAction(
        req.user.id,
        "Tarihçe Güncelleme",
        `Tarihçe öğesi güncellendi: ${updatedItem.title}`,
        "timeline",
        id.toString(),
        req
      );
      
      res.json(updatedItem);
    } catch (error) {
      console.error("Error updating timeline item:", error);
      res.status(500).json({ message: "Error updating timeline item" });
    }
  });

  app.delete("/api/admin/timeline/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      await storage.deleteTimelineItem(id);
      
      await logAdminAction(
        req.user.id,
        "Tarihçe Silme",
        `Tarihçe öğesi silindi: ID ${id}`,
        "timeline",
        id.toString(),
        req
      );
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting timeline item:", error);
      res.status(500).json({ message: "Error deleting timeline item" });
    }
  });

  app.patch("/api/admin/timeline/:id/toggle-active", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }

    try {
      const id = parseInt(req.params.id);
      const { isActive } = req.body;
      
      const updatedItem = await storage.toggleTimelineItemActive(id, isActive);
      
      if (!updatedItem) {
        return res.status(404).json({ message: "Timeline item not found" });
      }
      
      await logAdminAction(
        req.user.id,
        "Tarihçe Durum Değişimi",
        `Tarihçe öğesi durumu değiştirildi: ${updatedItem.title} - ${isActive ? 'Aktif' : 'Pasif'}`,
        "timeline",
        id.toString(),
        req
      );
      
      res.json(updatedItem);
    } catch (error) {
      console.error("Error toggling timeline item status:", error);
      res.status(500).json({ message: "Error toggling timeline item status" });
    }
  });

  app.get("/api/archive/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const archiveItem = await storage.getArchiveItem(id);
      
      if (!archiveItem || !archiveItem.isPublished) {
        return res.status(404).json({ message: "Archive item not found" });
      }

      // Increment view count
      await storage.incrementArchiveItemViews(id);

      res.json(archiveItem);
    } catch (error) {
      console.error("Error fetching archive item:", error);
      res.status(500).json({ message: "Error fetching archive item" });
    }
  });

  // Analytics endpoint
  app.get("/api/analytics/traffic", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized" });
    }
    
    try {
      // Return analytics data - for now, return basic metrics
      const analytics = {
        totalVisitors: visitorCount,
        uniqueVisitors: visitorIPs.size,
        recentActivity: {
          events: await storage.getAllEvents().then(events => events.length),
          activities: await storage.getActivities().then(activities => activities.length),
          media: await storage.getAllMedia().then(media => media.length),
          team: await storage.getAllTeamMembers().then(members => members.length),
        }
      };
      
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ message: "Error fetching analytics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
