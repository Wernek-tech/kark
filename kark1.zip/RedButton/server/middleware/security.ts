import { Express, Request, Response, NextFunction } from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import mongoSanitize from 'express-mongo-sanitize';
import hpp from 'hpp';
import xss from 'xss';

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      loginAttempts?: { count: number; lastAttempt: Date };
    }
  }
}

// Create a custom XSS clean middleware
export const xssClean = (req: Request, res: Response, next: NextFunction) => {
  // Clean body, query, and params
  if (req.body) req.body = cleanData(req.body);
  if (req.query) req.query = cleanData(req.query);
  if (req.params) req.params = cleanData(req.params);
  next();
};

function cleanData(data: any): any {
  if (typeof data === 'string') {
    return xss(data);
  } else if (Array.isArray(data)) {
    return data.map(cleanData);
  } else if (typeof data === 'object' && data !== null) {
    const cleaned: any = {};
    for (const key in data) {
      cleaned[key] = cleanData(data[key]);
    }
    return cleaned;
  }
  return data;
}

// Rate limiting configurations
export const createRateLimiters = () => {
  // General API rate limiter
  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
    skip: (req) => {
      // Skip rate limiting for development
      return process.env.NODE_ENV === 'development';
    },
    // Override key generator to handle trust proxy properly
    keyGenerator: (req) => {
      // Use forwarded IP if available and trust proxy is enabled, otherwise use req.ip
      const forwardedIps = req.get('X-Forwarded-For');
      if (forwardedIps && req.app.get('trust proxy')) {
        return forwardedIps.split(',')[0].trim();
      }
      return req.ip || req.connection.remoteAddress || 'unknown';
    },
  });

  // Strict rate limiter for authentication routes
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // Limit each IP to 5 requests per windowMs
    message: 'Too many authentication attempts, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
    skipSuccessfulRequests: true, // Don't count successful requests
    keyGenerator: (req) => {
      const forwardedIps = req.get('X-Forwarded-For');
      if (forwardedIps && req.app.get('trust proxy')) {
        return forwardedIps.split(',')[0].trim();
      }
      return req.ip || req.connection.remoteAddress || 'unknown';
    },
  });

  // Contact form rate limiter
  const contactLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 3, // Limit each IP to 3 contact messages per hour
    message: 'Too many messages sent, please try again later.',
    keyGenerator: (req) => {
      const forwardedIps = req.get('X-Forwarded-For');
      if (forwardedIps && req.app.get('trust proxy')) {
        return forwardedIps.split(',')[0].trim();
      }
      return req.ip || req.connection.remoteAddress || 'unknown';
    },
  });

  // File upload rate limiter
  const uploadLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 20, // Limit each IP to 20 uploads per hour
    message: 'Too many file uploads, please try again later.',
    keyGenerator: (req) => {
      const forwardedIps = req.get('X-Forwarded-For');
      if (forwardedIps && req.app.get('trust proxy')) {
        return forwardedIps.split(',')[0].trim();
      }
      return req.ip || req.connection.remoteAddress || 'unknown';
    },
  });

  return {
    apiLimiter,
    authLimiter,
    contactLimiter,
    uploadLimiter,
  };
};

// Login attempt tracking
const loginAttempts = new Map<string, { count: number; lastAttempt: Date }>();

export const trackLoginAttempt = (req: Request, res: Response, next: NextFunction) => {
  const identifier = req.body.username || req.ip;
  const attempts = loginAttempts.get(identifier) || { count: 0, lastAttempt: new Date() };
  
  // Reset attempts if last attempt was more than 15 minutes ago
  const fifteenMinutesAgo = new Date(Date.now() - 15 * 60 * 1000);
  if (attempts.lastAttempt < fifteenMinutesAgo) {
    attempts.count = 0;
  }
  
  // Check if account is locked
  if (attempts.count >= 5) {
    return res.status(429).json({
      message: 'Account temporarily locked due to too many failed login attempts. Please try again in 15 minutes.',
    });
  }
  
  req.loginAttempts = attempts;
  next();
};

export const recordFailedLogin = (identifier: string) => {
  const attempts = loginAttempts.get(identifier) || { count: 0, lastAttempt: new Date() };
  attempts.count++;
  attempts.lastAttempt = new Date();
  loginAttempts.set(identifier, attempts);
};

export const clearLoginAttempts = (identifier: string) => {
  loginAttempts.delete(identifier);
};

// Security headers configuration
export const configureSecurityHeaders = (app: Express) => {
  // Use Helmet with custom configuration
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"], // For development
        imgSrc: ["'self'", "data:", "https:", "blob:"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        connectSrc: ["'self'", "ws:", "wss:"], // For WebSocket connections
        mediaSrc: ["'self'", "blob:"],
        objectSrc: ["'none'"],
        frameSrc: ["'self'", "https://www.youtube.com", "https://www.youtube-nocookie.com"],
      },
    },
    crossOriginEmbedderPolicy: false, // Allow embedding of images from other origins
  }));

  // Additional security headers
  app.use((req, res, next) => {
    // Prevent clickjacking
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    
    // Prevent MIME type sniffing
    res.setHeader('X-Content-Type-Options', 'nosniff');
    
    // Enable XSS filter
    res.setHeader('X-XSS-Protection', '1; mode=block');
    
    // Referrer policy
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    
    // Feature policy
    res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
    
    next();
  });
};

// Input validation middleware
export const validateInput = (req: Request, res: Response, next: NextFunction) => {
  // Check for excessively long inputs
  const maxFieldLength = 10000;
  const checkLength = (obj: any): boolean => {
    for (const key in obj) {
      if (typeof obj[key] === 'string' && obj[key].length > maxFieldLength) {
        return false;
      } else if (typeof obj[key] === 'object' && obj[key] !== null) {
        if (!checkLength(obj[key])) return false;
      }
    }
    return true;
  };

  if (req.body && !checkLength(req.body)) {
    return res.status(400).json({ message: 'Input too long' });
  }

  next();
};

// File upload security
export const fileUploadSecurity = (req: Request, res: Response, next: NextFunction) => {
  if (!req.files && !req.file) {
    return next();
  }

  const allowedMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'application/pdf',
    'video/mp4',
    'video/mpeg',
    'video/quicktime',
  ];

  const maxFileSize = 50 * 1024 * 1024; // 50MB

  const files = req.files ? (Array.isArray(req.files) ? req.files : [req.files]) : [req.file];
  
  for (const file of files) {
    if (!file) continue;
    
    // Check MIME type
    if (!allowedMimeTypes.includes(file.mimetype)) {
      return res.status(400).json({ 
        message: 'Invalid file type. Only images, PDFs, and videos are allowed.' 
      });
    }

    // Check file size
    if (file.size > maxFileSize) {
      return res.status(400).json({ 
        message: 'File too large. Maximum size is 50MB.' 
      });
    }
  }

  next();
};

// Apply all security middleware
export const applySecurityMiddleware = (app: Express) => {
  // Configure CORS with strict settings
  const corsOptions = {
    origin: process.env.NODE_ENV === 'production' 
      ? ['https://kark.replit.app', 'https://kark.repl.co'] // Add your production domains
      : true, // Allow all origins in development
    credentials: true,
    optionsSuccessStatus: 200,
    maxAge: 86400, // 24 hours
  };
  app.use(cors(corsOptions));

  // Configure security headers
  configureSecurityHeaders(app);

  // Sanitize data to prevent NoSQL injection attacks
  app.use((req, res, next) => {
    // Skip sanitization for settings endpoints to preserve dot notation
    if (req.url === '/api/settings' && req.method === 'PUT') {
      // Custom sanitization for settings that preserves dots in keys
      if (req.body && typeof req.body === 'object') {
        for (const key in req.body) {
          // Allow dots in settings keys but still check for actual MongoDB operators
          if (key.includes('$') || key.includes('{') || key.includes('}')) {
            console.warn(`[Security] Attempted NoSQL injection in settings: ${key}`);
            delete req.body[key];
          }
        }
      }
      return next();
    }
    
    // Apply normal mongo sanitization for all other routes
    return mongoSanitize({
      replaceWith: '_',
      onSanitize: ({ req, key }) => {
        console.warn(`[Security] Attempted NoSQL injection in ${key}`);
      }
    })(req, res, next);
  });

  // Prevent parameter pollution
  app.use(hpp({
    whitelist: ['sort', 'fields', 'page', 'limit'] // Allow these duplicate params
  }));

  // XSS protection with enhanced cleaning
  app.use(xssClean);

  // Input validation
  app.use(validateInput);

  // Create rate limiters
  const { apiLimiter, authLimiter, contactLimiter, uploadLimiter } = createRateLimiters();

  // Apply rate limiting to specific routes
  app.use('/api/', apiLimiter);
  app.use('/api/auth/', authLimiter);
  app.use('/api/login', authLimiter);
  app.use('/api/register', authLimiter);
  app.use('/api/contact', contactLimiter);
  app.use('/api/upload', uploadLimiter);
  app.use('/api/media', uploadLimiter);
  
  // Add security logging middleware
  app.use((req, res, next) => {
    // Log suspicious activity
    if (req.headers['user-agent'] && req.headers['user-agent'].includes('sqlmap')) {
      console.warn(`[Security Alert] Potential SQL injection scan from IP: ${req.ip}`);
    }
    next();
  });
};