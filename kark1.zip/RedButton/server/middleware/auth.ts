import { Request, Response, NextFunction } from "express";

// Middleware to check if user is authenticated
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ message: "Oturum açmanız gerekiyor" });
  }
  next();
}

// Middleware to check if user is an admin (any admin level)
export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const user = req.user as any;
  if (!user) {
    return res.status(401).json({ message: "Oturum açmanız gerekiyor" });
  }
  
  if (!user.isAdmin && user.role !== "admin" && user.role !== "major_admin") {
    return res.status(403).json({ message: "Bu işlem için yetkiniz bulunmuyor" });
  }
  
  next();
}

// Middleware to check if user is a major admin
export function requireMajorAdmin(req: Request, res: Response, next: NextFunction) {
  const user = req.user as any;
  if (!user) {
    return res.status(401).json({ message: "Oturum açmanız gerekiyor" });
  }
  
  if (user.role !== "major_admin" && !user.permissions?.includes("manage_admins")) {
    return res.status(403).json({ message: "Bu işlem için yetkiniz bulunmuyor" });
  }
  
  next();
}