# Fix Nginx Configuration Error

## The Problem
Your nginx configuration has a syntax error on line 31 with the `gzip_proxied` directive.

## Commands to Run on Your Server

```bash
# 1. Remove the broken configuration
sudo rm /etc/nginx/sites-enabled/kibrisaramakurtarma
sudo rm /etc/nginx/sites-available/kibrisaramakurtarma

# 2. Copy the fixed configuration from your KARK directory
sudo cp /var/www/kark/nginx-fixed.conf /etc/nginx/sites-available/kibrisaramakurtarma

# 3. Enable the site
sudo ln -s /etc/nginx/sites-available/kibrisaramakurtarma /etc/nginx/sites-enabled/

# 4. Test the configuration
sudo nginx -t

# 5. If test passes, restart nginx
sudo systemctl restart nginx
sudo systemctl enable nginx

# 6. Check nginx status
sudo systemctl status nginx
```

## Alternative: Manual Fix

If you prefer to edit the existing file:

```bash
# Edit the existing configuration file
sudo nano /etc/nginx/sites-available/kibrisaramakurtarma

# Find line 31 and change:
# FROM: gzip_proxied expired no-cache no-store private must-revalidate auth;
# TO:   gzip_proxied any;

# Then test and restart
sudo nginx -t
sudo systemctl restart nginx
```

## What Changed

- Fixed `gzip_proxied` directive (removed invalid `must-revalidate` value)
- Simplified gzip configuration for better compatibility
- Added better error handling and timeouts
- Improved static file handling

After running these commands, your nginx should start successfully and be ready for SSL certificate installation.