# Admin Logging System Documentation

## Overview

This document explains the admin logging system implemented in the application. The system records all administrative actions in a security logs panel (Güvenlik Kayıtları) that provides real-time visibility of admin activities.

## How It Works

The admin logging system automatically captures actions performed by administrators and displays them in the security logs panel. This helps track changes, identify who made them, and maintain a complete audit trail.

### Key Components

1. **Admin Logger Module (`server/admin-logger.ts`)**: 
   - Central module that handles logging of all admin actions
   - Captures details like action type, user ID, IP address, and affected resources
   - Uses fallback mechanisms to ensure logs are recorded even if initial attempts fail

2. **Security Logs Panel (`client/src/components/admin/SecurityLogsPanel.tsx`)**:
   - Displays admin actions in a user-friendly interface
   - Features filtering by resource type (events, media, settings, etc.)
   - Auto-refreshes to show real-time updates

3. **Refreshable Security Logs Panel (`client/src/components/admin/RefreshableSecurityLogsPanel.tsx`)**:
   - Wrapper component that ensures logs are refreshed automatically
   - Provides visual feedback when refreshing data

## Database Structure

Admin logs are stored in the `admin_logs` table with the following structure:

| Column        | Type         | Description                               |
|---------------|--------------|-------------------------------------------|
| id            | SERIAL       | Primary key                               |
| user_id       | INTEGER      | ID of the admin who performed the action  |
| action        | TEXT         | Description of the action performed       |
| details       | TEXT         | Additional details about the action       |
| ip_address    | TEXT         | IP address of the admin                   |
| user_agent    | TEXT         | Browser/client information                |
| resource_type | TEXT         | Type of resource affected (e.g., "media") |
| resource_id   | TEXT         | ID of the affected resource               |
| timestamp     | TIMESTAMP    | When the action occurred                  |

## Logging Process

1. **Request Interception**:
   - The `adminActionLogger` middleware intercepts all admin API requests
   - Only requests from authenticated admin or major_admin users are logged

2. **Action Capture**:
   - The system captures the following information:
     - HTTP method (POST, PUT, DELETE, etc.)
     - Path (e.g., `/api/media`)
     - User ID and username
     - IP address and user agent
     - Request body (sanitized to remove sensitive data)

3. **Log Storage**:
   - Logs are stored in the database using Drizzle ORM
   - A fallback mechanism uses direct SQL queries if the ORM approach fails

4. **User Interface Display**:
   - Logs are displayed in the security logs panel
   - The panel auto-refreshes every 2 seconds to show real-time updates
   - Logs can be filtered by resource type (media, events, settings, etc.)

## Resource Types

The system categorizes admin actions by resource type:

- `media`: Photos and videos
- `events`: Event listings
- `sliders`: Hero sliders on homepage
- `team`: Team member information
- `settings`: System settings
- `donation-methods`: Payment/donation methods
- `donation-campaigns`: Fundraising campaigns
- `users`: User account management
- `security`: Security-related changes

## Important Security Notes

1. Only major_admin (supermanager) users can view the security logs panel
2. All admin actions are logged, even if the admin doesn't have the proper permissions
3. Failed login attempts and unauthorized access attempts are also logged
4. The logging system uses a fallback mechanism to ensure no actions go unrecorded

## Troubleshooting

If admin actions don't appear in the security logs:

1. Check if the user has admin or major_admin role
2. Verify the admin_logs table exists in the database
3. Check if the action was successful (only 2xx responses are logged)
4. Try resetting the security logs cache with the `reset-admin-logs-cache.js` script

## Enhancement Scripts

Several scripts are available to help manage the admin logging system:

- `fix-real-time-logs.js`: Ensures logs appear in real-time
- `fix-select-items.js`: Fixes UI rendering issues in the logs panel
- `reset-admin-logs-cache.js`: Resets the cache to show the latest logs

## Technical Implementation

The admin logging system uses:

1. **Event-based logging**: Captures actions after responses are completed
2. **Fallback mechanisms**: Multiple ways to ensure logs are recorded
3. **Real-time UI updates**: Auto-refreshing panel with TanStack Query
4. **Pattern recognition**: Intelligently recognizes action types from URL patterns

### Code Example: Adding Direct Logging to Routes

```typescript
// Example: Directly logging an admin action in routes
app.post("/api/media", async (req, res) => {
  if (!req.isAuthenticated() || !req.user.isAdmin) {
    return res.status(403).json({ message: "Unauthorized" });
  }

  try {
    const mediaData = insertMediaItemSchema.parse(req.body);
    const newMedia = await storage.createMediaItem({
      ...mediaData,
      createdBy: req.user.id,
    });
    
    // Direct admin log entry - can be used if middleware isn't capturing correctly
    await logAdminAction(
      req.user.id,
      "Medya Ekleme",
      `Yeni medya eklendi: ${mediaData.title || mediaData.filePath || 'Başlıksız'}`,
      "media",
      newMedia.id.toString(),
      req
    );
    
    res.status(201).json(newMedia);
  } catch (error) {
    console.error("Error creating media:", error);
    res.status(400).json({ message: "Invalid media data" });
  }
});
```