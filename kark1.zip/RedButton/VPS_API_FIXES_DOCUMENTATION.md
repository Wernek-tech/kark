# VPS API Deployment Fixes Documentation

This document outlines all the fixes implemented to ensure the KARK website API works correctly when deployed on a VPS.

## Issues Fixed

### 1. CORS Configuration
**Problem**: Cross-Origin Resource Sharing (CORS) errors when frontend and backend are on different domains/ports.

**Solution**: 
- Added comprehensive CORS configuration in `server/index.ts`
- Configurable allowed origins via `CORS_ORIGINS` environment variable
- Proper handling of credentials and headers

```javascript
// CORS configuration now supports:
- Dynamic origin validation
- Credentials support for authentication
- All necessary HTTP methods
- Proper header handling
```

### 2. Trust Proxy Configuration
**Problem**: Session and rate limiting issues behind reverse proxies (nginx, cloudflare).

**Solution**:
- Added `TRUST_PROXY` environment variable support
- Conditional trust proxy setting based on configuration
- Fixed rate limiter compatibility with proxy headers

### 3. Session Configuration
**Problem**: Session cookies not working properly in production with HTTPS and proxies.

**Solution**:
- Configurable cookie security settings via environment variables
- Support for custom cookie domain
- Proper SameSite attribute handling

Environment variables:
```bash
SESSION_SECRET=your-secure-secret
COOKIE_SECURE=false  # Set to true for HTTPS
COOKIE_SAME_SITE=lax
COOKIE_DOMAIN=.yourdomain.com  # Optional
```

### 4. API URL Configuration
**Problem**: Hardcoded localhost URLs causing issues in production.

**Solution**:
- Created `client/src/lib/config.ts` for dynamic API URL resolution
- Automatic protocol detection (http/https, ws/wss)
- Environment-based URL configuration

### 5. Port and Host Binding
**Problem**: Server not accessible externally on VPS.

**Solution**:
- Configurable host binding (default: 0.0.0.0)
- Port configuration via environment variable
- Removed platform-specific binding logic

### 6. Request Size Limits
**Problem**: Large file uploads failing.

**Solution**:
- Increased JSON and URL-encoded body size limits to 50MB
- Configurable via Express middleware

### 7. Rate Limiting
**Problem**: Rate limiter errors with proxy headers.

**Solution**:
- Added skip logic for development environment
- Proper proxy header handling
- Configurable rate limits via environment variables

## Environment Configuration

Create a `.env` file in the root directory with these settings:

```bash
# Basic Configuration
NODE_ENV=production
PORT=5000
HOST=0.0.0.0

# Database
DB_TYPE=json  # or mysql

# Session
SESSION_SECRET=generate-secure-random-string
TRUST_PROXY=true
COOKIE_SECURE=false  # true for HTTPS
COOKIE_SAME_SITE=lax

# CORS
CORS_ORIGINS=https://yourdomain.com,https://www.yourdomain.com

# Rate Limiting
RATE_LIMIT_WINDOW=900000
RATE_LIMIT_MAX=100
```

## Nginx Configuration

For VPS deployment with Nginx reverse proxy:

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # For large file uploads
        client_max_body_size 50M;
    }
}
```

## Testing API Endpoints

After deployment, test these critical endpoints:

1. **Health Check**: `curl https://yourdomain.com/api/health`
2. **CORS Test**: Use browser console to test cross-origin requests
3. **Session Test**: Login and verify session persistence
4. **File Upload**: Test with files up to 50MB

## Common Issues and Solutions

### Issue: 403 Forbidden on API calls
**Solution**: Check CORS_ORIGINS environment variable includes your domain

### Issue: Session lost after login
**Solution**: 
- Ensure TRUST_PROXY=true
- Set COOKIE_SECURE appropriately (false for HTTP, true for HTTPS)
- Check COOKIE_DOMAIN if using subdomains

### Issue: Rate limit errors
**Solution**: Verify nginx is passing correct headers (X-Real-IP, X-Forwarded-For)

### Issue: WebSocket connection fails
**Solution**: Ensure nginx configuration includes WebSocket upgrade headers

## Monitoring

Monitor these logs for issues:
- Express server logs for API errors
- Nginx error logs for proxy issues
- Browser console for client-side errors

## Security Considerations

1. Always use HTTPS in production (set COOKIE_SECURE=true)
2. Generate strong SESSION_SECRET (min 32 characters)
3. Limit CORS_ORIGINS to your specific domains
4. Keep rate limits appropriate for your use case
5. Regular security updates for dependencies

## Deployment Checklist

- [ ] Copy `.env.vps.example` to `.env` and configure
- [ ] Set up Nginx with proper proxy configuration
- [ ] Configure SSL certificate (Let's Encrypt recommended)
- [ ] Test all API endpoints
- [ ] Verify session persistence
- [ ] Check file upload functionality
- [ ] Monitor logs for errors
- [ ] Set up process manager (PM2 recommended)

This configuration ensures your KARK website API works correctly on any VPS deployment.