#!/usr/bin/env node

/**
 * Fix for Admin Panel Blank Screen Issue
 * 
 * This script addresses common causes of blank admin panels:
 * 1. Build cache issues
 * 2. Component errors in security logs
 * 3. Permission check failures
 * 4. API timeout issues
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

console.log('🔧 Fixing Admin Panel Blank Screen Issue...\n');

try {
  // 1. Clean build cache
  console.log('1. Cleaning build cache...');
  if (fs.existsSync('dist')) {
    execSync('rm -rf dist', { stdio: 'inherit' });
  }
  if (fs.existsSync('node_modules/.cache')) {
    execSync('rm -rf node_modules/.cache', { stdio: 'inherit' });
  }
  console.log('✅ Build cache cleaned\n');

  // 2. Rebuild application
  console.log('2. Rebuilding application...');
  execSync('npm run build', { stdio: 'inherit' });
  console.log('✅ Application rebuilt\n');

  // 3. Check for common problematic files
  console.log('3. Checking for problematic files...');
  
  const problematicFiles = [
    'client/src/components/admin/SecurityLogsPanel.tsx',
    'client/src/components/admin/RefreshableSecurityLogsPanel.tsx'
  ];
  
  problematicFiles.forEach(file => {
    if (fs.existsSync(file)) {
      console.log(`   Found: ${file}`);
    }
  });
  console.log('✅ File check completed\n');

  // 4. Create admin panel health check endpoint
  console.log('4. Creating admin health check...');
  
  const healthCheckCode = `
// Admin Panel Health Check
export const adminHealthCheck = () => {
  try {
    // Check if essential components are loaded
    const checks = {
      react: typeof React !== 'undefined',
      router: typeof window !== 'undefined' && window.location,
      localStorage: typeof localStorage !== 'undefined',
      user: localStorage.getItem('user') !== null
    };
    
    console.log('Admin Health Check:', checks);
    return checks;
  } catch (error) {
    console.error('Admin Health Check Failed:', error);
    return { error: error.message };
  }
};

// Auto-run health check
if (typeof window !== 'undefined') {
  window.adminHealthCheck = adminHealthCheck;
  console.log('Admin health check available at: window.adminHealthCheck()');
}
`;

  if (!fs.existsSync('client/src/lib')) {
    fs.mkdirSync('client/src/lib', { recursive: true });
  }
  
  fs.writeFileSync('client/src/lib/admin-health.ts', healthCheckCode);
  console.log('✅ Admin health check created\n');

  // 5. Create fallback admin component
  console.log('5. Creating fallback admin component...');
  
  const fallbackComponent = `
import React from 'react';
import { Button } from '@/components/ui/button';

export default function AdminFallback() {
  const handleForceRefresh = () => {
    // Clear all local storage
    localStorage.clear();
    // Force reload
    window.location.href = '/auth';
  };

  const handleRetryAdmin = () => {
    window.location.href = '/admin';
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <div className="text-center p-8 bg-white rounded-lg shadow-md max-w-md">
        <h1 className="text-2xl font-bold mb-4 text-red-600">
          Admin Panel Loading Issue
        </h1>
        <p className="mb-6 text-gray-600">
          Admin paneli yüklenirken bir sorun oluştu. Aşağıdaki seçenekleri deneyebilirsiniz:
        </p>
        <div className="space-y-3">
          <Button onClick={handleRetryAdmin} className="w-full">
            Admin Paneli Yeniden Dene
          </Button>
          <Button onClick={handleForceRefresh} variant="outline" className="w-full">
            Oturumu Sıfırla ve Yeniden Giriş Yap
          </Button>
          <Button 
            onClick={() => window.location.href = '/'} 
            variant="ghost" 
            className="w-full"
          >
            Ana Sayfaya Dön
          </Button>
        </div>
        <div className="mt-6 text-xs text-gray-500">
          <p>Sorun devam ederse, tarayıcı önbelleğinizi temizleyin (Ctrl+F5)</p>
        </div>
      </div>
    </div>
  );
}
`;

  fs.writeFileSync('client/src/components/AdminFallback.tsx', fallbackComponent);
  console.log('✅ Fallback admin component created\n');

  console.log('🎉 Admin Panel Fix Complete!\n');
  console.log('Next Steps:');
  console.log('1. Restart your application: pm2 restart kark-website');
  console.log('2. Clear browser cache (Ctrl+F5)');
  console.log('3. Try accessing admin panel again');
  console.log('4. Check browser console for errors');
  console.log('5. If still blank, access /admin/users directly');

} catch (error) {
  console.error('❌ Fix failed:', error.message);
  process.exit(1);
}