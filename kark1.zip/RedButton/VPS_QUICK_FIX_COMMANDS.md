# VPS Quick Fix Commands

## Problem: PM2 can't find ecosystem.production.cjs

**Solution:** Use the new JavaScript files instead of .cjs files

```bash
# 1. Stop all PM2 processes
pm2 stop all
pm2 delete all

# 2. Create missing directories
mkdir -p /var/www/kark/data/sessions
chmod 755 /var/www/kark/data/sessions

# 3. Use the JavaScript config file (not .cjs)
pm2 start ecosystem.production.js --env production

# 4. Save PM2 config
pm2 save

# 5. Check status
pm2 status

# 6. Test if app is running
curl http://localhost:5000/api/visitor-count
```

## Alternative: Use the automated script

```bash
# Make script executable
chmod +x vps-deploy-fix.sh

# Run the automated fix
./vps-deploy-fix.sh
```

## Files you need to copy to VPS:

1. `ecosystem.production.js` (not .cjs)
2. `ecosystem.config.js` (not .cjs)
3. `vps-deploy-fix.sh`
4. Make sure `data/sessions/` directory exists

## Key Changes Made:

- ✅ Created `ecosystem.production.js` (JavaScript instead of CommonJS)
- ✅ Created `ecosystem.config.js` (JavaScript instead of CommonJS)  
- ✅ Created `data/sessions/` directory
- ✅ Added comprehensive deployment script
- ✅ Your nginx config looks good - no changes needed there

## Expected PM2 Status After Fix:

```
┌────┬──────────────────┬─────────────┬─────────┬─────────┬──────────┬────────┬──────┬───────────┬──────────┬──────────┬──────────┬──────────┐
│ id │ name             │ namespace   │ version │ mode    │ pid      │ uptime │ ↺    │ status    │ cpu      │ mem      │ user     │ watching │
├────┼──────────────────┼─────────────┼─────────┼─────────┼──────────┼────────┼──────┼───────────┼──────────┼──────────┼──────────┼──────────┤
│ 0  │ kark-production  │ default     │ 1.0.0   │ fork    │ 12345    │ 10s    │ 0    │ online    │ 0%       │ 50.0mb   │ root     │ disabled │
└────┴──────────────────┴─────────────┴─────────┴─────────┴──────────┴────────┴──────┴───────────┴──────────┴──────────┴──────────┴──────────┘
```