#!/bin/bash

echo "🔧 KARK Website Complete VPS Fix"
echo "=================================="

# Navigate to application directory
cd /var/www/kark || exit 1

# 1. Stop all PM2 processes
echo "1. Stopping existing services..."
pm2 stop all 2>/dev/null || true
pm2 delete all 2>/dev/null || true

# 2. Install ALL dependencies including dev dependencies
echo "2. Installing all dependencies (including build tools)..."
npm install --production=false

# 3. Build the application
echo "3. Building application..."
npm run build

# 4. Create health check endpoint (CommonJS version)
echo "4. Adding health check endpoint..."
cat > add-health-check.cjs << 'EOF'
const fs = require('fs');
const path = require('path');

// Read the existing index.ts file
const indexPath = path.join(__dirname, 'server/index.ts');
const indexContent = fs.readFileSync(indexPath, 'utf8');

// Check if health endpoint already exists
if (!indexContent.includes('/api/health')) {
  // Find where to insert the health check route
  const insertPoint = indexContent.indexOf('app.use("/api", routes');
  
  if (insertPoint !== -1) {
    const healthRoute = `
  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV || 'production'
    });
  });

`;
    
    const newContent = 
      indexContent.slice(0, insertPoint) + 
      healthRoute + 
      indexContent.slice(insertPoint);
    
    fs.writeFileSync(indexPath, newContent);
    console.log('✓ Health check endpoint added successfully');
  }
} else {
  console.log('✓ Health check endpoint already exists');
}
EOF

# Run the health check script
node add-health-check.cjs

# 5. Rebuild after adding health check
echo "5. Rebuilding with health check..."
npm run build

# 6. Create PM2 ecosystem config
echo "6. Creating PM2 configuration..."
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: './dist/index.js',
    cwd: '/var/www/kark',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      HOST: '0.0.0.0',
      DATABASE_URL: process.env.DATABASE_URL,
      SESSION_SECRET: process.env.SESSION_SECRET || 'kark-session-secret-2025',
      FRONTEND_URL: 'https://kibrisaramakurtarma.org',
      CORS_ORIGIN: 'https://kibrisaramakurtarma.org'
    },
    error_file: '/var/www/kark/logs/err.log',
    out_file: '/var/www/kark/logs/out.log',
    log_file: '/var/www/kark/logs/combined.log',
    time: true
  }]
};
EOF

# 7. Create logs directory
echo "7. Creating logs directory..."
mkdir -p /var/www/kark/logs

# 8. Update NGINX configuration for Cloudflare
echo "8. Configuring NGINX..."
cat > /etc/nginx/sites-available/kark << 'EOF'
server {
    listen 80;
    listen [::]:80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;

    # Cloudflare real IP
    set_real_ip_from 173.245.48.0/20;
    set_real_ip_from 103.21.244.0/22;
    set_real_ip_from 103.22.200.0/22;
    set_real_ip_from 103.31.4.0/22;
    set_real_ip_from 141.101.64.0/18;
    set_real_ip_from 108.162.192.0/18;
    set_real_ip_from 190.93.240.0/20;
    set_real_ip_from 188.114.96.0/20;
    set_real_ip_from 197.234.240.0/22;
    set_real_ip_from 198.41.128.0/17;
    set_real_ip_from 162.158.0.0/15;
    set_real_ip_from 104.16.0.0/13;
    set_real_ip_from 104.24.0.0/14;
    set_real_ip_from 172.64.0.0/13;
    set_real_ip_from 131.0.72.0/22;
    set_real_ip_from 2400:cb00::/32;
    set_real_ip_from 2606:4700::/32;
    set_real_ip_from 2803:f800::/32;
    set_real_ip_from 2405:b500::/32;
    set_real_ip_from 2405:8100::/32;
    set_real_ip_from 2a06:98c0::/29;
    set_real_ip_from 2c0f:f248::/32;
    real_ip_header CF-Connecting-IP;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # Error pages
    error_page 502 503 504 /502.html;
    location = /502.html {
        root /var/www/kark/public;
        internal;
    }
}
EOF

# 9. Create error page
echo "9. Creating error page..."
cat > /var/www/kark/public/502.html << 'EOF'
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Geçici Bakım - KARK</title>
    <style>
        body { font-family: Arial; text-align: center; padding: 50px; background: #f5f5f5; }
        h1 { color: #dc2626; }
        .message { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="message">
        <h1>Site Geçici Olarak Bakımda</h1>
        <p>Kıbrıs Arama Kurtarma websitesi şu anda güncellenmektedir.</p>
        <p>Lütfen birkaç dakika sonra tekrar deneyin.</p>
    </div>
</body>
</html>
EOF

# 10. Test and reload NGINX
echo "10. Testing NGINX configuration..."
nginx -t && systemctl reload nginx

# 11. Start application with PM2
echo "11. Starting application..."
pm2 start ecosystem.config.cjs

# 12. Save PM2 configuration
pm2 save
pm2 startup systemd -u root --hp /root

# 13. Wait for application to start
echo "12. Waiting for application to start..."
sleep 5

# 14. Run diagnostic tests
echo "13. Running diagnostics..."
echo "===================="

# Check PM2 status
echo "PM2 Status:"
pm2 status

# Test health endpoint
echo -e "\nHealth Check:"
curl -s http://localhost:5000/api/health || echo "Health check failed"

# Check logs
echo -e "\nRecent logs:"
pm2 logs --lines 10 --nostream

# Test a few endpoints
echo -e "\nAPI Tests:"
echo "- Visitor count: $(curl -s http://localhost:5000/api/visitor-count | head -c 50)"
echo "- Team: $(curl -s http://localhost:5000/api/team | head -c 50)"
echo "- Settings: $(curl -s http://localhost:5000/api/settings | head -c 50)"

echo -e "\n✅ Deployment complete!"
echo "Check your website at: https://kibrisaramakurtarma.org"
echo ""
echo "Troubleshooting commands:"
echo "- View logs: pm2 logs"
echo "- Check status: pm2 status"
echo "- Restart: pm2 restart all"
echo "- NGINX logs: tail -f /var/log/nginx/error.log"