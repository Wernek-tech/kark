#!/bin/bash

# VPS 502 Error Diagnosis Script for KARK Website
echo "🔍 KARK Website VPS 502 Error Diagnosis"
echo "======================================="

# Basic system info
echo "System Information:"
echo "- OS: $(cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2)"
echo "- Node: $(node --version 2>/dev/null || echo 'NOT INSTALLED')"
echo "- NPM: $(npm --version 2>/dev/null || echo 'NOT INSTALLED')"
echo "- PM2: $(pm2 --version 2>/dev/null || echo 'NOT INSTALLED')"
echo ""

# Check if in correct directory
echo "Directory Check:"
if [ ! -f "package.json" ]; then
    echo "❌ package.json not found in current directory"
    echo "📍 Current directory: $(pwd)"
    echo "🔧 Fix: cd /var/www/kark"
    exit 1
else
    echo "✅ Found package.json in $(pwd)"
fi
echo ""

# Check build status
echo "Build Status:"
if [ -f "dist/index.js" ]; then
    echo "✅ Built application found"
    echo "📁 Build file: $(ls -la dist/index.js)"
else
    echo "❌ No built application found"
    echo "🔧 Fix: npm run build"
fi
echo ""

# Check PM2 status
echo "PM2 Status:"
if command -v pm2 &> /dev/null; then
    pm2 list 2>/dev/null
    if pm2 list 2>/dev/null | grep -q "online"; then
        echo "✅ PM2 processes are running"
    else
        echo "❌ No PM2 processes are online"
        echo "🔧 Fix: pm2 start your-app"
    fi
else
    echo "❌ PM2 not installed"
    echo "🔧 Fix: sudo npm install -g pm2"
fi
echo ""

# Check port 5000
echo "Port 5000 Status:"
if netstat -tlnp 2>/dev/null | grep -q ":5000"; then
    echo "✅ Port 5000 is in use"
    netstat -tlnp 2>/dev/null | grep ":5000"
else
    echo "❌ Port 5000 is not in use"
    echo "🔧 Fix: Start your application on port 5000"
fi
echo ""

# Test local connection
echo "Local Connection Test:"
if curl -s --connect-timeout 5 http://localhost:5000/health &>/dev/null; then
    echo "✅ Local connection successful"
    echo "Response: $(curl -s http://localhost:5000/health)"
else
    echo "❌ Local connection failed"
    echo "🔧 Fix: Check if application is running and listening on port 5000"
fi
echo ""

# NGINX status
echo "NGINX Status:"
if command -v nginx &> /dev/null; then
    if systemctl is-active --quiet nginx; then
        echo "✅ NGINX is running"
    else
        echo "❌ NGINX is not running"
        echo "🔧 Fix: sudo systemctl start nginx"
    fi
    
    # Check configuration
    if nginx -t &>/dev/null; then
        echo "✅ NGINX configuration is valid"
    else
        echo "❌ NGINX configuration has errors"
        echo "🔧 Fix: sudo nginx -t"
    fi
    
    # Check site configuration
    if [ -f "/etc/nginx/sites-available/kark" ]; then
        echo "✅ KARK site configuration exists"
    else
        echo "❌ KARK site configuration missing"
        echo "🔧 Fix: Create /etc/nginx/sites-available/kark"
    fi
    
    if [ -L "/etc/nginx/sites-enabled/kark" ]; then
        echo "✅ KARK site is enabled"
    else
        echo "❌ KARK site is not enabled"
        echo "🔧 Fix: sudo ln -s /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/"
    fi
else
    echo "❌ NGINX not installed"
    echo "🔧 Fix: sudo apt install nginx"
fi
echo ""

# Check logs
echo "Recent Logs:"
echo "PM2 Logs (last 10 lines):"
pm2 logs --lines 10 2>/dev/null || echo "No PM2 logs available"
echo ""

echo "NGINX Error Logs (last 10 lines):"
sudo tail -n 10 /var/log/nginx/error.log 2>/dev/null || echo "No NGINX error logs available"
echo ""

# Check firewall
echo "Firewall Status:"
if command -v ufw &> /dev/null; then
    if ufw status | grep -q "Status: active"; then
        echo "✅ UFW is active"
        echo "Ports 80 and 443 status:"
        ufw status | grep -E "(80|443)" || echo "Ports 80/443 not explicitly allowed"
    else
        echo "ℹ️ UFW is inactive"
    fi
else
    echo "ℹ️ UFW not installed"
fi
echo ""

# SSL Certificate check
echo "SSL Certificate Status:"
if [ -f "/etc/letsencrypt/live/kibrisaramakurtarma.org/fullchain.pem" ]; then
    echo "✅ SSL certificate found"
    echo "Certificate expires: $(openssl x509 -enddate -noout -in /etc/letsencrypt/live/kibrisaramakurtarma.org/fullchain.pem 2>/dev/null | cut -d= -f2)"
else
    echo "❌ SSL certificate not found"
    echo "🔧 Fix: sudo certbot --nginx -d kibrisaramakurtarma.org -d www.kibrisaramakurtarma.org"
fi
echo ""

# Common 502 causes summary
echo "📋 Common 502 Error Causes:"
echo "1. Application not running (check PM2 status)"
echo "2. Application not listening on correct port (check port 5000)"
echo "3. NGINX configuration pointing to wrong upstream (check proxy_pass)"
echo "4. Application crashed (check PM2 logs)"
echo "5. Firewall blocking internal connections"
echo "6. SSL certificate issues"
echo ""

echo "🔧 Quick Fix Steps:"
echo "1. pm2 restart all"
echo "2. sudo systemctl restart nginx"
echo "3. Check: curl http://localhost:5000/health"
echo "4. Check: sudo nginx -t"
echo "5. Check logs: pm2 logs"
echo ""

echo "📞 If issues persist, run: bash vps-quick-502-fix.sh"