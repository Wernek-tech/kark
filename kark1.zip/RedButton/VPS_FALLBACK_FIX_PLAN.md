# VPS Fallback Fix Plan for KARK Website

## Problem Analysis
- VPS showing 502 errors
- Website falling back to fallback page
- APIs and JSON data need verification

## Phase 1: API and JSON Verification

### 1.1 Check All JSON Data Files
- [ ] Verify all data/*.json files are valid JSON
- [ ] Check file permissions (should be readable)
- [ ] Validate data integrity

### 1.2 API Endpoint Testing
- [ ] Test all GET endpoints
- [ ] Test all POST endpoints
- [ ] Check authentication endpoints
- [ ] Verify CORS headers

### 1.3 JSON Storage Path Verification
- [ ] Ensure JSON files are accessible from server
- [ ] Check relative paths in server code
- [ ] Verify file permissions

## Phase 2: Build and Deployment Issues

### 2.1 Build Process
- [ ] Verify production build completes
- [ ] Check if dist folder contains all files
- [ ] Ensure client build is included

### 2.2 Path Issues
- [ ] Check static file serving paths
- [ ] Verify API route prefixes
- [ ] Ensure client/server paths align

## Phase 3: VPS Configuration Fix

### 3.1 PM2 Configuration
- [ ] Use correct script path
- [ ] Set environment variables properly
- [ ] Configure logging paths

### 3.2 NGINX Configuration
- [ ] Fix proxy_pass settings
- [ ] Add proper headers
- [ ] Configure timeouts
- [ ] Add fallback handling

### 3.3 SSL and Domain
- [ ] Verify SSL certificates
- [ ] Check domain configuration
- [ ] Test HTTPS redirect

## Phase 4: Fallback Prevention

### 4.1 Error Handling
- [ ] Add health check endpoint
- [ ] Configure proper error pages
- [ ] Implement graceful degradation

### 4.2 Static File Serving
- [ ] Ensure index.html is served correctly
- [ ] Configure SPA routing fallback
- [ ] Add cache headers

## Implementation Steps

1. **Local Testing**
   - Run full build
   - Test all APIs locally
   - Verify JSON data loading

2. **VPS Preparation**
   - Update deployment scripts
   - Fix configuration files
   - Add monitoring

3. **Deployment**
   - Deploy with new configuration
   - Test incrementally
   - Monitor logs

4. **Verification**
   - Test all endpoints
   - Check for 502 errors
   - Verify no fallback