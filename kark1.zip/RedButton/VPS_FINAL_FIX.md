# VPS Final Fix - Solves the Build Issue

## Problem Identified
The build is failing because esbuild is trying to bundle Vite development dependencies into the production server, creating a corrupted `dist/index.js` file.

## Root Cause
- `server/index.ts` imports `server/vite.ts` which has Vite dependencies
- These Vite imports get bundled into production, causing `(void 0) is not a function` error
- Production should not include any Vite dependencies

## Solution
Created a clean production server (`server/index-production.ts`) that excludes all Vite dependencies.

## Quick Fix Commands (Run on VPS)

### Option 1: Automated Fix
```bash
cd /var/www/kark
chmod +x vps-production-build-fix.sh
./vps-production-build-fix.sh
```

### Option 2: Manual Fix
```bash
cd /var/www/kark

# Stop PM2
pm2 stop all && pm2 delete all

# Clean build
rm -rf dist/

# Install dependencies
npm install

# Build frontend
npx vite build

# Build clean production server (no Vite dependencies)
npx esbuild server/index-production.ts \
  --platform=node \
  --packages=external \
  --bundle \
  --format=esm \
  --outfile=dist/server.js \
  --external:vite

# Test the clean server
node dist/server.js &
sleep 3
curl http://localhost:5000/api/visitor-count
pkill node

# Start with clean PM2 config
pm2 start ecosystem.production-clean.js
pm2 save

# Restart nginx
systemctl restart nginx
```

## Files to Upload
1. `server/index-production.ts` - Clean production server (no Vite)
2. `vps-production-build-fix.sh` - Automated fix script
3. `ecosystem.production-clean.js` - Will be created by the script

## Key Changes

### Before (Broken)
- Server imports Vite development tools
- esbuild tries to bundle Vite into production
- Results in corrupted build with `(void 0)` errors

### After (Fixed)
- Clean production server with no Vite dependencies
- Separate build process for frontend and backend
- Production server serves static files directly

## Expected Result
```bash
pm2 status
# Shows: kark-production | online

curl http://localhost:5000/api/visitor-count
# Returns: {"count":1}

# Website accessible at: http://kibrisaramakurtarma.org
```

This approach completely eliminates the Vite dependency issue by using a separate production server entry point.