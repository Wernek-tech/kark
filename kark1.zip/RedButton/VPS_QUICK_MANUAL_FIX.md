# VPS Quick Manual Fix

## Problem Identified
Your VPS is trying to run development mode instead of production build, causing the Vite config import error.

## Root Cause
- PM2 is running `npm start` which expects `dist/index.js` to exist
- The `dist/index.js` file is missing or corrupted
- Vite dependencies are not installed on VPS (they're dev dependencies)

## Quick Fix (Run these commands on your VPS)

### Option 1: Automated Fix
```bash
cd /var/www/kark
chmod +x vps-production-fix.sh
./vps-production-fix.sh
```

### Option 2: Manual Fix (Step by step)
```bash
# 1. Stop PM2
pm2 stop all && pm2 delete all

# 2. Install build dependencies
npm install --save-dev vite esbuild tsx typescript

# 3. Build the project
npm run build

# 4. Verify build exists
ls -la dist/index.js

# 5. Test the built app
node dist/index.js &
sleep 3
curl http://localhost:5000/api/visitor-count
pkill node

# 6. Use direct node execution (not npm scripts)
pm2 start ecosystem.vps-production.js

# 7. Save and setup startup
pm2 save
pm2 startup

# 8. Restart nginx
systemctl restart nginx
```

## Key Changes Made

### 1. Fixed PM2 Configuration
Instead of:
```javascript
script: 'npm',
args: 'start',
```

Now uses:
```javascript
script: 'node',
args: 'dist/index.js',
```

### 2. Direct Node Execution
- No longer relies on npm scripts
- Directly runs the built JavaScript file
- Avoids TypeScript/Vite import issues

### 3. Proper Build Process
- Ensures `dist/index.js` exists before running
- Installs build dependencies temporarily
- Removes dev dependencies after build

## Expected Result
After running the fix:
```bash
pm2 status
# Should show: kark-production | online

curl http://localhost:5000/api/visitor-count
# Should return: {"count":1}
```

## Files to Upload to VPS
1. `ecosystem.vps-production.js`
2. `vps-production-fix.sh`

## Why This Fixes the Issue
- The error was caused by trying to import `vite.config.ts` in production
- Production should run the built `dist/index.js` file, not TypeScript source
- The new config bypasses npm scripts and runs Node.js directly
- This eliminates the Vite dependency issue entirely