#!/bin/bash

# KARK VPS Complete Deployment Fix
# This script fixes all differences between Replit and VPS environments

echo "=== KARK VPS Complete Deployment Fix ==="
echo "Fixing authentication, sessions, and server binding..."

# Step 1: Stop everything
pm2 stop all
pm2 delete all
pm2 flush
pkill -f "node|tsx" || true

# Step 2: Fix server binding issue
echo "Fixing server binding for VPS..."

# Update the server/index.ts to work on VPS
cp server/index.ts server/index.ts.backup

# Fix the Windows-specific binding
cat > server/index.ts << 'EOF'
import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { adminActionLogger } from "./admin-logger";
import { applySecurityMiddleware } from "./middleware/security";
import path from "path";

const app = express();

// CRITICAL: Set trust proxy BEFORE any middleware
app.set("trust proxy", 1);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Apply security middleware
applySecurityMiddleware(app);

// Add admin action logger middleware
app.use(adminActionLogger);

// Serve static files from public directory
app.use(express.static(path.join(process.cwd(), 'public')));

// Special handler for the jumpscare video with explicit MIME type
app.get('/xoxoxo.mp4', (req, res) => {
  const videoPath = path.resolve(process.cwd(), 'xoxoxo.mp4');
  res.setHeader('Content-Type', 'video/mp4');
  res.sendFile(videoPath);
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // Setup vite or static serving
  if (app.get("env") === "development" && process.env.NODE_ENV !== "production") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const PORT = parseInt(process.env.PORT || "5000", 10);
  const HOST = process.env.HOST || "0.0.0.0";
  
  // VPS-compatible server binding
  server.listen(PORT, HOST, () => {
    log(`🚀 KARK Server running on http://${HOST}:${PORT}`);
    log(`Environment: ${process.env.NODE_ENV}`);
    log(`Trust Proxy: ${app.get('trust proxy')}`);
  });
})();
EOF

# Step 3: Create proper environment file
cat > .env << 'EOF'
NODE_ENV=production
PORT=5000
HOST=0.0.0.0
DB_TYPE=json
SESSION_SECRET=kark-vps-kibris-secure-2025
TRUST_PROXY=true
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
COOKIE_HTTP_ONLY=true
EOF

# Step 4: Create PM2 configuration
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_memory_restart: '500M',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      HOST: '0.0.0.0',
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-kibris-secure-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    },
    error_file: './logs/error.log',
    out_file: './logs/output.log',
    time: true
  }]
}
EOF

# Step 5: Prepare directories
rm -rf data/sessions
mkdir -p data/sessions logs
chmod -R 755 data logs

# Step 6: Configure firewall
if command -v ufw >/dev/null 2>&1; then
    ufw allow 5000/tcp
    ufw allow 80/tcp
    ufw allow 443/tcp
fi

# Step 7: Start PM2
pm2 start ecosystem.config.cjs

# Step 8: Save PM2 configuration
pm2 save
pm2 startup systemd -u $USER --hp $HOME

# Step 9: Wait and verify
sleep 5
echo ""
echo "=== Verification ==="
pm2 status
echo ""
echo "Testing local connection..."
curl -s http://localhost:5000 | head -3
echo ""
echo "=== Deployment Complete ==="
echo "Your KARK website is now running on VPS!"
echo "Access at: http://$(curl -s ifconfig.me):5000"
echo "Admin panel: http://$(curl -s ifconfig.me):5000/admin"