#!/bin/bash

# KARK VPS Deployment Fix Script
# This script fixes common deployment issues on VPS

echo "🚀 Starting KARK VPS Deployment Fix..."

# 1. Create necessary directories
echo "📁 Creating necessary directories..."
mkdir -p /var/www/kark/data/sessions
mkdir -p /var/log/pm2
chmod 755 /var/www/kark/data/sessions
chmod 755 /var/log/pm2

# 2. Stop all PM2 processes
echo "🛑 Stopping all PM2 processes..."
pm2 stop all
pm2 delete all

# 3. Build the project
echo "🔨 Building the project..."
cd /var/www/kark
npm run build

# 4. Start PM2 with the correct JavaScript config
echo "🚀 Starting PM2 with ecosystem.production.js..."
pm2 start ecosystem.production.js --env production

# 5. Save PM2 configuration
echo "💾 Saving PM2 configuration..."
pm2 save

# 6. Setup PM2 startup script
echo "🔄 Setting up PM2 startup script..."
pm2 startup

# 7. Check PM2 status
echo "📊 Checking PM2 status..."
pm2 status

# 8. Check if app is responding
echo "🔍 Testing if app is responding..."
sleep 3
curl -s http://localhost:5000/api/visitor-count || echo "❌ App not responding on port 5000"

# 9. Restart nginx
echo "🔄 Restarting nginx..."
systemctl restart nginx

# 10. Check nginx status
echo "📊 Checking nginx status..."
systemctl status nginx --no-pager

# 11. Show recent logs
echo "📋 Recent PM2 logs:"
pm2 logs --lines 10

echo "✅ VPS deployment fix completed!"
echo "🌐 Your website should now be accessible at http://kibrisaramakurtarma.org"