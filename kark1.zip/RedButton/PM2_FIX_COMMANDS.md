# Fix PM2 Configuration and Start KARK Website

## The Problem
Your ecosystem.config.js file has ES module syntax issues with PM2. 

## Quick Fix Commands

Run these on your server:

```bash
cd /var/www/kark

# Option 1: Use the .cjs extension file (recommended)
pm2 start ecosystem.config.cjs

# Option 2: Start directly with npm
pm2 start npm --name "kark-website" -- start

# Option 3: Start the server file directly
pm2 start server/index.ts --name "kark-website" --interpreter tsx

# Save PM2 configuration
pm2 save

# Set PM2 to start on boot
pm2 startup systemd

# Check status
pm2 status

# View logs
pm2 logs kark-website
```

## Test Your Application

```bash
# Test if KARK app is running locally
curl http://localhost:5000

# Test nginx proxy
curl -H "Host: kibrisaramakurtarma.org" http://localhost

# Check PM2 process
pm2 monit
```

## If Still Having Issues

Try starting manually first:

```bash
cd /var/www/kark

# Start manually to check for errors
npm start

# If that works, then try PM2 again
pm2 start npm --name "kark-website" -- start
pm2 save
```

The .cjs extension file should work with PM2 regardless of your package.json type setting.