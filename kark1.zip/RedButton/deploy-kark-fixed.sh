#!/bin/bash

# KARK Website Complete Deployment Script - FIXED VERSION
# For: kibrisaramakurtarma.org
# Server: 193.31.31.171

set -e  # Exit on any error

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date +'%H:%M:%S')]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
    exit 1
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    error "This script must be run as root (use sudo)"
fi

log "🚀 Starting KARK Website Deployment for kibrisaramakurtarma.org"

# Step 1: Clean up any broken configurations
log "🧹 Cleaning up existing configurations..."
rm -f /etc/nginx/sites-enabled/kibrisaramakurtarma
rm -f /etc/nginx/sites-available/kibrisaramakurtarma
rm -f /etc/nginx/sites-enabled/default

# Step 2: Install required software
log "📦 Installing required software..."
apt update && apt upgrade -y
apt install nginx certbot python3-certbot-nginx ufw -y

# Install Node.js if not present
if ! command -v node &> /dev/null; then
    log "📦 Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi

# Install PM2 if not present
if ! command -v pm2 &> /dev/null; then
    log "📦 Installing PM2..."
    npm install -g pm2
fi

# Step 3: Set up KARK application
log "⚙️ Setting up KARK application..."
cd /var/www/kark

# Check if package.json exists
if [ ! -f "package.json" ]; then
    error "package.json not found in /var/www/kark. Make sure your KARK files are in the correct location."
fi

# Install dependencies and build
log "📦 Installing dependencies..."
npm install

log "🔨 Building application..."
npm run build

# Step 4: Set up HTTP-only nginx configuration
log "🌐 Setting up nginx configuration (HTTP only)..."
if [ ! -f "nginx-http-only.conf" ]; then
    error "nginx-http-only.conf not found. Make sure all deployment files are uploaded."
fi

cp nginx-http-only.conf /etc/nginx/sites-available/kibrisaramakurtarma
ln -s /etc/nginx/sites-available/kibrisaramakurtarma /etc/nginx/sites-enabled/

# Test nginx configuration
log "🧪 Testing nginx configuration..."
if ! nginx -t; then
    error "Nginx configuration test failed"
fi

# Start nginx
log "🔄 Starting nginx..."
systemctl restart nginx
systemctl enable nginx

# Step 5: Start KARK application
log "🚀 Starting KARK application..."
if [ ! -f "ecosystem.config.js" ]; then
    warning "ecosystem.config.js not found, creating basic PM2 config..."
    cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'npm',
    args: 'start',
    cwd: '/var/www/kark',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json'
    }
  }]
}
EOF
fi

# Stop any existing PM2 processes
pm2 delete kark-website 2>/dev/null || true

# Start with PM2
pm2 start ecosystem.config.js
pm2 save

# Set PM2 to start on boot
log "⚡ Configuring PM2 startup..."
pm2 startup systemd --silent

# Step 6: Configure firewall
log "🔒 Configuring firewall..."
ufw allow ssh
ufw allow 'Nginx Full'
ufw --force enable

# Step 7: Test HTTP access
log "🧪 Testing HTTP access..."
sleep 5  # Give services time to start

if curl -f http://localhost:5000 > /dev/null 2>&1; then
    log "✅ KARK application is running on port 5000"
else
    error "❌ KARK application is not responding on port 5000"
fi

# Step 8: Get SSL certificates
log "🔐 Setting up SSL certificates..."
echo "📧 You will be prompted for email address and agreement to terms..."
echo "🔄 Choose option 2 (Redirect HTTP to HTTPS) when asked"
echo ""

if certbot --nginx -d kibrisaramakurtarma.org -d www.kibrisaramakurtarma.org; then
    log "✅ SSL certificates installed successfully"
else
    warning "⚠️ SSL certificate installation failed. You can run it manually later:"
    echo "sudo certbot --nginx -d kibrisaramakurtarma.org -d www.kibrisaramakurtarma.org"
fi

# Step 9: Set correct permissions
log "🔐 Setting file permissions..."
chown -R www-data:www-data /var/www/kark
chmod -R 755 /var/www/kark
chmod -R 644 /var/www/kark/data/*.json 2>/dev/null || true

# Step 10: Final verification
log "🧪 Final verification..."
nginx -t
systemctl reload nginx

log "✅ Deployment completed successfully!"
echo ""
echo "🌐 Your KARK website should now be accessible at:"
echo "   https://kibrisaramakurtarma.org"
echo "   https://www.kibrisaramakurtarma.org"
echo ""
echo "🔧 Useful commands:"
echo "   pm2 status              - Check application status"
echo "   pm2 logs kark-website   - View application logs"
echo "   systemctl status nginx  - Check nginx status"
echo "   certbot renew          - Renew SSL certificates"
echo ""
echo "📊 Admin panel: https://kibrisaramakurtarma.org/admin"