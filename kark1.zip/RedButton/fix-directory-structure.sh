#!/bin/bash

# Fix KARK Website Directory Structure
# Current path: /var/www/kark/karksite/RedButtonSimulator
# Target path: /var/www/kark

echo "🔧 Fixing KARK website directory structure..."

# Navigate to the correct location
cd /var/www/kark

# Check if the nested structure exists
if [ -d "karksite/RedButtonSimulator" ]; then
    echo "✅ Found nested directory: karksite/RedButtonSimulator"
    
    # Create backup
    echo "📦 Creating backup..."
    cp -r karksite/RedButtonSimulator kark-backup-$(date +%Y%m%d-%H%M%S)
    
    # Move all files from nested directory to root
    echo "📁 Moving files to root directory..."
    mv karksite/RedButtonSimulator/* .
    mv karksite/RedButtonSimulator/.* . 2>/dev/null || true
    
    # Remove empty nested directories
    echo "🗑️ Cleaning up nested directories..."
    rm -rf karksite/
    
    echo "✅ Directory structure fixed!"
    
elif [ -d "RedButtonSimulator" ]; then
    echo "✅ Found RedButtonSimulator directory"
    
    # Move files from RedButtonSimulator to root
    echo "📁 Moving files to root directory..."
    mv RedButtonSimulator/* .
    mv RedButtonSimulator/.* . 2>/dev/null || true
    rm -rf RedButtonSimulator/
    
    echo "✅ Directory structure fixed!"
    
else
    echo "❌ Neither karksite/RedButtonSimulator nor RedButtonSimulator directory found"
    echo "📋 Current directory contents:"
    ls -la
    exit 1
fi

# Check if package.json exists
if [ -f "package.json" ]; then
    echo "✅ Found package.json"
    
    # Install dependencies
    echo "📦 Installing dependencies..."
    npm install
    
    # Build application
    echo "🔨 Building application..."
    npm run build
    
    echo "✅ Application built successfully!"
    
else
    echo "❌ package.json not found in root directory"
    echo "📋 Current directory contents:"
    ls -la
    exit 1
fi

# Set correct permissions
echo "🔐 Setting correct permissions..."
chown -R www-data:www-data /var/www/kark
chmod -R 755 /var/www/kark

echo ""
echo "🎉 KARK website directory structure fixed!"
echo "📁 All files are now in: /var/www/kark"
echo ""
echo "🚀 Next steps:"
echo "1. Start the application: pm2 start ecosystem.config.js"
echo "2. Save PM2 config: pm2 save"
echo "3. Check status: pm2 status"