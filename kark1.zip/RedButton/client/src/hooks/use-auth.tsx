import { createContext, ReactNode, useContext } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { User, LoginData, InsertUser } from "@shared/schema";
import { getQueryFn, apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type AuthContextType = {
  user: User | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<User, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<User, Error, InsertUser>;
};

export const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const {
    data: user,
    error,
    isLoading,
  } = useQuery<User | undefined, Error>({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      // Store the attempted username in sessionStorage temporarily so jumpscare page can access it
      if (credentials.username) {
        sessionStorage.setItem('attempted_username', credentials.username);
      }
      
      try {
        const res = await apiRequest("POST", "/api/login", credentials);
        
        // Check if this was a security alert (403 status)
        if (res.status === 403) {
          const data = await res.json();
          
          // If this was an unauthorized admin access attempt, redirect to jumpscare
          if (data.securityAlert) {
            window.location.href = '/security/alert';
            // Throw an error to stop the normal flow
            throw new Error('Security alert triggered');
          }
        }
        
        // If we got here, it's a normal response
        return await res.json();
      } catch (err: any) {
        // If this is our security alert error, re-throw it
        if (err.message === 'Security alert triggered') {
          throw err;
        }
        
        // For regular errors like 401, throw the error
        if (err.response) {
          const errorData = await err.response.json();
          throw new Error(errorData.message || 'Login failed');
        }
        
        throw err;
      }
    },
    onSuccess: (user: User) => {
      // Clear any stored attempted username
      sessionStorage.removeItem('attempted_username');
      
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Başarılı",
        description: "Giriş işlemi başarılı",
      });
    },
    onError: (error: Error) => {
      // Don't show error for security alerts
      if (error.message === 'Security alert triggered') {
        return;
      }
      
      toast({
        title: "Giriş başarısız",
        description: error.message || "Kullanıcı adı veya şifre hatalı",
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (userData: any) => {
      // Simplify and ensure all the fields are properly formatted
      const registerData = {
        username: userData.username,
        password: userData.password,
        firstName: userData.firstName,
        lastName: userData.lastName,
        email: userData.email,
        role: "user"
      };

      // Remove confirmPassword from the data sent to server
      if (userData.confirmPassword) {
        // Just verify here, don't send to server
        if (userData.password !== userData.confirmPassword) {
          throw new Error("Şifreler eşleşmiyor");
        }
      }
      
      try {
        const response = await fetch('/api/register', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(registerData),
          credentials: 'include'
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          console.error('Registration error:', errorData);
          throw new Error(errorData.message || 'Kayıt sırasında bir hata oluştu');
        }
        
        const data = await response.json();
        return data;
      } catch (err: any) {
        console.error('Registration error:', err);
        throw err;
      }
    },
    onSuccess: (user: User) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Başarılı",
        description: "Kayıt işlemi başarılı",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Kayıt başarısız",
        description: error.message || "Kayıt sırasında bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/logout");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/user"], null);
      toast({
        title: "Çıkış yapıldı",
        description: "Başarıyla çıkış yaptınız",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Çıkış başarısız",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
