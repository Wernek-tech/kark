import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Edit, Plus, Search, Image, Video, ImageIcon } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { formatDate } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";

const mediaSchema = z.object({
  title: z.string().min(1, "Başlık gereklidir"),
  description: z.string().optional(),
  mediaType: z.enum(["photo", "video"]),
  mediaUrl: z.string().url("Geçerli bir URL giriniz"),
  date: z.string().optional(),
});

type MediaFormData = z.infer<typeof mediaSchema>;

interface MediaItem {
  id: number;
  title: string;
  description?: string;
  mediaType: "photo" | "video";
  mediaUrl: string;
  date?: string;
  createdAt: string;
}

export default function AdminMediaPage() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingMedia, setEditingMedia] = useState<MediaItem | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTab, setSelectedTab] = useState<"all" | "photo" | "video">("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<MediaFormData>({
    resolver: zodResolver(mediaSchema),
    defaultValues: {
      title: "",
      description: "",
      mediaType: "photo",
      mediaUrl: "",
      date: new Date().toISOString().split("T")[0],
    },
  });

  const { data: mediaItems = [], isLoading } = useQuery<MediaItem[]>({
    queryKey: ["/api/admin/media"],
  });

  const { data: videos = [] } = useQuery({
    queryKey: ["/api/admin/videos"],
  });

  const { data: albums = [] } = useQuery({
    queryKey: ["/api/admin/albums"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: MediaFormData) => {
      const res = await apiRequest("POST", "/api/admin/media", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/media"] });
      toast({
        title: "Başarılı",
        description: "Medya içeriği başarıyla eklendi",
      });
      setIsOpen(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Medya içeriği eklenirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: MediaFormData }) => {
      const res = await apiRequest("PUT", `/api/admin/media/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/media"] });
      toast({
        title: "Başarılı",
        description: "Medya içeriği başarıyla güncellendi",
      });
      setIsOpen(false);
      setEditingMedia(null);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Medya içeriği güncellenirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/admin/media/${id}`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/media"] });
      toast({
        title: "Başarılı",
        description: "Medya içeriği başarıyla silindi",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Medya içeriği silinirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (editingMedia) {
      form.reset({
        title: editingMedia.title,
        description: editingMedia.description || "",
        mediaType: editingMedia.mediaType,
        mediaUrl: editingMedia.mediaUrl,
        date: editingMedia.date || new Date().toISOString().split("T")[0],
      });
    } else {
      form.reset({
        title: "",
        description: "",
        mediaType: "photo",
        mediaUrl: "",
        date: new Date().toISOString().split("T")[0],
      });
    }
  }, [editingMedia, form]);

  const handleSubmit = (data: MediaFormData) => {
    if (editingMedia) {
      updateMutation.mutate({ id: editingMedia.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filteredMedia = mediaItems.filter((item) => {
    const matchesSearch = 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (selectedTab === "all") return matchesSearch;
    return matchesSearch && item.mediaType === selectedTab;
  });

  const mediaType = form.watch("mediaType");

  if (isLoading) {
    return (
      <AdminLayout title="Medya Yönetimi">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-secondary"></div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Medya Yönetimi">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Medya ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Yeni Medya Ekle
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {editingMedia ? "Medya Düzenle" : "Yeni Medya Ekle"}
                </DialogTitle>
                <DialogDescription>
                  Medya içeriği bilgilerini girin
                </DialogDescription>
              </DialogHeader>
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(handleSubmit)}
                  className="space-y-4"
                >
                  <FormField
                    control={form.control}
                    name="mediaType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Medya Tipi</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Medya tipi seçin" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="photo">
                              <div className="flex items-center">
                                <ImageIcon className="w-4 h-4 mr-2" />
                                Fotoğraf
                              </div>
                            </SelectItem>
                            <SelectItem value="video">
                              <div className="flex items-center">
                                <Video className="w-4 h-4 mr-2" />
                                Video
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Başlık</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Medya başlığı" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Açıklama (Opsiyonel)</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="Medya açıklaması"
                            rows={3}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="mediaUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>
                          {mediaType === "video" ? "Video URL" : "Fotoğraf URL"}
                        </FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder={
                              mediaType === "video"
                                ? "https://www.youtube.com/watch?v=..."
                                : "https://example.com/foto.jpg"
                            }
                          />
                        </FormControl>
                        <FormMessage />
                        {mediaType === "video" && (
                          <p className="text-sm text-gray-500">
                            YouTube video URL'si veya direkt video bağlantısı girebilirsiniz
                          </p>
                        )}
                      </FormItem>
                    )}
                  />

                  {form.watch("mediaUrl") && (
                    <div className="mt-2 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
                      <p className="text-sm font-medium mb-2">Önizleme:</p>
                      <div className="aspect-video bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center">
                        {mediaType === "video" ? (
                          <Video className="w-12 h-12 text-gray-400" />
                        ) : (
                          <ImageIcon className="w-12 h-12 text-gray-400" />
                        )}
                      </div>
                    </div>
                  )}

                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tarih (Opsiyonel)</FormLabel>
                        <FormControl>
                          <Input {...field} type="date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <DialogFooter>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setIsOpen(false);
                        setEditingMedia(null);
                        form.reset();
                      }}
                    >
                      İptal
                    </Button>
                    <Button type="submit">
                      {editingMedia ? "Güncelle" : "Ekle"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as any)}>
          <TabsList>
            <TabsTrigger value="all">Tümü</TabsTrigger>
            <TabsTrigger value="photo">
              <ImageIcon className="w-4 h-4 mr-2" />
              Fotoğraflar
            </TabsTrigger>
            <TabsTrigger value="video">
              <Video className="w-4 h-4 mr-2" />
              Videolar
            </TabsTrigger>
          </TabsList>

          <TabsContent value={selectedTab} className="mt-6">
            {filteredMedia.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <div className="mb-4">
                    {selectedTab === "video" && <Video className="w-16 h-16 text-gray-400" />}
                    {selectedTab === "photo" && <ImageIcon className="w-16 h-16 text-gray-400" />}
                    {selectedTab === "all" && <Image className="w-16 h-16 text-gray-400" />}
                  </div>
                  <p className="text-gray-500 text-center">
                    {selectedTab === "all" && "Henüz medya içeriği eklenmemiş"}
                    {selectedTab === "video" && "Henüz video eklenmemiş"}
                    {selectedTab === "photo" && "Henüz fotoğraf eklenmemiş"}
                  </p>
                  <p className="text-sm text-gray-400 mt-2">
                    Yeni medya eklemek için yukarıdaki butonu kullanın
                  </p>
                </CardContent>
              </Card>
            ) : (
              <Table>
                <TableCaption>
                  Toplam {filteredMedia.length} medya içeriği
                </TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Başlık</TableHead>
                    <TableHead>Açıklama</TableHead>
                    <TableHead>Tip</TableHead>
                    <TableHead>Tarih</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMedia.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.title}</TableCell>
                      <TableCell>{item.description || "-"}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          {item.mediaType === "video" && <Video className="w-4 h-4 mr-2" />}
                          {item.mediaType === "photo" && <ImageIcon className="w-4 h-4 mr-2" />}
                          <span className="capitalize">
                            {item.mediaType === "video" && "Video"}
                            {item.mediaType === "photo" && "Fotoğraf"}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {item.date ? formatDate(item.date) : formatDate(item.createdAt)}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setEditingMedia(item);
                            setIsOpen(true);
                          }}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            if (confirm("Bu medya içeriğini silmek istediğinizden emin misiniz?")) {
                              deleteMutation.mutate(item.id);
                            }
                          }}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </TabsContent>
        </Tabs>

        {/* Albümler için ayrı bir bölüm */}
        <div className="mt-8 p-6 bg-gray-50 dark:bg-gray-900 rounded-lg">
          <h3 className="text-lg font-semibold mb-2">Albüm Yönetimi</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            Birden fazla fotoğraf içeren albümler için lütfen Albüm sayfasını kullanın. 
            Albümler oluşturulduktan sonra fotoğrafları albüme ekleyebilirsiniz.
          </p>
          <Button variant="outline" onClick={() => window.location.href = '/admin/albums'}>
            Albüm Yönetimine Git
          </Button>
        </div>
      </div>
    </AdminLayout>
  );
}