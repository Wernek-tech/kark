import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Plus, Edit, Trash2, Images, Calendar, X } from "lucide-react";
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

interface Album {
  id: number;
  title: string;
  description: string | null;
  cover_image_url: string | null;
  image_count: number;
  created_at: string;
  updated_at: string;
  createdAt?: string; // Alternative field name support
}

export default function AdminAlbums() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isPhotoDialogOpen, setIsPhotoDialogOpen] = useState(false);
  const [selectedAlbum, setSelectedAlbum] = useState<Album | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    cover_image_url: "",
  });
  const [albumPhotos, setAlbumPhotos] = useState<string[]>([]);
  const [newPhotoUrls, setNewPhotoUrls] = useState<string[]>([""]);
  
  // Functions to manage photo URLs
  const addPhotoUrl = () => {
    setNewPhotoUrls([...newPhotoUrls, ""]);
  };
  
  const removePhotoUrl = (index: number) => {
    setNewPhotoUrls(newPhotoUrls.filter((_, i) => i !== index));
  };
  
  const updatePhotoUrl = (index: number, value: string) => {
    const newUrls = [...newPhotoUrls];
    newUrls[index] = value;
    setNewPhotoUrls(newUrls);
  };

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: albums, isLoading } = useQuery<Album[]>({
    queryKey: ["/api/albums"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await fetch("/api/albums", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to create album");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/albums"] });
      toast({ title: "Albüm başarıyla oluşturuldu" });
      setIsCreateDialogOpen(false);
      resetForm();
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Albüm oluşturulurken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: typeof formData }) => {
      const response = await fetch(`/api/albums/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to update album");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/albums"] });
      toast({ title: "Albüm başarıyla güncellendi" });
      setIsEditDialogOpen(false);
      resetForm();
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Albüm güncellenirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/albums/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to delete album");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/albums"] });
      toast({ title: "Albüm başarıyla silindi" });
      setIsDeleteDialogOpen(false);
      setSelectedAlbum(null);
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Albüm silinirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const addPhotosMutation = useMutation({
    mutationFn: async ({ albumId, photoUrls }: { albumId: number; photoUrls: string[] }) => {
      const promises = photoUrls.map(async (url) => {
        const response = await fetch("/api/media", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: `Fotoğraf - ${selectedAlbum?.title}`,
            description: `${selectedAlbum?.title} albümünden fotoğraf`,
            mediaType: "photo",
            filePath: url,
            albumId: albumId,
          }),
          credentials: "include",
        });
        if (!response.ok) throw new Error("Failed to add photo");
        return response.json();
      });
      return Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/albums"] });
      queryClient.invalidateQueries({ queryKey: ["/api/media"] });
      toast({ title: "Fotoğraflar başarıyla eklendi" });
      setIsPhotoDialogOpen(false);
      setNewPhotoUrls([""]);
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: "Fotoğraflar eklenirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      cover_image_url: "",
    });
    setSelectedAlbum(null);
  };

  const handleCreate = () => {
    createMutation.mutate(formData);
  };

  const handleEdit = (album: Album) => {
    setSelectedAlbum(album);
    setFormData({
      title: album.title || "",
      description: album.description || "",
      cover_image_url: album.cover_image_url || "",
    });
    setIsEditDialogOpen(true);
  };

  const handleUpdate = () => {
    if (selectedAlbum) {
      updateMutation.mutate({ id: selectedAlbum.id, data: formData });
    }
  };

  const handleDelete = (album: Album) => {
    setSelectedAlbum(album);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (selectedAlbum) {
      deleteMutation.mutate(selectedAlbum.id);
    }
  };

  const handleSavePhotos = () => {
    if (!selectedAlbum) return;
    
    const validUrls = newPhotoUrls.filter(url => url.trim() !== "");
    if (validUrls.length > 0) {
      addPhotosMutation.mutate({ 
        albumId: selectedAlbum.id, 
        photoUrls: validUrls 
      });
    } else {
      toast({
        title: "Hata",
        description: "En az bir fotoğraf URL'si girmelisiniz",
        variant: "destructive",
      });
    }
  };

  return (
    <AdminLayout title="Fotoğraf Albümleri">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Fotoğraf Albümleri</h1>
            <p className="text-muted-foreground mt-2">
              Fotoğraf albümlerini yönetin
            </p>
          </div>
          <Button onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Yeni Albüm
          </Button>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Albümler</CardTitle>
              <CardDescription>
                Tüm fotoğraf albümlerini görüntüleyin ve yönetin
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Kapak</TableHead>
                    <TableHead>Başlık</TableHead>
                    <TableHead>Açıklama</TableHead>
                    <TableHead>Fotoğraf Sayısı</TableHead>
                    <TableHead>Oluşturulma</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {albums?.map((album) => (
                    <TableRow key={album.id}>
                      <TableCell>
                        {album.cover_image_url ? (
                          <img
                            src={album.cover_image_url}
                            alt={album.title}
                            className="w-16 h-16 object-cover rounded"
                          />
                        ) : (
                          <div className="w-16 h-16 bg-muted rounded flex items-center justify-center">
                            <Images className="h-6 w-6 text-muted-foreground" />
                          </div>
                        )}
                      </TableCell>
                      <TableCell className="font-medium">{album.title}</TableCell>
                      <TableCell>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {album.description}
                        </p>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{album.image_count || 0} Fotoğraf</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="h-4 w-4" />
                          {(() => {
                            try {
                              const dateValue = album.createdAt || album.created_at;
                              const date = new Date(dateValue);
                              if (isNaN(date.getTime())) {
                                return "Tarih belirtilmemiş";
                              }
                              return format(date, "d MMM yyyy", { locale: tr });
                            } catch (error) {
                              return "Geçersiz tarih";
                            }
                          })()}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setSelectedAlbum(album);
                              setIsPhotoDialogOpen(true);
                              setNewPhotoUrls([""]);
                            }}
                            title="Fotoğrafları Yönet"
                          >
                            <Images className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(album)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(album)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {/* Create Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Yeni Albüm Oluştur</DialogTitle>
              <DialogDescription>
                Yeni bir fotoğraf albümü oluşturun
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Başlık</Label>
                <Input
                  id="title"
                  value={formData.title || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                  placeholder="Albüm başlığı"
                />
              </div>
              <div>
                <Label htmlFor="description">Açıklama</Label>
                <Textarea
                  id="description"
                  value={formData.description || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  placeholder="Albüm açıklaması"
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="cover_image_url">Kapak Görseli URL</Label>
                <Input
                  id="cover_image_url"
                  value={formData.cover_image_url || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, cover_image_url: e.target.value })
                  }
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                İptal
              </Button>
              <Button onClick={handleCreate} disabled={createMutation.isPending}>
                {createMutation.isPending ? "Oluşturuluyor..." : "Oluştur"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Albümü Düzenle</DialogTitle>
              <DialogDescription>
                Albüm bilgilerini güncelleyin
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-title">Başlık</Label>
                <Input
                  id="edit-title"
                  value={formData.title || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                  placeholder="Albüm başlığı"
                />
              </div>
              <div>
                <Label htmlFor="edit-description">Açıklama</Label>
                <Textarea
                  id="edit-description"
                  value={formData.description || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  placeholder="Albüm açıklaması"
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="edit-cover_image_url">Kapak Görseli URL</Label>
                <Input
                  id="edit-cover_image_url"
                  value={formData.cover_image_url || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, cover_image_url: e.target.value })
                  }
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                İptal
              </Button>
              <Button onClick={handleUpdate} disabled={updateMutation.isPending}>
                {updateMutation.isPending ? "Güncelleniyor..." : "Güncelle"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Dialog */}
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Albümü Sil</AlertDialogTitle>
              <AlertDialogDescription>
                "{selectedAlbum?.title}" albümünü silmek istediğinize emin misiniz?
                Bu işlem geri alınamaz.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setIsDeleteDialogOpen(false)}>
                İptal
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={confirmDelete}
                className="bg-destructive hover:bg-destructive/90"
              >
                {deleteMutation.isPending ? "Siliniyor..." : "Sil"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Photo Management Dialog */}
        <Dialog open={isPhotoDialogOpen} onOpenChange={setIsPhotoDialogOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Fotoğrafları Yönet - {selectedAlbum?.title}</DialogTitle>
              <DialogDescription>
                Bu albüme fotoğraf URL'leri ekleyin
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Fotoğraf URL'leri</Label>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {newPhotoUrls.map((url, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        placeholder="https://example.com/photo.jpg"
                        value={url}
                        onChange={(e) => updatePhotoUrl(index, e.target.value)}
                      />
                      {newPhotoUrls.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removePhotoUrl(index)}
                        >
                          <X className="h-4 w-4 text-red-500" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addPhotoUrl}
                    className="w-full bg-red-500 text-white hover:bg-red-600 border-red-500"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Fotoğraf URL'si Ekle
                  </Button>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsPhotoDialogOpen(false)}>
                İptal
              </Button>
              <Button 
                onClick={handleSavePhotos}
                disabled={addPhotosMutation.isPending}
              >
                {addPhotosMutation.isPending ? "Kaydediliyor..." : "Kaydet"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}