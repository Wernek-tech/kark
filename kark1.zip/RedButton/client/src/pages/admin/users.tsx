import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import AdminLayout from "@/components/admin/AdminLayout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, UserX, Trash2, UserCheck, Shield } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

// User tipi
type User = {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  role: "major_admin" | "admin" | "user" | "banned";
  isAdmin: boolean;
  createdAt: string;
};

export default function AdminUsers() {
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const [userToBan, setUserToBan] = useState<User | null>(null);
  const [showBanDialog, setShowBanDialog] = useState(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [userToPromote, setUserToPromote] = useState<User | null>(null);
  const [showPromoteDialog, setShowPromoteDialog] = useState(false);
  const [selectedRole, setSelectedRole] = useState<"admin" | "major_admin">("admin");
  const [userToRevoke, setUserToRevoke] = useState<User | null>(null);
  const [showRevokeDialog, setShowRevokeDialog] = useState(false);

  // Kullanıcıları çek
  const { data: users = [], isLoading, isError } = useQuery<User[]>({
    queryKey: ["/api/users"],
    staleTime: 10000, // 10 saniye
  });

  // Kullanıcı banlama mutasyonu
  const banUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("POST", `/api/admin/ban-user/${userId}`);
    },
    onSuccess: () => {
      toast({
        title: "Kullanıcı banlandı",
        description: "Kullanıcı başarıyla banlandı.",
        variant: "default",
      });
      // Doğru query key ile önbelleği geçersiz kıl
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      // Oturum değişiklikleri için de önbelleği geçersiz kıl
      queryClient.invalidateQueries();
      setShowBanDialog(false);
      setUserToBan(null);
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: "Kullanıcı banlanırken bir hata oluştu: " + (error as Error).message,
        variant: "destructive",
      });
    },
  });
  
  // Kullanıcı yasağını kaldırma mutasyonu
  const unbanUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("POST", `/api/admin/unban-user/${userId}`);
    },
    onSuccess: () => {
      toast({
        title: "Yasak kaldırıldı",
        description: "Kullanıcı yasağı başarıyla kaldırıldı.",
        variant: "default",
      });
      // Doğru query key ile önbelleği geçersiz kıl
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      // Oturum değişiklikleri için de önbelleği geçersiz kıl
      queryClient.invalidateQueries();
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: "Kullanıcı yasağı kaldırılırken bir hata oluştu: " + (error as Error).message,
        variant: "destructive",
      });
    },
  });

  // Kullanıcı silme mutasyonu (sadece major_admin)
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("DELETE", `/api/admin/delete-user/${userId}`);
    },
    onSuccess: () => {
      toast({
        title: "Kullanıcı silindi",
        description: "Kullanıcı başarıyla silindi.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries();
      setShowDeleteDialog(false);
      setUserToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: "Kullanıcı silinirken bir hata oluştu: " + (error as Error).message,
        variant: "destructive",
      });
    },
  });

  // Admin izni verme mutasyonu (sadece major_admin)
  const grantAdminMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: "admin" | "major_admin" }) => {
      return await apiRequest("POST", `/api/admin/grant-admin/${userId}`, {
        role,
        permissions: role === "major_admin" 
          ? ["manage_users", "manage_events", "manage_media", "manage_team", "manage_donations", "manage_settings", "manage_sliders", "manage_admins", "all"]
          : ["manage_events", "manage_media", "manage_team"]
      });
    },
    onSuccess: () => {
      toast({
        title: "Admin izni verildi",
        description: "Kullanıcıya admin izinleri başarıyla verildi.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries();
      setShowPromoteDialog(false);
      setUserToPromote(null);
      setSelectedRole("admin");
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: "Admin izni verilirken bir hata oluştu: " + (error as Error).message,
        variant: "destructive",
      });
    },
  });

  // Admin yetkisi geri alma mutasyonu (sadece major_admin)
  const revokeAdminMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest("POST", `/api/admin/revoke-admin/${userId}`);
    },
    onSuccess: () => {
      toast({
        title: "Admin yetkisi geri alındı",
        description: "Kullanıcının admin yetkileri başarıyla geri alındı.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries();
      setShowRevokeDialog(false);
      setUserToRevoke(null);
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: "Admin yetkisi geri alınırken bir hata oluştu: " + (error as Error).message,
        variant: "destructive",
      });
    },
  });

  const handleBanUser = (user: User) => {
    setUserToBan(user);
    setShowBanDialog(true);
  };

  const confirmBanUser = () => {
    if (userToBan) {
      banUserMutation.mutate(userToBan.id.toString());
    }
  };

  const handleDeleteUser = (user: User) => {
    setUserToDelete(user);
    setShowDeleteDialog(true);
  };

  const confirmDeleteUser = () => {
    if (userToDelete) {
      deleteUserMutation.mutate(userToDelete.id.toString());
    }
  };

  const handlePromoteUser = (user: User) => {
    setUserToPromote(user);
    setSelectedRole("admin");
    setShowPromoteDialog(true);
  };

  const confirmPromoteUser = () => {
    if (userToPromote) {
      grantAdminMutation.mutate({
        userId: userToPromote.id.toString(),
        role: selectedRole
      });
    }
  };

  const handleRevokeAdmin = (user: User) => {
    setUserToRevoke(user);
    setShowRevokeDialog(true);
  };

  const confirmRevokeAdmin = () => {
    if (userToRevoke) {
      revokeAdminMutation.mutate(userToRevoke.id.toString());
    }
  };

  // Sadece major_admin kullanıcıların özel işlemleri görebilmesini kontrol et
  const isMajorAdmin = currentUser?.role === "major_admin";

  // Kullanıcı rolüne göre badge rengi
  const getRoleBadge = (role: string) => {
    switch (role) {
      case "major_admin":
        return <Badge className="bg-purple-600">Süper Yönetici</Badge>;
      case "admin":
        return <Badge className="bg-blue-600">Yönetici</Badge>;
      case "banned":
        return <Badge className="bg-red-600">Banlanmış</Badge>;
      default:
        return <Badge className="bg-green-600">Kullanıcı</Badge>;
    }
  };

  // Tarihi formatla
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("tr-TR", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <AdminLayout title="Kullanıcı Yönetimi">
      {/* Son Kayıt Olan Kullanıcılar */}
      <div className="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-sm border dark:border-gray-800 mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold dark:text-white">Son Kayıt Olan Kullanıcılar</h2>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center py-4">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
            <span className="ml-2">Yükleniyor...</span>
          </div>
        ) : isError ? (
          <div className="text-center py-4 text-red-600 dark:text-red-400">
            <p>Kullanıcılar yüklenirken bir hata oluştu.</p>
          </div>
        ) : (
          <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
            {users.slice(0, 6).map((user) => (
              <div 
                key={user.id} 
                className="p-4 border dark:border-gray-700 rounded-lg flex items-start space-x-3"
              >
                <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-lg font-semibold text-gray-700 dark:text-gray-200">
                  {user.firstName[0]}{user.lastName[0]}
                </div>
                <div className="flex-1">
                  <p className="font-medium">{user.firstName} {user.lastName}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{user.email}</p>
                  <div className="mt-1 flex items-center gap-2">
                    {getRoleBadge(user.role)}
                    <span className="text-xs text-gray-500">
                      {new Date(user.createdAt).toLocaleDateString("tr-TR")}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Tüm Kullanıcılar Tablosu */}
      <div className="bg-white dark:bg-gray-900 p-6 rounded-lg shadow-sm border dark:border-gray-800">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold dark:text-white">Tüm Kullanıcılar</h2>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2 text-lg">Kullanıcılar yükleniyor...</span>
          </div>
        ) : isError ? (
          <div className="text-center py-8 text-red-600 dark:text-red-400">
            <p>Kullanıcılar yüklenirken bir hata oluştu.</p>
            <Button
              onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] })}
              variant="outline"
              className="mt-2"
            >
              Tekrar dene
            </Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Kullanıcı Adı</TableHead>
                  <TableHead>İsim Soyisim</TableHead>
                  <TableHead>E-posta</TableHead>
                  <TableHead>Rol</TableHead>
                  <TableHead>Kayıt Tarihi</TableHead>
                  <TableHead>İşlemler</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.length > 0 ? (
                  users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.id}</TableCell>
                      <TableCell>{user.username}</TableCell>
                      <TableCell>
                        {user.firstName} {user.lastName}
                      </TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{getRoleBadge(user.role)}</TableCell>
                      <TableCell>{formatDate(user.createdAt)}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          {/* Ban/Unban actions */}
                          {user.role !== "major_admin" && user.role !== "banned" && (
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleBanUser(user)}
                              className="flex items-center"
                            >
                              <UserX className="h-4 w-4 mr-1" />
                              Banla
                            </Button>
                          )}
                          {user.role === "banned" && (
                            <>
                              <Badge variant="outline" className="text-red-500 border-red-500">
                                Banlanmış
                              </Badge>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => unbanUserMutation.mutate(user.id.toString())}
                                className="border-green-500 text-green-500 hover:bg-green-50 hover:text-green-600"
                                disabled={unbanUserMutation.isPending}
                              >
                                {unbanUserMutation.isPending ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  "Yasağı Kaldır"
                                )}
                              </Button>
                            </>
                          )}
                          
                          {/* Major Admin exclusive actions */}
                          {isMajorAdmin && user.role !== "major_admin" && currentUser?.id !== user.id && (
                            <>
                              {/* Grant Admin Permission - only for regular users */}
                              {user.role === "user" && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handlePromoteUser(user)}
                                  className="border-blue-500 text-blue-500 hover:bg-blue-50 hover:text-blue-600"
                                  disabled={grantAdminMutation.isPending}
                                >
                                  {grantAdminMutation.isPending ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <>
                                      <Shield className="h-4 w-4 mr-1" />
                                      Admin Yap
                                    </>
                                  )}
                                </Button>
                              )}
                              
                              {/* Revoke Admin Permission - only for admin users */}
                              {user.role === "admin" && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleRevokeAdmin(user)}
                                  className="border-orange-500 text-orange-500 hover:bg-orange-50 hover:text-orange-600"
                                  disabled={revokeAdminMutation.isPending}
                                >
                                  {revokeAdminMutation.isPending ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <>
                                      <UserX className="h-4 w-4 mr-1" />
                                      Yetkiyi Geri Al
                                    </>
                                  )}
                                </Button>
                              )}
                              
                              {/* Delete User - for non-major-admin users */}
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDeleteUser(user)}
                                className="border-red-500 text-red-500 hover:bg-red-50 hover:text-red-600"
                                disabled={deleteUserMutation.isPending}
                              >
                                {deleteUserMutation.isPending ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <>
                                    <Trash2 className="h-4 w-4 mr-1" />
                                    Sil
                                  </>
                                )}
                              </Button>
                            </>
                          )}
                          
                          {user.role === "major_admin" && (
                            <Badge variant="outline" className="text-purple-500 border-purple-500">
                              Süper Admin
                            </Badge>
                          )}
                          
                          {currentUser?.id === user.id && (
                            <Badge variant="outline" className="text-green-500 border-green-500">
                              Sen
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-4">
                      Hiç kullanıcı bulunamadı.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}

        {/* Banlama Onay Dialog */}
        <AlertDialog open={showBanDialog} onOpenChange={setShowBanDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Kullanıcı Banlama</AlertDialogTitle>
              <AlertDialogDescription>
                <span className="font-semibold text-red-600">
                  {userToBan?.firstName} {userToBan?.lastName}
                </span>{" "}
                adlı kullanıcıyı banlamak istediğinize emin misiniz? Bu işlem geri alınamaz.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={banUserMutation.isPending}>İptal</AlertDialogCancel>
              <AlertDialogAction
                onClick={confirmBanUser}
                disabled={banUserMutation.isPending}
                className="bg-red-600 hover:bg-red-700"
              >
                {banUserMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> İşlem yapılıyor...
                  </>
                ) : (
                  "Evet, Banla"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Kullanıcı Silme Onay Dialog */}
        <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Kullanıcı Silme</AlertDialogTitle>
              <AlertDialogDescription>
                <span className="font-semibold text-red-600">
                  {userToDelete?.firstName} {userToDelete?.lastName}
                </span>{" "}
                adlı kullanıcıyı kalıcı olarak silmek istediğinize emin misiniz? Bu işlem geri alınamaz ve kullanıcının tüm verileri silinecektir.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={deleteUserMutation.isPending}>İptal</AlertDialogCancel>
              <AlertDialogAction
                onClick={confirmDeleteUser}
                disabled={deleteUserMutation.isPending}
                className="bg-red-600 hover:bg-red-700"
              >
                {deleteUserMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Siliniyor...
                  </>
                ) : (
                  "Evet, Sil"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Admin İzni Verme Dialog */}
        <AlertDialog open={showPromoteDialog} onOpenChange={setShowPromoteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Admin İzni Verme</AlertDialogTitle>
              <AlertDialogDescription>
                <span className="font-semibold text-blue-600">
                  {userToPromote?.firstName} {userToPromote?.lastName}
                </span>{" "}
                adlı kullanıcıya admin izinleri vermek istediğinize emin misiniz?
                <div className="mt-4">
                  <label className="block text-sm font-medium mb-2">Admin Rolü Seçin:</label>
                  <Select value={selectedRole} onValueChange={(value: "admin" | "major_admin") => setSelectedRole(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Rol seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">
                        <div className="flex items-center">
                          <UserCheck className="h-4 w-4 mr-2 text-blue-500" />
                          <span>Yönetici (Admin) - Sınırlı yetkiler</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="major_admin">
                        <div className="flex items-center">
                          <Shield className="h-4 w-4 mr-2 text-purple-500" />
                          <span>Süper Yönetici (Major Admin) - Tam yetkiler</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <div className="mt-2 text-xs text-gray-500">
                    {selectedRole === "admin" ? 
                      "Etkinlik, medya ve takım yönetimi izinleri" : 
                      "Kullanıcı yönetimi dahil tüm izinler"}
                  </div>
                </div>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={grantAdminMutation.isPending}>İptal</AlertDialogCancel>
              <AlertDialogAction
                onClick={confirmPromoteUser}
                disabled={grantAdminMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {grantAdminMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> İşlem yapılıyor...
                  </>
                ) : (
                  "Evet, Admin Yap"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Admin Yetkisi Geri Alma Dialog */}
        <AlertDialog open={showRevokeDialog} onOpenChange={setShowRevokeDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Admin Yetkisi Geri Alma</AlertDialogTitle>
              <AlertDialogDescription>
                <span className="font-semibold text-orange-600">
                  {userToRevoke?.firstName} {userToRevoke?.lastName}
                </span>{" "}
                adlı kullanıcının admin yetkilerini geri almak istediğinize emin misiniz? Bu kullanıcı normal kullanıcı statüsüne dönecektir.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={revokeAdminMutation.isPending}>İptal</AlertDialogCancel>
              <AlertDialogAction
                onClick={confirmRevokeAdmin}
                disabled={revokeAdminMutation.isPending}
                className="bg-orange-600 hover:bg-orange-700"
              >
                {revokeAdminMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> İşlem yapılıyor...
                  </>
                ) : (
                  "Evet, Yetkiyi Geri Al"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AdminLayout>
  );
}