import { useEffect } from "react";
import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Radio, ExternalLink } from "lucide-react";

export default function AdminRadioLocation() {
  // Redirect immediately to the external URL
  useEffect(() => {
    window.open("http://8.222.164.17/TSM3/index.html", "_blank");
    // Optionally close the current tab/window after a delay
    // setTimeout(() => window.close(), 1000);
  }, []);

  const handleRedirect = () => {
    window.open("http://8.222.164.17/TSM3/index.html", "_blank");
  };

  return (
    <AdminLayout title="Telsiz Konum">
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Radio className="h-5 w-5" />
              Telsiz Konum Sistemi
            </CardTitle>
            <CardDescription>
              Telsiz konum tracking sistemine erişim için aşağıdaki butona tıklayın.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center space-y-4">
              <p className="text-gray-600 dark:text-gray-400">
                Sistem otomatik olarak yeni sekmede açılacaktır. Eğer açılmadıysa aşağıdaki butonu kullanın.
              </p>
              <Button 
                onClick={handleRedirect}
                className="bg-blue-600 hover:bg-blue-700 text-white"
                size="lg"
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Telsiz Konum Sistemine Git
              </Button>
              <div className="text-sm text-gray-500 dark:text-gray-400 mt-4">
                <p>URL: http://8.222.164.17/TSM3/index.html</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}