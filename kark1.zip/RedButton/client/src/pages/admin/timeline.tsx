import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Eye, EyeOff, Calendar, Type } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import { Card } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog';
import { Badge } from '../../components/ui/badge';

interface TimelineItem {
  id: number;
  year: number;
  title: string;
  description: string;
  itemType: string;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export default function TimelinePage() {
  const [timelineItems, setTimelineItems] = useState<TimelineItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<TimelineItem | null>(null);
  const [formData, setFormData] = useState({
    year: new Date().getFullYear(),
    title: '',
    description: '',
    itemType: 'milestone',
    isActive: true,
    sortOrder: 0
  });

  const itemTypes = [
    { value: 'milestone', label: 'Kilometre Taşı', color: 'bg-blue-100 text-blue-800' },
    { value: 'achievement', label: 'Başarı', color: 'bg-green-100 text-green-800' },
    { value: 'establishment', label: 'Kuruluş', color: 'bg-purple-100 text-purple-800' },
    { value: 'expansion', label: 'Genişleme', color: 'bg-orange-100 text-orange-800' },
    { value: 'partnership', label: 'İş Birliği', color: 'bg-indigo-100 text-indigo-800' },
  ];

  useEffect(() => {
    fetchTimelineItems();
  }, []);

  const fetchTimelineItems = async () => {
    try {
      const response = await fetch('/api/timeline');
      if (response.ok) {
        const data = await response.json();
        setTimelineItems(data);
      } else {
        console.error('Tarihçe öğeleri yüklenemedi');
      }
    } catch (error) {
      console.error('Tarihçe yükleme hatası:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const url = editingItem ? `/api/admin/timeline/${editingItem.id}` : '/api/admin/timeline';
      const method = editingItem ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        await fetchTimelineItems();
        setIsModalOpen(false);
        resetForm();
      } else {
        console.error('Kaydetme hatası');
      }
    } catch (error) {
      console.error('Kaydetme hatası:', error);
    }
  };

  const handleEdit = (item: TimelineItem) => {
    setEditingItem(item);
    setFormData({
      year: item.year,
      title: item.title,
      description: item.description,
      itemType: item.itemType,
      isActive: item.isActive,
      sortOrder: item.sortOrder
    });
    setIsModalOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (confirm('Bu tarihçe öğesini silmek istediğinizden emin misiniz?')) {
      try {
        const response = await fetch(`/api/admin/timeline/${id}`, {
          method: 'DELETE',
          credentials: 'include',
        });

        if (response.ok) {
          await fetchTimelineItems();
        } else {
          console.error('Silme hatası');
        }
      } catch (error) {
        console.error('Silme hatası:', error);
      }
    }
  };

  const toggleActive = async (id: number, isActive: boolean) => {
    try {
      const response = await fetch(`/api/admin/timeline/${id}/toggle-active`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ isActive: !isActive }),
      });

      if (response.ok) {
        await fetchTimelineItems();
      } else {
        console.error('Durum değiştirme hatası');
      }
    } catch (error) {
      console.error('Durum değiştirme hatası:', error);
    }
  };

  const resetForm = () => {
    setEditingItem(null);
    setFormData({
      year: new Date().getFullYear(),
      title: '',
      description: '',
      itemType: 'milestone',
      isActive: true,
      sortOrder: 0
    });
  };

  const getTypeInfo = (type: string) => {
    return itemTypes.find(t => t.value === type) || itemTypes[0];
  };

  if (loading) {
    return (
      <AdminLayout title="Tarihçe Yönetimi">
        <div className="flex justify-center items-center h-64">
          <div className="text-lg">Yükleniyor...</div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Tarihçe Yönetimi">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Tarihçe Yönetimi</h1>
            <p className="text-gray-600">Hakkımızda sayfasındaki tarihçe bölümünü yönetin</p>
          </div>
          <Button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2">
            <Plus size={20} />
            Yeni Tarihçe Öğesi
          </Button>
        </div>

        <div className="grid gap-4">
          {timelineItems.map((item) => {
            const typeInfo = getTypeInfo(item.itemType);
            return (
              <Card key={item.id} className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-2xl font-bold text-primary">{item.year}</span>
                      <Badge className={typeInfo.color}>{typeInfo.label}</Badge>
                      {!item.isActive && (
                        <Badge variant="secondary" className="bg-gray-100 text-gray-600">
                          Pasif
                        </Badge>
                      )}
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{item.description}</p>
                  </div>
                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toggleActive(item.id, item.isActive)}
                      className="flex items-center gap-1"
                    >
                      {item.isActive ? <EyeOff size={16} /> : <Eye size={16} />}
                      {item.isActive ? 'Gizle' : 'Göster'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(item)}
                      className="flex items-center gap-1"
                    >
                      <Edit2 size={16} />
                      Düzenle
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(item.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {timelineItems.length === 0 && (
          <Card className="p-8 text-center">
            <Calendar size={48} className="mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Henüz tarihçe öğesi yok</h3>
            <p className="text-gray-600 mb-4">İlk tarihçe öğenizi ekleyerek başlayın</p>
            <Button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2">
              <Plus size={20} />
              Tarihçe Öğesi Ekle
            </Button>
          </Card>
        )}

        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingItem ? 'Tarihçe Öğesini Düzenle' : 'Yeni Tarihçe Öğesi'}</DialogTitle>
              <DialogDescription>
                Hakkımızda sayfasında görünecek tarihçe öğesinin bilgilerini girin
              </DialogDescription>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Yıl *
                  </label>
                  <input
                    type="number"
                    min="1900"
                    max="2100"
                    required
                    value={formData.year}
                    onChange={(e) => setFormData({ ...formData, year: parseInt(e.target.value) })}
                    className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="2023"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tür *
                  </label>
                  <select
                    required
                    value={formData.itemType}
                    onChange={(e) => setFormData({ ...formData, itemType: e.target.value })}
                    className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    {itemTypes.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Başlık *
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="Örn: KARK'ın Kuruluşu"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Açıklama *
                </label>
                <textarea
                  required
                  rows={4}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                  placeholder="Bu tarihçe öğesinin detaylı açıklamasını yazın..."
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="isActive"
                  checked={formData.isActive}
                  onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                  className="w-4 h-4 text-primary bg-gray-100 border-gray-300 rounded focus:ring-primary"
                />
                <label htmlFor="isActive" className="text-sm font-medium text-gray-700">
                  Aktif (Hakkımızda sayfasında görünsün)
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsModalOpen(false);
                    resetForm();
                  }}
                >
                  İptal
                </Button>
                <Button type="submit">
                  {editingItem ? 'Güncelle' : 'Ekle'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}