import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import TeamCard from "@/components/team/TeamCard";
import { TeamMember } from "@shared/schema";
import { Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Helmet } from "react-helmet";

export default function TeamPage() {
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);
  const [isContactDialogOpen, setIsContactDialogOpen] = useState(false);

  const { data: teamMembers, isLoading } = useQuery<TeamMember[]>({
    queryKey: ["/api/team"],
  });

  const handleContactClick = (member: TeamMember) => {
    setSelectedMember(member);
    setIsContactDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsContactDialogOpen(false);
  };

  return (
    <>
      <Helmet>
        <title>Yönetim Kurulu | Etkinlik Platformu</title>
        <meta name="description" content="Organizasyonumuzu yöneten ekip üyeleri ile tanışın. Yönetim kurulu üyelerimiz ve uzmanlık alanları hakkında bilgi edinin." />
      </Helmet>
      
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <div className="flex justify-center">
              <h1 className="section-title">Yönetim Kurulu</h1>
            </div>
            <p className="section-description">Organizasyonumuzu yöneten ekip üyeleri</p>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-12 w-12 animate-spin text-secondary" />
            </div>
          ) : teamMembers && teamMembers.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {teamMembers.map((member) => (
                <TeamCard 
                  key={member.id} 
                  member={member} 
                  onContactClick={handleContactClick} 
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">Henüz yönetim kurulu üyesi bulunmuyor</p>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
      
      {/* Contact Dialog */}
      <Dialog open={isContactDialogOpen} onOpenChange={setIsContactDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>İletişim Bilgileri</DialogTitle>
            <DialogDescription>
              {selectedMember ? `${selectedMember.firstName} ${selectedMember.lastName} ile iletişime geçin` : ''}
            </DialogDescription>
          </DialogHeader>
          
          {selectedMember && (
            <div className="py-4">
              <div className="mb-4">
                <h4 className="font-medium text-sm text-gray-500">Pozisyon</h4>
                <p>{selectedMember.position}</p>
              </div>
              
              {selectedMember.email && (
                <div className="mb-4">
                  <h4 className="font-medium text-sm text-gray-500">E-posta</h4>
                  <a href={`mailto:${selectedMember.email}`} className="text-blue-600 hover:underline">
                    {selectedMember.email}
                  </a>
                </div>
              )}
              
              <div className="mb-4">
                <h4 className="font-medium text-sm text-gray-500">Uzmanlık Alanları</h4>
                <ul className="list-disc pl-5 mt-2">
                  {selectedMember.skills && selectedMember.skills.map((skill, index) => (
                    <li key={index}>{skill}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button onClick={handleCloseDialog}>Kapat</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
