import { Helmet } from "react-helmet-async";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

export default function KVKKPage() {
  return (
    <>
      <Helmet>
        <title>KVKK Aydınlatma Metni | KARK Arama Kurtarma</title>
        <meta name="description" content="KARK Arama Kurtarma Derneği KVKK kapsamında kişisel verilerin korunması ve işlenmesine ilişkin politikalar." />
      </Helmet>
      
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <div className="flex justify-center">
              <h1 className="section-title">KVKK Aydınlatma Metni</h1>
            </div>
            <p className="section-description">Kuzey Kıbrıs Türk Cumhuriyeti Kişisel Verilerin Korunması Hakkında Bilgilendirme</p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 mb-10 dark:shadow-blue-900/20">
            <h2 className="text-2xl font-bold mb-6 dark:text-white">1. Veri Sorumlusu ve Temsilcisi</h2>
            <p className="text-primary dark:text-gray-300 mb-4">
              6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") ve ilgili Kuzey Kıbrıs Türk Cumhuriyeti mevzuatı uyarınca, 
              kişisel verileriniz; veri sorumlusu olarak <strong>Kuzey Kıbrıs Arama Kurtarma Derneği (KARK)</strong> tarafından 
              aşağıda açıklanan kapsamda işlenebilecektir.
            </p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 mb-10 dark:shadow-blue-900/20">
            <h2 className="text-2xl font-bold mb-6 dark:text-white">2. Kişisel Verilerin İşlenme Amacı</h2>
            <p className="text-primary dark:text-gray-300 mb-4">
              Toplanan kişisel verileriniz, KVKK tarafından öngörülen temel ilkelere uygun olarak ve 
              veri işleme şartları kapsamında aşağıdaki amaçlarla işlenebilecektir:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-primary dark:text-gray-300">
              <li>Dernek üyelik işlemlerinin yürütülmesi,</li>
              <li>Gönüllülük başvurularının değerlendirilmesi ve yönetilmesi,</li>
              <li>Bağış ve yardım faaliyetlerinin organize edilmesi ve yürütülmesi,</li>
              <li>Etkinlik, eğitim ve operasyonların planlanması ve gerçekleştirilmesi,</li>
              <li>İletişim faaliyetlerinin yürütülmesi,</li>
              <li>Web sitesi üzerinden sağlanan hizmetlerin iyileştirilmesi,</li>
              <li>Yasal yükümlülüklerin yerine getirilmesi.</li>
            </ul>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 mb-10 dark:shadow-blue-900/20">
            <h2 className="text-2xl font-bold mb-6 dark:text-white">3. İşlenen Kişisel Veri Kategorileri</h2>
            <p className="text-primary dark:text-gray-300 mb-4">
              KARK tarafından işlenen başlıca kişisel veri kategorileri aşağıdaki gibidir:
            </p>
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                <thead>
                  <tr className="bg-gray-50 dark:bg-gray-700">
                    <th className="py-3 px-4 border-b border-gray-200 dark:border-gray-600 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Veri Kategorisi</th>
                    <th className="py-3 px-4 border-b border-gray-200 dark:border-gray-600 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">İçerik</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                  <tr>
                    <td className="py-4 px-4 text-sm text-gray-900 dark:text-gray-200">Kimlik Bilgileri</td>
                    <td className="py-4 px-4 text-sm text-gray-500 dark:text-gray-300">Ad, soyad, TC kimlik numarası/pasaport numarası, doğum tarihi vb.</td>
                  </tr>
                  <tr>
                    <td className="py-4 px-4 text-sm text-gray-900 dark:text-gray-200">İletişim Bilgileri</td>
                    <td className="py-4 px-4 text-sm text-gray-500 dark:text-gray-300">Telefon numarası, e-posta adresi, ikametgâh adresi vb.</td>
                  </tr>
                  <tr>
                    <td className="py-4 px-4 text-sm text-gray-900 dark:text-gray-200">Sağlık Bilgileri</td>
                    <td className="py-4 px-4 text-sm text-gray-500 dark:text-gray-300">Kan grubu, alerjiler, kronik hastalıklar vb. (sadece operasyonel gerekliliklerde)</td>
                  </tr>
                  <tr>
                    <td className="py-4 px-4 text-sm text-gray-900 dark:text-gray-200">Eğitim ve İş Bilgileri</td>
                    <td className="py-4 px-4 text-sm text-gray-500 dark:text-gray-300">Eğitim geçmişi, meslek, çalışma durumu vb.</td>
                  </tr>
                  <tr>
                    <td className="py-4 px-4 text-sm text-gray-900 dark:text-gray-200">Görsel ve İşitsel Veriler</td>
                    <td className="py-4 px-4 text-sm text-gray-500 dark:text-gray-300">Fotoğraflar, video kayıtları vb.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 mb-10 dark:shadow-blue-900/20">
            <h2 className="text-2xl font-bold mb-6 dark:text-white">4. Kişisel Verilerin Aktarılması</h2>
            <p className="text-primary dark:text-gray-300 mb-4">
              Kişisel verileriniz, KVKK ve yürürlükte olan diğer mevzuat kapsamında ve yukarıda belirtilen amaçlarla:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-primary dark:text-gray-300">
              <li>Kuzey Kıbrıs Türk Cumhuriyeti kanunlarında açıkça öngörülmesi halinde yasal düzenlemeler kapsamında talep edilmesi halinde kamu kurum ve kuruluşlarına,</li>
              <li>Afet ve acil durum hallerinde işbirliği yapılan diğer STK ve kamu kurumlarına,</li>
              <li>Gerekli durumlarda işbirliği içinde olduğumuz hizmet sağlayıcılara,</li>
              <li>Uluslararası operasyonlar kapsamında yurtdışındaki partner kuruluşlara</li>
            </ul>
            <p className="text-primary dark:text-gray-300 mt-4">
              aktarılabilecektir.
            </p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 mb-10 dark:shadow-blue-900/20">
            <h2 className="text-2xl font-bold mb-6 dark:text-white">5. Kişisel Veri Toplama Yöntemi ve Hukuki Sebebi</h2>
            <p className="text-primary dark:text-gray-300 mb-4">
              Kişisel verileriniz, elektronik veya fiziki ortamda:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-primary dark:text-gray-300 mb-4">
              <li>Web sitemizdeki formlar,</li>
              <li>E-posta, telefon ve diğer elektronik iletişim kanalları,</li>
              <li>Üyelik ve gönüllü başvuru formları,</li>
              <li>Etkinlik ve eğitim katılım kayıtları,</li>
              <li>Bağış işlemleri</li>
            </ul>
            <p className="text-primary dark:text-gray-300">
              aracılığıyla toplanmakta ve KVKK'nın 5. ve 6. maddelerinde belirtilen kişisel veri işleme şartları ve amaçları 
              kapsamında işlenmektedir.
            </p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 mb-10 dark:shadow-blue-900/20">
            <h2 className="text-2xl font-bold mb-6 dark:text-white">6. KVKK Kapsamında Haklarınız</h2>
            <p className="text-primary dark:text-gray-300 mb-4">
              KVKK'nın "İlgili Kişinin Hakları" başlıklı 11. maddesi kapsamında kişisel veri sahipleri olarak:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-primary dark:text-gray-300">
              <li>Kişisel verilerinizin işlenip işlenmediğini öğrenme,</li>
              <li>Kişisel verileriniz işlenmişse buna ilişkin bilgi talep etme,</li>
              <li>Kişisel verilerinizin işlenme amacını ve bunların amacına uygun kullanılıp kullanılmadığını öğrenme,</li>
              <li>Yurt içinde veya yurt dışında kişisel verilerinizin aktarıldığı üçüncü kişileri bilme,</li>
              <li>Kişisel verilerinizin eksik veya yanlış işlenmiş olması hâlinde bunların düzeltilmesini isteme,</li>
              <li>Kişisel verilerinizin silinmesini veya yok edilmesini isteme,</li>
              <li>Kişisel verilerinizin düzeltilmesi, silinmesi ya da yok edilmesi halinde bu işlemlerin kişisel verilerin aktarıldığı üçüncü kişilere bildirilmesini isteme,</li>
              <li>İşlenen verilerinizin münhasıran otomatik sistemler vasıtasıyla analiz edilmesi suretiyle kişinin kendisi aleyhine bir sonucun ortaya çıkmasına itiraz etme,</li>
              <li>Kişisel verilerinizin kanuna aykırı olarak işlenmesi sebebiyle zarara uğraması hâlinde zararın giderilmesini talep etme</li>
            </ul>
            <p className="text-primary dark:text-gray-300 mt-4">
              haklarına sahip olduğunuzu bildiririz.
            </p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 mb-10 dark:shadow-blue-900/20">
            <h2 className="text-2xl font-bold mb-6 dark:text-white">7. İletişim</h2>
            <p className="text-primary dark:text-gray-300 mb-4">
              KVKK kapsamındaki haklarınızı kullanmak, sorularınızı iletmek veya şikâyette bulunmak için aşağıdaki iletişim bilgileri üzerinden bize ulaşabilirsiniz:
            </p>
            <div className="space-y-3 text-primary dark:text-gray-300">
              <p><strong>KARK - Kuzey Kıbrıs Arama Kurtarma Derneği</strong></p>
              <p>Adres: Atatürk Bulvarı No:123 Kat:5 Merkez/Lefkoşa, KKTC</p>
              <p>Telefon: +90 392 123 45 67</p>
              <p>E-posta: kvkk@karkkktc.org</p>
            </div>
          </div>
          
          <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg text-sm text-primary dark:text-gray-300 mb-6">
            <p className="font-semibold mb-2">Son Güncelleme Tarihi: 16 Mayıs 2025</p>
            <p>
              KARK, işbu KVKK Aydınlatma Metni'ni yürürlükteki mevzuatta yapılabilecek değişiklikler çerçevesinde her zaman güncelleme hakkını saklı tutar.
              Güncellemeler derneğimizin web sitesinde yayınlanacaktır.
            </p>
          </div>
        </div>
      </main>
      
      <Footer />
    </>
  );
}