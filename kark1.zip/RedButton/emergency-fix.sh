#!/bin/bash

# Emergency Fix for KARK Website SSL Issue
# Run this on your server: sudo ./emergency-fix.sh

echo "🚨 Emergency Fix: Removing SSL references from nginx..."

# Remove broken configurations
rm -f /etc/nginx/sites-enabled/kibrisaramakurtarma
rm -f /etc/nginx/sites-available/kibrisaramakurtarma

# Create clean HTTP-only configuration
cat > /etc/nginx/sites-available/kibrisaramakurtarma << 'EOF'
server {
    listen 80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

# Enable the site
ln -s /etc/nginx/sites-available/kibrisaramakurtarma /etc/nginx/sites-enabled/

# Test nginx configuration
echo "Testing nginx configuration..."
if nginx -t; then
    echo "✅ Nginx configuration is valid"
    systemctl restart nginx
    echo "✅ Nginx restarted successfully"
else
    echo "❌ Nginx configuration failed"
    exit 1
fi

# Start KARK application if not running
cd /var/www/kark
if ! pm2 list | grep -q "kark-website"; then
    echo "Starting KARK application..."
    pm2 start ecosystem.config.js
    pm2 save
fi

# Enable firewall
ufw --force enable

echo ""
echo "🎉 Emergency fix completed!"
echo "Now test: curl -I http://kibrisaramakurtarma.org"
echo "If HTTP works, run: sudo certbot --nginx -d kibrisaramakurtarma.org -d www.kibrisaramakurtarma.org"