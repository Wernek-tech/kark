# replit.md

## Overview

This is the KARK (Kuzey Kıbrıs Arama Kurtarma) website - a comprehensive web platform for a search and rescue organization in Northern Cyprus. The website features a public-facing interface for viewing events, activities, media, and organization information, along with a powerful admin panel for content management.

**Project Type**: KARK Website (Full-stack web application)
**Technology Stack**: Node.js/Express backend with React frontend
**Current Status**: Fully functional news and rescue organization website

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: wouter (lightweight React router)
- **State Management**: TanStack Query (React Query) for server state management
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite (inferred from modern React setup)

### Backend Architecture
- **API Structure**: RESTful API endpoints
- **Authentication**: Role-based access control (major_admin, admin, user, banned)
- **Data Validation**: Zod schemas for type safety

### Component Structure
- **Layout Components**: Navbar, Footer, AdminLayout
- **UI Components**: shadcn/ui library (Button, Card, Dialog, Table, etc.)
- **Page Components**: Archive pages, Admin pages
- **Specialized Components**: EventCard for content display

## Key Components

### Public Interface
1. **Archive Detail Page** (`/archive/:id`)
   - Displays individual archive items with full details
   - Supports different content types (operation, training, event, report, news)
   - Type-based color coding and labeling system

2. **Archive List Page** (`/archive`)
   - Filterable archive listing with search functionality
   - Multiple content tabs (archive, events, media, reports)
   - Year and category filtering

### Admin Interface
1. **User Management** (`/admin/users`)
   - User listing with role management
   - Ban/unban functionality
   - Role-based permissions display

2. **Video Management** (`/admin/videos`)
   - CRUD operations for video content
   - YouTube integration for video embedding
   - Thumbnail extraction and preview

## Data Flow

### Content Management Flow
1. Admin creates/edits content through admin panels
2. Content is validated using Zod schemas
3. TanStack Query manages API calls and caching
4. Public pages display filtered and formatted content

### User Authentication Flow
1. Role-based access control system
2. Admin permissions for content management
3. User status tracking (active/banned)

### Archive Item Processing
1. Content categorization by type (operation, training, event, report, news)
2. Date-based filtering and organization
3. Search functionality across titles and descriptions

## External Dependencies

### Frontend Libraries
- **React Ecosystem**: React, React DOM, React Router (wouter)
- **State Management**: @tanstack/react-query
- **UI Framework**: Tailwind CSS, shadcn/ui components
- **Form Management**: react-hook-form, @hookform/resolvers
- **Validation**: Zod
- **Icons**: Lucide React
- **SEO**: React Helmet (Async)

### Media Integration
- **YouTube**: Video embedding and thumbnail extraction
- **File Handling**: Support for various media types (images, videos, documents)

## Deployment Strategy

The application appears to be structured for modern web deployment with:
- Client-side routing handled by wouter
- API endpoints suggesting a separate backend service
- Static asset optimization through modern build tools
- SEO optimization through React Helmet

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### January 07, 2025: KARK Website Successfully Restored Again
- **Problem**: User initially asked to remove files but then requested to continue with KARK website
- **Solution**: 
  - Stopped temporary Streamlit app creation
  - Restored KARK website using existing project structure
  - Successfully started Express server with npm run dev
  - Confirmed all dependencies are properly installed
- **Impact**: KARK website is fully operational and accessible at port 5000
- **Status**: Website running successfully with no errors

### January 07, 2025: VPS Deployment Fix for Cloudflare
- **Problem**: User experiencing 502 errors on VPS deployment with website falling back to fallback page
- **Solution**: 
  - Created comprehensive VPS deployment scripts for Cloudflare setup (no certbot needed)
  - Added health check endpoint to server for monitoring
  - Created API testing script to verify all endpoints
  - Created detailed deployment documentation with troubleshooting guides
  - Configured NGINX properly for Cloudflare proxy with real IP headers
- **Impact**: Complete solution for VPS deployment with Cloudflare, including monitoring and troubleshooting
- **Status**: Health check endpoint added and working, comprehensive deployment scripts ready

### January 07, 2025: VPS Build Error Fix
- **Problem**: VPS build failing with "No matching export in server/vite.ts" errors, causing all API tests to return 000
- **Solution**: Created three different fix scripts:
  1. **vps-build-fix.sh**: Creates production-specific server file avoiding ES module issues
  2. **vps-simple-build-fix.sh**: Uses tsx to run TypeScript directly (simpler approach)
  3. **vps-ultimate-fix.sh**: Most comprehensive - creates production-compatible modules, proper build process, PM2 config, and testing
- **Root Cause**: esbuild couldn't resolve imports from server/vite.ts during bundling
- **Impact**: Complete build process fixes that resolve module import issues and enable proper API functionality
- **Status**: Multiple solutions provided to ensure VPS deployment succeeds

## Admin Credentials
- **Username:** lotus, **Password:** Lotus103224
- **Username:** admin, **Password:** Admin123!

## Current Status

The KARK website is currently running successfully with:
- Express server on port 5000
- React frontend with Vite hot module replacement
- All API endpoints functioning correctly
- No JavaScript errors or critical issues
- Full authentication and admin panel functionality