# Fix Session Authentication Issue (403 Errors)

## The Problem
You're successfully logging in as "supermanager", but immediately getting 403 Unauthorized errors for admin API calls. This is a session management issue.

## Root Cause
The session configuration has cookie security settings that don't work properly with your Cloudflare + nginx setup.

## Fix Commands (Run on Your Server)

```bash
cd /var/www/kark

# 1. Set correct environment variables
echo "SESSION_SECRET=your-super-secret-session-key-$(date +%s)" >> .env
echo "NODE_ENV=production" >> .env
echo "TRUST_PROXY=true" >> .env

# 2. Restart application
pm2 restart kark-website

# 3. Test authentication
curl -X POST http://localhost:5000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"supermanager","password":"admin123"}' \
  -c cookies.txt

# 4. Test admin access with session
curl -X GET http://localhost:5000/api/users \
  -b cookies.txt
```

## Alternative Fix: Update Environment File

Create/update your `.env` file:

```bash
cat > .env << 'EOF'
NODE_ENV=production
PORT=5000
DB_TYPE=json
SESSION_SECRET=kark-super-secret-session-key-2025
TRUST_PROXY=true
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
EOF
```

## Quick Test

After restart, try this in browser console:

```javascript
// Check if session is maintained
fetch('/api/user')
  .then(response => response.json())
  .then(data => console.log('User session:', data))
  .catch(error => console.log('Session error:', error));
```

## Why This Happens

With Cloudflare + nginx proxy setup:
1. Cookies get confused about secure/non-secure contexts
2. Session store doesn't trust the proxy properly
3. Session gets lost between login and API calls

The fix sets proper proxy trust and cookie settings for your deployment environment.