#!/bin/bash

# VPS Production Fix Script - Solves the Vite config import issue
echo "🔧 Fixing VPS Production Build Issue..."

# Navigate to project directory
cd /var/www/kark

# 1. Stop all PM2 processes
echo "🛑 Stopping PM2 processes..."
pm2 stop all
pm2 delete all

# 2. Clean existing builds
echo "🧹 Cleaning existing builds..."
rm -rf dist/
rm -rf node_modules/.cache/

# 3. Install dependencies (production only)
echo "📦 Installing production dependencies..."
npm ci --only=production

# 4. Install dev dependencies temporarily for build
echo "📦 Installing build dependencies..."
npm install --save-dev vite esbuild tsx typescript

# 5. Build the project
echo "🔨 Building the project..."
npm run build

# 6. Verify build output
echo "🔍 Verifying build output..."
ls -la dist/
ls -la dist/public/

# 7. Test the built application
echo "🧪 Testing built application..."
node dist/index.js &
BUILD_PID=$!
sleep 3
curl -s http://localhost:5000/api/visitor-count && echo "✅ Built app works" || echo "❌ Built app failed"
kill $BUILD_PID 2>/dev/null

# 8. Create production-only PM2 config
echo "⚙️  Creating production PM2 config..."
cat > ecosystem.vps-production.js << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-production',
    script: 'node',
    args: 'dist/index.js',
    cwd: '/var/www/kark',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    },
    log_file: '/var/log/pm2/kark-production.log',
    out_file: '/var/log/pm2/kark-production-out.log',
    error_file: '/var/log/pm2/kark-production-error.log',
    merge_logs: true,
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
};
EOF

# 9. Create necessary directories
echo "📁 Creating directories..."
mkdir -p /var/log/pm2
mkdir -p data/sessions
chmod 755 data/sessions

# 10. Remove dev dependencies to save space
echo "🗑️  Removing dev dependencies..."
npm prune --production

# 11. Start with the fixed PM2 config
echo "🚀 Starting with production PM2 config..."
pm2 start ecosystem.vps-production.js

# 12. Save PM2 configuration
echo "💾 Saving PM2 configuration..."
pm2 save

# 13. Setup PM2 startup
echo "🔄 Setting up PM2 startup..."
pm2 startup systemd -u root --hp /root

# 14. Final verification
echo "🔍 Final verification..."
sleep 5
pm2 status
curl -s http://localhost:5000/api/visitor-count && echo "✅ Production deployment successful!" || echo "❌ Still having issues"

# 15. Restart nginx
echo "🔄 Restarting nginx..."
systemctl restart nginx

echo "✅ VPS Production Fix Complete!"
echo "🌐 Your website should now be accessible at http://kibrisaramakurtarma.org"
echo "📊 Monitor with: pm2 monit"
echo "📋 View logs with: pm2 logs"