# Complete KARK Website VPS Deployment with Cloudflare SSL

## Prerequisites
- Ubuntu VPS with root/sudo access
- Domain configured in Cloudflare with VPS IP address
- Cloudflare SSL/TLS mode set to "Full" or "Full (strict)"

## Step 1: Server Preparation

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required software
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
sudo npm install -g pm2
sudo apt install nginx git -y
```

## Step 2: Create Application Directory

```bash
sudo mkdir -p /var/www/kark
sudo chown $USER:$USER /var/www/kark
cd /var/www/kark
```

## Step 3: Upload Application Files

Upload all files from this Replit project to `/var/www/kark` using your preferred method (git, scp, etc.)

## Step 4: Install Dependencies

```bash
cd /var/www/kark
npm install
```

## Step 5: Create Production Environment File

```bash
cat > /var/www/kark/.env << 'EOF'
# Database Configuration
DB_TYPE=json
DATABASE_URL=postgresql://user:pass@localhost:5432/kark

# Session Configuration - CRITICAL FOR VPS WITH CLOUDFLARE
SESSION_SECRET=your-super-secure-random-session-secret-change-this-now
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
TRUST_PROXY=true

# Node Environment
NODE_ENV=production

# Port Configuration
PORT=5000
EOF
```

**⚠️ IMPORTANT:** Replace the SESSION_SECRET with: `openssl rand -base64 32`

## Step 6: Build Application

```bash
cd /var/www/kark
npm run build
```

## Step 7: Create PM2 Configuration

```bash
cat > /var/www/kark/ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'dist/index.js',
    cwd: '/var/www/kark',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      SESSION_SECRET: process.env.SESSION_SECRET || 'your-session-secret',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax',
      TRUST_PROXY: 'true',
      DB_TYPE: 'json'
    },
    node_args: '--max-old-space-size=1024',
    exec_mode: 'fork',
    log_file: '/var/log/pm2/kark-combined.log',
    out_file: '/var/log/pm2/kark-out.log',
    error_file: '/var/log/pm2/kark-error.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
};
EOF
```

## Step 8: Start Application with PM2

```bash
# Create log directory
sudo mkdir -p /var/log/pm2
sudo chown $USER:$USER /var/log/pm2

# Start application
cd /var/www/kark
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup systemd -u $USER --hp $HOME
```

## Step 9: Configure NGINX for Cloudflare

```bash
sudo tee /etc/nginx/sites-available/kark << 'EOF'
# Cloudflare IP ranges for real IP detection
set_real_ip_from 173.245.48.0/20;
set_real_ip_from 103.21.244.0/22;
set_real_ip_from 103.22.200.0/22;
set_real_ip_from 103.31.4.0/22;
set_real_ip_from 141.101.64.0/18;
set_real_ip_from 108.162.192.0/18;
set_real_ip_from 190.93.240.0/20;
set_real_ip_from 188.114.96.0/20;
set_real_ip_from 197.234.240.0/22;
set_real_ip_from 198.41.128.0/17;
set_real_ip_from 162.158.0.0/15;
set_real_ip_from 104.16.0.0/12;
set_real_ip_from 172.64.0.0/13;
set_real_ip_from 131.0.72.0/22;
set_real_ip_from 2400:cb00::/32;
set_real_ip_from 2606:4700::/32;
set_real_ip_from 2803:f800::/32;
set_real_ip_from 2405:b500::/32;
set_real_ip_from 2405:8100::/32;
set_real_ip_from 2a06:98c0::/29;
set_real_ip_from 2c0f:f248::/32;

# Use real IP from Cloudflare
real_ip_header CF-Connecting-IP;

server {
    listen 80;
    listen [::]:80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;
    
    # Security headers (Cloudflare will add more)
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    
    # Large file uploads
    client_max_body_size 100M;
    
    # Proxy to Node.js application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header X-Forwarded-Server $host;
        proxy_cache_bypass $http_upgrade;
        
        # WebSocket support
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        proxy_buffering off;
    }
    
    # Static files with caching
    location /assets {
        alias /var/www/kark/dist/assets;
        expires 1y;
        add_header Cache-Control "public, immutable";
        gzip_static on;
    }
    
    # Public files
    location /public {
        alias /var/www/kark/public;
        expires 30d;
        add_header Cache-Control "public";
    }
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript application/json application/javascript application/xml+rss application/rss+xml application/atom+xml image/svg+xml;
}
EOF
```

## Step 10: Enable NGINX Site

```bash
# Enable site
sudo ln -sf /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test configuration
sudo nginx -t

# Reload NGINX
sudo systemctl reload nginx
```

## Step 11: Configure Firewall

```bash
# Allow NGINX and SSH
sudo ufw allow 'Nginx Full'
sudo ufw allow ssh
sudo ufw --force enable
```

## Step 12: Verify Deployment

```bash
# Check PM2 status
pm2 status

# Check application logs
pm2 logs kark-website --lines 50

# Test local connection
curl http://localhost:5000

# Check NGINX status
sudo systemctl status nginx
```

## Cloudflare Settings

In your Cloudflare dashboard:

1. **SSL/TLS Mode**: Set to "Full" or "Full (strict)"
2. **Edge Certificates**: Enable "Always Use HTTPS"
3. **Speed > Optimization**: Enable "Auto Minify" for CSS, JS, HTML
4. **Caching > Configuration**: Set "Browser Cache TTL" to "4 hours"
5. **Security > Settings**: Set Security Level to "Medium"

## Testing Your Site

1. Visit: `https://kibrisaramakurtarma.org`
2. Admin panel: `https://kibrisaramakurtarma.org/admin`
3. Default credentials:
   - Username: `supermanager`
   - Password: `admin123`

## Troubleshooting

### Check Application Logs
```bash
pm2 logs kark-website --lines 100
```

### Check NGINX Error Logs
```bash
sudo tail -f /var/log/nginx/error.log
```

### Restart Application
```bash
pm2 restart kark-website
```

### Check Real IP Detection
```bash
# In NGINX logs, verify you see real visitor IPs, not Cloudflare IPs
sudo tail -f /var/log/nginx/access.log
```

### Session Issues
If you experience session problems:
1. Verify `TRUST_PROXY=true` in environment
2. Check `COOKIE_SECURE=false` for HTTP behind Cloudflare
3. Ensure SESSION_SECRET is set and consistent

## Maintenance Commands

```bash
# View application status
pm2 status

# View logs
pm2 logs kark-website

# Restart application
pm2 restart kark-website

# Update application
cd /var/www/kark
git pull  # or upload new files
npm install
npm run build
pm2 restart kark-website
```

## Security Notes

1. **Change default passwords immediately**
2. **Use strong SESSION_SECRET**: `openssl rand -base64 32`
3. **Keep system updated**: `sudo apt update && sudo apt upgrade`
4. **Monitor logs regularly**
5. **Enable Cloudflare security features**

This configuration is optimized for Cloudflare proxy and handles all the specific requirements for your KARK website deployment.