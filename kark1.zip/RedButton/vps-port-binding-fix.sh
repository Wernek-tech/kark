#!/bin/bash

echo "=== VPS Port 5000 Binding Fix ==="
echo "Fixing server port binding issue..."

# 1. Stop ALL PM2 processes
echo "Step 1: Stopping all PM2 processes..."
pm2 stop all
pm2 delete all
pm2 flush

# 2. Kill any remaining node processes
echo "Step 2: Cleaning up any remaining processes..."
pkill -f "node\|tsx" 2>/dev/null || true

# 3. Check server/index.ts configuration
echo "Step 3: Checking server configuration..."
echo "Current server/index.ts listen configuration:"
grep -n -A2 -B2 "listen\|PORT" server/index.ts | head -10

# 4. Update server to properly bind to port and interface
echo "Step 4: Ensuring server binds to 0.0.0.0:5000..."

# Backup original file
cp server/index.ts server/index.ts.backup

# Update the listen call to bind to all interfaces
sed -i 's/app\.listen(PORT)/app.listen(PORT, "0.0.0.0", () => { console.log(`Server running on http:\/\/0.0.0.0:${PORT}`); })/g' server/index.ts

# Alternative patterns
sed -i 's/\.listen(port)/\.listen(port, "0.0.0.0", () => { console.log(`Server running on http:\/\/0.0.0.0:${port}`); })/g' server/index.ts

# Check if changes were applied
echo "Updated server configuration:"
grep -n -A2 -B2 "listen" server/index.ts | head -10

# 5. Create clean PM2 configuration
echo "Step 5: Creating clean PM2 configuration..."
cat > ecosystem.clean.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-clean',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    autorestart: true,
    watch: false,
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-kibris-secret-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log'
  }]
}
EOF

# 6. Create logs directory
mkdir -p logs

# 7. Start single clean process
echo "Step 6: Starting clean PM2 process..."
pm2 start ecosystem.clean.cjs

# 8. Wait for startup
echo "Step 7: Waiting for server startup..."
sleep 8

# 9. Check what's actually listening
echo "Step 8: Checking port status..."
echo "Processes listening on port 5000:"
netstat -tlnp | grep :5000 || echo "Nothing listening on port 5000"

echo ""
echo "All listening ports:"
netstat -tlnp | grep LISTEN

# 10. Test server response
echo ""
echo "Step 9: Testing server response..."
if curl -s http://localhost:5000 | head -1 | grep -q DOCTYPE; then
    echo "✓ Server responding correctly on port 5000"
else
    echo "✗ Server not responding. Checking logs..."
    echo "PM2 Status:"
    pm2 status
    echo ""
    echo "Recent logs:"
    pm2 logs kark-clean --lines 15
fi

# 11. Show final status
echo ""
echo "Step 10: Final verification..."
pm2 status

echo ""
echo "=== Port Binding Fix Complete ==="
echo "If server is now listening on 0.0.0.0:5000, test external access:"
echo "http://193.31.31.171:5000"
EOF