#!/bin/bash

# Quick 502 Error Fix for KARK Website VPS
echo "🔧 Quick 502 Error Fix for KARK Website..."

# Check if we're in the correct directory
if [ ! -f "package.json" ]; then
    echo "❌ package.json not found. Are you in the correct directory?"
    echo "Please run: cd /var/www/kark"
    exit 1
fi

# 1. Stop everything
echo "Stopping all services..."
pm2 stop all 2>/dev/null || true
pm2 delete all 2>/dev/null || true
sudo systemctl stop nginx 2>/dev/null || true

# 2. Quick build check
echo "Checking build..."
if [ ! -f "dist/index.js" ]; then
    echo "Building application..."
    npm run build
    
    if [ ! -f "dist/index.js" ]; then
        echo "❌ Build failed. Creating fallback server..."
        mkdir -p dist
        cat > dist/index.js << 'EOF'
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

app.set('trust proxy', true);
app.use(express.json());
app.use(express.static(path.join(__dirname, '../client/dist')));

app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/dist/index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`KARK Website running on port ${PORT}`);
});
EOF
    fi
fi

# 3. Start with PM2
echo "Starting application..."
pm2 start dist/index.js --name kark-website --env production

# 4. Test application
sleep 3
echo "Testing application..."
if curl -s http://localhost:5000/health | grep -q "ok"; then
    echo "✅ Application is running"
else
    echo "❌ Application failed to start"
    echo "PM2 logs:"
    pm2 logs --lines 20
    exit 1
fi

# 5. Create basic NGINX config
echo "Configuring NGINX..."
sudo tee /etc/nginx/sites-available/kark > /dev/null << 'EOF'
server {
    listen 80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Timeouts to prevent 502
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    location /health {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
    }
}
EOF

# Enable site
sudo ln -sf /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test and restart NGINX
if sudo nginx -t; then
    sudo systemctl restart nginx
    echo "✅ NGINX configured and started"
else
    echo "❌ NGINX configuration error"
    sudo nginx -t
    exit 1
fi

# 6. Final status
echo ""
echo "Status Check:"
echo "PM2 Status:"
pm2 list

echo ""
echo "NGINX Status:"
sudo systemctl status nginx --no-pager -l

echo ""
echo "Port Check:"
sudo netstat -tlnp | grep :5000

echo ""
echo "🎉 Quick 502 Fix Complete!"
echo ""
echo "Test commands:"
echo "curl -I http://kibrisaramakurtarma.org"
echo "curl http://localhost:5000/health"
echo ""
echo "If still getting 502:"
echo "1. pm2 logs"
echo "2. sudo tail -f /var/log/nginx/error.log"
echo "3. sudo systemctl status nginx"