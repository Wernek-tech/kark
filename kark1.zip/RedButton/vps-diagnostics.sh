#!/bin/bash

echo "=== KARK VPS Comprehensive Diagnostics ==="
echo "Diagnosing all potential issues..."

echo ""
echo "1. PM2 Status Check:"
pm2 status

echo ""
echo "2. PM2 Logs (last 30 lines):"
pm2 logs kark-website --lines 30 | head -50

echo ""
echo "3. Port Check:"
netstat -tlnp | grep :5000 || echo "Port 5000 not listening"

echo ""
echo "4. Process Check:"
ps aux | grep -E "(node|tsx|npm)" | grep -v grep

echo ""
echo "5. File Structure Check:"
echo "Server files:"
ls -la server/
echo ""
echo "Package.json scripts:"
grep -A 10 '"scripts"' package.json
echo ""
echo "Environment file:"
cat .env 2>/dev/null || echo ".env file missing"

echo ""
echo "6. Dependencies Check:"
echo "Node version:"
node --version
echo "NPM version:"
npm --version
echo "TSX installed?"
which tsx || echo "tsx not found"

echo ""
echo "7. Build Output Check:"
ls -la dist/ 2>/dev/null || echo "No dist directory"

echo ""
echo "8. Manual Server Test:"
echo "Testing server startup..."
timeout 10s npx tsx server/index.ts 2>&1 || echo "Server startup failed"

echo ""
echo "9. Network Test:"
echo "Testing local connection:"
curl -s http://localhost:5000 | head -5 2>/dev/null || echo "Server not responding on localhost:5000"

echo ""
echo "10. System Resources:"
echo "Memory:"
free -h
echo "Disk space:"
df -h /var/www/kark
echo "CPU load:"
uptime

echo ""
echo "=== Diagnostics Complete ==="
echo "Send this output to troubleshoot the issue."