#!/bin/bash

# VPS PM2 Debug Script
echo "🔍 Debugging PM2 and API connection..."

cd /var/www/kark

echo "=== PM2 Status ==="
pm2 status

echo -e "\n=== PM2 Logs (Last 50 lines) ==="
pm2 logs --lines 50

echo -e "\n=== Check Process Details ==="
pm2 show 0

echo -e "\n=== Check if server file exists ==="
ls -la dist/server.js

echo -e "\n=== Test server file directly ==="
timeout 10s node dist/server.js &
sleep 3
curl -v http://localhost:5000/api/visitor-count
pkill node

echo -e "\n=== Check PM2 process environment ==="
pm2 env 0

echo -e "\n=== System processes on port 5000 ==="
ss -tlnp | grep :5000 || echo "Nothing on port 5000"

echo -e "\n=== Restart PM2 process ==="
pm2 restart 0

echo -e "\n=== Wait and test again ==="
sleep 5
curl -s http://localhost:5000/api/visitor-count && echo "✅ API working" || echo "❌ API still not working"

echo -e "\n=== PM2 Final Status ==="
pm2 status