# KARK Website VPS Deployment Checklist

## ✅ API Configuration Status

All API endpoints have been tested and are working correctly:

### Tested Endpoints:
- ✅ `/api/visitor-count` - Working
- ✅ `/api/team` - Working  
- ✅ `/api/events` - Working
- ✅ `/api/settings` - Working
- ✅ `/api/hero-sliders` - Working
- ✅ `/api/albums` - Working
- ✅ `/api/media` - Working
- ✅ `/api/activities` - Working

### Frontend API Configuration:
- ✅ All API calls use relative paths (e.g., `/api/...`)
- ✅ No hardcoded localhost or port references
- ✅ Proper error handling for failed requests
- ✅ Authentication headers included where needed

### Backend Configuration:
- ✅ CORS properly configured for production
- ✅ Trust proxy enabled for nginx
- ✅ Session configuration ready for production
- ✅ Security headers implemented
- ✅ Rate limiting configured

## 📋 Deployment Steps

### 1. Server Preparation
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required software
sudo apt install nginx nodejs npm git pm2 -y

# Clone repository
cd /var/www
git clone [your-repo-url] kark
cd kark
```

### 2. Install Dependencies
```bash
# Install Node.js dependencies
npm install

# Install PM2 globally
sudo npm install -g pm2
```

### 3. Environment Configuration
```bash
# Create production .env file
cat > .env << 'EOF'
NODE_ENV=production
PORT=5000
HOST=0.0.0.0
DB_TYPE=json
SESSION_SECRET=your-secure-random-session-secret-here
TRUST_PROXY=true
COOKIE_SECURE=true
COOKIE_SAME_SITE=lax
COOKIE_HTTP_ONLY=true
CORS_ORIGINS=https://kibrisaramakurtarma.org,https://www.kibrisaramakurtarma.org
EOF
```

### 4. Build Frontend
```bash
# Build the React frontend
npm run build
```

### 5. Configure Nginx
```bash
# Copy nginx configuration
sudo cp nginx-production.conf /etc/nginx/sites-available/kark

# Create symlink
sudo ln -s /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/

# Test nginx configuration
sudo nginx -t

# Reload nginx
sudo systemctl reload nginx
```

### 6. SSL Certificate Setup
```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx -y

# Obtain SSL certificate
sudo certbot --nginx -d kibrisaramakurtarma.org -d www.kibrisaramakurtarma.org
```

### 7. Start Application with PM2
```bash
# Start the application
pm2 start ecosystem.production.cjs

# Save PM2 configuration
pm2 save

# Setup PM2 to start on boot
pm2 startup systemd
```

### 8. Configure Firewall
```bash
# Allow SSH, HTTP, and HTTPS
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

## 🔍 Verification Steps

### 1. Check API Endpoints
```bash
# Test from server
curl http://localhost:5000/api/visitor-count

# Test from external (after nginx setup)
curl https://kibrisaramakurtarma.org/api/visitor-count
```

### 2. Check Logs
```bash
# PM2 logs
pm2 logs

# Nginx access logs
tail -f /var/log/nginx/kark_access.log

# Nginx error logs
tail -f /var/log/nginx/kark_error.log
```

### 3. Monitor Application
```bash
# PM2 status
pm2 status

# PM2 monitoring
pm2 monit
```

## 📝 Important Notes

1. **Database**: Currently using JSON file storage. For production, consider migrating to MySQL/PostgreSQL.

2. **Backups**: Set up regular backups for:
   - `/var/www/kark/data/` directory
   - Nginx configuration
   - SSL certificates

3. **Security**: 
   - Change default admin passwords
   - Set strong SESSION_SECRET
   - Enable firewall
   - Keep system updated

4. **Performance**:
   - Enable gzip compression (already in nginx config)
   - Set up CDN for static assets if needed
   - Monitor server resources

## 🚨 Troubleshooting

### If API returns 502 Bad Gateway:
```bash
# Check if Node.js app is running
pm2 status
pm2 restart kark-production
```

### If static files not loading:
```bash
# Check build output
ls -la /var/www/kark/dist/public/

# Check nginx error logs
tail -50 /var/log/nginx/kark_error.log
```

### If sessions not persisting:
```bash
# Check session directory permissions
ls -la /var/www/kark/data/sessions/
chmod 755 /var/www/kark/data/sessions/
```

## ✅ Final Checklist

- [ ] Server updated and secured
- [ ] Dependencies installed
- [ ] Environment variables configured
- [ ] Frontend built successfully
- [ ] Nginx configured and tested
- [ ] SSL certificates installed
- [ ] Application running with PM2
- [ ] Firewall configured
- [ ] All API endpoints tested
- [ ] Admin panel accessible
- [ ] Backups configured

Your KARK website is ready for VPS deployment with nginx!