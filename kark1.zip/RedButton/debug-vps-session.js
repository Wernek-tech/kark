const express = require('express');
const session = require('express-session');

// VPS Session Debug Tool
console.log('=== VPS Session Debug Tool ===');

// Test session configuration
const sessionConfig = {
  secret: process.env.SESSION_SECRET || 'test-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.COOKIE_SECURE === 'true',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000,
    sameSite: process.env.COOKIE_SAME_SITE || 'lax'
  }
};

console.log('Session Configuration:', JSON.stringify(sessionConfig, null, 2));

// Check environment variables
console.log('\nEnvironment Variables:');
console.log('NODE_ENV:', process.env.NODE_ENV);
console.log('PORT:', process.env.PORT);
console.log('SESSION_SECRET:', process.env.SESSION_SECRET ? 'SET' : 'NOT SET');
console.log('TRUST_PROXY:', process.env.TRUST_PROXY);
console.log('COOKIE_SECURE:', process.env.COOKIE_SECURE);
console.log('COOKIE_SAME_SITE:', process.env.COOKIE_SAME_SITE);

// Test express app
const app = express();
app.set('trust proxy', 1);

// Add session middleware
app.use(session(sessionConfig));

// Test route
app.get('/test-session', (req, res) => {
  console.log('Session Test:');
  console.log('Session ID:', req.sessionID);
  console.log('Session data:', req.session);
  console.log('Request headers:', req.headers);
  
  // Set test data
  req.session.testData = 'VPS Session Working!';
  req.session.timestamp = new Date().toISOString();
  
  res.json({
    success: true,
    sessionID: req.sessionID,
    testData: req.session.testData,
    timestamp: req.session.timestamp,
    cookies: req.headers.cookie
  });
});

// Start debug server
const port = process.env.PORT || 3001;
app.listen(port, '0.0.0.0', () => {
  console.log(`\nDebug server running on port ${port}`);
  console.log(`Test URL: http://your-vps-ip:${port}/test-session`);
  console.log('\nThis will help identify session issues on your VPS.');
});