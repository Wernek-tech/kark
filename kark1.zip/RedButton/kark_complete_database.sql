-- KARK Website Complete MySQL Database Import File for cPanel
-- Version: 2.0
-- Date: 2025-01-27
-- Description: Complete database structure with all tables, relationships, indexes, and initial data
-- Optimized for cPanel hosting environments

-- =====================================================
-- CPANEL CONFIGURATION NOTES
-- =====================================================
-- 1. Replace 'your_prefix_' with your actual cPanel database prefix (e.g., 'mysite_')
-- 2. Replace 'your_database_name' with your actual cPanel database name
-- 3. Some cPanel providers don't allow CREATE DATABASE, so comment out if needed
-- 4. Table names are prefixed for shared hosting compatibility

-- =====================================================
-- DATABASE SETUP (Comment out if using existing cPanel database)
-- =====================================================

-- CREATE DATABASE IF NOT EXISTS your_database_name CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE your_database_name;

-- =====================================================
-- DROP EXISTING TABLES (if any)
-- =====================================================
-- Note: Replace 'your_prefix_' with your actual cPanel database prefix

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `your_prefix_sessions`;
DROP TABLE IF EXISTS `your_prefix_admin_logs`;
DROP TABLE IF EXISTS `your_prefix_archive_media`;
DROP TABLE IF EXISTS `your_prefix_archive_items`;
DROP TABLE IF EXISTS `your_prefix_activities`;
DROP TABLE IF EXISTS `your_prefix_hero_sliders`;
DROP TABLE IF EXISTS `your_prefix_donation_campaigns`;
DROP TABLE IF EXISTS `your_prefix_donation_methods`;
DROP TABLE IF EXISTS `your_prefix_settings`;
DROP TABLE IF EXISTS `your_prefix_contact_messages`;
DROP TABLE IF EXISTS `your_prefix_team_members`;
DROP TABLE IF EXISTS `your_prefix_media_items`;
DROP TABLE IF EXISTS `your_prefix_albums`;
DROP TABLE IF EXISTS `your_prefix_events`;
DROP TABLE IF EXISTS `your_prefix_users`;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================
-- TABLE: your_prefix_users
-- =====================================================

CREATE TABLE `your_prefix_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `is_admin` boolean DEFAULT false NOT NULL,
  `role` enum('major_admin','admin','user','banned') DEFAULT 'user' NOT NULL,
  `permissions` json DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_idx` (`username`),
  UNIQUE KEY `email_idx` (`email`),
  KEY `role_idx` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: events
-- =====================================================

CREATE TABLE `your_prefix_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date` timestamp NOT NULL,
  `location` varchar(255) NOT NULL,
  `category` enum('rescue','training','donation','awareness') NOT NULL,
  `image_path` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_idx` (`category`),
  KEY `date_idx` (`date`),
  KEY `created_by_idx` (`created_by`),
  CONSTRAINT `events_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: albums
-- =====================================================

CREATE TABLE `your_prefix_albums` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `cover_image_id` int DEFAULT NULL,
  `event_id` int DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_id_idx` (`event_id`),
  KEY `created_by_idx` (`created_by`),
  CONSTRAINT `albums_event_id_fk` FOREIGN KEY (`event_id`) REFERENCES `your_prefix_events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `albums_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: media_items
-- =====================================================

CREATE TABLE `your_prefix_media_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `media_type` enum('photo','video') NOT NULL,
  `file_path` text NOT NULL,
  `thumbnail_path` text,
  `event_id` int DEFAULT NULL,
  `album_id` int DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_type_idx` (`media_type`),
  KEY `event_id_idx` (`event_id`),
  KEY `album_id_idx` (`album_id`),
  KEY `created_by_idx` (`created_by`),
  CONSTRAINT `media_items_event_id_fk` FOREIGN KEY (`event_id`) REFERENCES `your_prefix_events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `media_items_album_id_fk` FOREIGN KEY (`album_id`) REFERENCES `your_prefix_albums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `media_items_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: team_members
-- =====================================================

CREATE TABLE `your_prefix_team_members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `image_path` text,
  `email` varchar(255),
  `skills` json DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by_idx` (`created_by`),
  CONSTRAINT `team_members_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: contact_messages
-- =====================================================

CREATE TABLE `your_prefix_contact_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `is_read` boolean DEFAULT false NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  PRIMARY KEY (`id`),
  KEY `is_read_idx` (`is_read`),
  KEY `created_at_idx` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: settings
-- =====================================================

CREATE TABLE `your_prefix_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_idx` (`key`),
  KEY `updated_by_idx` (`updated_by`),
  CONSTRAINT `settings_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: donation_methods
-- =====================================================

CREATE TABLE `your_prefix_donation_methods` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(255) NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `iban` varchar(50) NOT NULL,
  `branch_code` varchar(20),
  `account_number` varchar(50),
  `currency` varchar(10) DEFAULT 'TRY',
  `description` text,
  `logo_url` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by_idx` (`created_by`),
  KEY `updated_by_idx` (`updated_by`),
  CONSTRAINT `donation_methods_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `donation_methods_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: donation_campaigns
-- =====================================================

CREATE TABLE `your_prefix_donation_campaigns` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `target_amount` decimal(12,2) DEFAULT NULL,
  `current_amount` decimal(12,2) DEFAULT 0,
  `end_date` date DEFAULT NULL,
  `image_url` text,
  `is_active` boolean DEFAULT true,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_active_idx` (`is_active`),
  KEY `end_date_idx` (`end_date`),
  KEY `created_by_idx` (`created_by`),
  KEY `updated_by_idx` (`updated_by`),
  CONSTRAINT `donation_campaigns_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `donation_campaigns_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: archive_items
-- =====================================================

CREATE TABLE `your_prefix_archive_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `content` text,
  `item_type` enum('operation','training','event','report','news') NOT NULL,
  `date` timestamp NOT NULL,
  `location` varchar(255),
  `participants` text,
  `outcome` text,
  `image_url` text,
  `video_url` text,
  `document_url` text,
  `tags` json DEFAULT NULL,
  `is_published` boolean DEFAULT false NOT NULL,
  `is_featured` boolean DEFAULT false NOT NULL,
  `view_count` int DEFAULT 0 NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_type_idx` (`item_type`),
  KEY `date_idx` (`date`),
  KEY `is_published_idx` (`is_published`),
  KEY `is_featured_idx` (`is_featured`),
  KEY `created_by_idx` (`created_by`),
  KEY `updated_by_idx` (`updated_by`),
  FULLTEXT KEY `title_description_content_idx` (`title`, `description`, `content`),
  CONSTRAINT `archive_items_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `archive_items_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: archive_media
-- =====================================================

CREATE TABLE `your_prefix_archive_media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `archive_item_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `media_type` enum('photo','video') NOT NULL,
  `file_path` text NOT NULL,
  `thumbnail_path` text,
  `display_order` int DEFAULT 0 NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `archive_item_id_idx` (`archive_item_id`),
  KEY `media_type_idx` (`media_type`),
  KEY `display_order_idx` (`display_order`),
  KEY `created_by_idx` (`created_by`),
  CONSTRAINT `archive_media_archive_item_id_fk` FOREIGN KEY (`archive_item_id`) REFERENCES `your_prefix_archive_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `archive_media_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: hero_sliders
-- =====================================================

CREATE TABLE `your_prefix_hero_sliders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `button_text` varchar(100),
  `button_link` varchar(255),
  `image_url` text NOT NULL,
  `display_order` int DEFAULT 0 NOT NULL,
  `is_active` boolean DEFAULT true NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `display_order_idx` (`display_order`),
  KEY `is_active_idx` (`is_active`),
  KEY `created_by_idx` (`created_by`),
  KEY `updated_by_idx` (`updated_by`),
  CONSTRAINT `hero_sliders_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `hero_sliders_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: activities
-- =====================================================

CREATE TABLE `your_prefix_activities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(100) NOT NULL,
  `image_url` text,
  `date` varchar(100),
  `link` varchar(255),
  `display_order` int DEFAULT 0 NOT NULL,
  `is_active` boolean DEFAULT true NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `created_by` int DEFAULT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_idx` (`category`),
  KEY `display_order_idx` (`display_order`),
  KEY `is_active_idx` (`is_active`),
  KEY `created_by_idx` (`created_by`),
  KEY `updated_by_idx` (`updated_by`),
  CONSTRAINT `activities_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `activities_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `your_prefix_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: admin_logs
-- =====================================================

CREATE TABLE `your_prefix_admin_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `action` varchar(255) NOT NULL,
  `details` text,
  `ip_address` varchar(45),
  `user_agent` text,
  `resource_type` varchar(100),
  `resource_id` varchar(100),
  `timestamp` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id_idx` (`user_id`),
  KEY `action_idx` (`action`),
  KEY `resource_type_idx` (`resource_type`),
  KEY `timestamp_idx` (`timestamp`),
  CONSTRAINT `admin_logs_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `your_prefix_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- TABLE: sessions (for express-session)
-- =====================================================

CREATE TABLE `your_prefix_sessions` (
  `sid` varchar(255) NOT NULL,
  `sess` text NOT NULL,
  `expire` timestamp NOT NULL,
  PRIMARY KEY (`sid`),
  KEY `expire_idx` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- INITIAL DATA: Admin User
-- =====================================================

-- Create super admin user (password: SuperAdmin123!)
-- Create admin user (password: Admin123!)
-- IMPORTANT: Change these passwords immediately after first login!
INSERT INTO `your_prefix_users` (`username`, `password`, `first_name`, `last_name`, `email`, `is_admin`, `role`, `permissions`) VALUES
('supermanager', '$2b$10$XE6EGQJXTMwIpi3IAc8lAuSX1lFbLSL.aaUY521S6HuxbMOaiNgx6', 'Super', 'Manager', 'superadmin@kark.org', true, 'major_admin', '["all"]'),
('admin', '$2b$10$Kbb2mcAqLpMcggqgJLwP.OywOlPS4Lmqs6GfeOGoOiPu2CAPKgrES', 'Admin', 'User', 'admin@kark.org', true, 'admin', '["manage_content", "manage_users"]');

-- =====================================================
-- INITIAL DATA: Settings
-- =====================================================

INSERT INTO `your_prefix_settings` (`key`, `value`, `updated_by`) VALUES
('general.site_name', 'KARK - Köpek Arama Kurtarma', 1),
('general.site_description', 'Profesyonel köpek arama kurtarma ekibi', 1),
('general.footer_text', '© 2025 KARK. Tüm hakları saklıdır.', 1),
('general.contact_email', 'info@kark.org', 1),
('general.contact_phone', '+90 555 123 4567', 1),
('general.address', 'İstanbul, Türkiye', 1),
('social.facebook', 'https://facebook.com/kark', 1),
('social.twitter', 'https://twitter.com/kark', 1),
('social.instagram', 'https://instagram.com/kark', 1),
('social.youtube', 'https://youtube.com/kark', 1);

-- =====================================================
-- INITIAL DATA: Hero Sliders
-- =====================================================

INSERT INTO `your_prefix_hero_sliders` (`title`, `description`, `button_text`, `button_link`, `image_url`, `display_order`, `is_active`, `created_by`) VALUES
('Köpek Arama Kurtarma', 'Profesyonel eğitimli köpeklerle arama kurtarma hizmetleri', 'Hakkımızda', '/about', '/images/hero1.jpg', 1, true, 1),
('7/24 Acil Müdahale', 'Doğal afetlerde ve acil durumlarda yanınızdayız', 'İletişim', '/contact', '/images/hero2.jpg', 2, true, 1),
('Gönüllü Ol', 'Ekibimize katılın, hayat kurtarmaya yardımcı olun', 'Başvur', '/volunteer', '/images/hero3.jpg', 3, true, 1);

-- =====================================================
-- INITIAL DATA: Activities
-- =====================================================

INSERT INTO `your_prefix_activities` (`title`, `description`, `category`, `image_url`, `date`, `link`, `display_order`, `is_active`, `created_by`) VALUES
('Arama Kurtarma Eğitimi', 'Profesyonel arama kurtarma teknikleri eğitimi', 'training', '/images/activity1.jpg', '2025-01-15', '/training/search-rescue', 1, true, 1),
('Deprem Tatbikatı', 'İzmir bölgesinde gerçekleştirilen deprem tatbikatı', 'exercise', '/images/activity2.jpg', '2025-01-20', '/events/earthquake-drill', 2, true, 1),
('K9 Köpek Eğitimi', 'Arama kurtarma köpeklerinin özel eğitim programı', 'training', '/images/activity3.jpg', '2025-01-25', '/training/k9-program', 3, true, 1);

-- =====================================================
-- INITIAL DATA: Events
-- =====================================================

INSERT INTO `your_prefix_events` (`title`, `description`, `date`, `location`, `category`, `image_path`, `created_by`) VALUES
('Temel Arama Kurtarma Eğitimi', 'KARK gönüllüleri için temel arama kurtarma eğitimi', '2025-02-01 09:00:00', 'İstanbul Eğitim Merkezi', 'training', '/images/event1.jpg', 1),
('Bağış Kampanyası', 'Ekipman yenileme için bağış kampanyası', '2025-02-15 10:00:00', 'Online', 'donation', '/images/event2.jpg', 1),
('Afet Farkındalık Semineri', 'Halk için afet farkındalık semineri', '2025-03-01 14:00:00', 'Ankara Kongre Merkezi', 'awareness', '/images/event3.jpg', 1);

-- =====================================================
-- INITIAL DATA: Team Members
-- =====================================================

INSERT INTO `your_prefix_team_members` (`first_name`, `last_name`, `position`, `image_path`, `email`, `skills`, `created_by`) VALUES
('Ahmet', 'Yılmaz', 'Ekip Lideri', '/images/team1.jpg', 'ahmet@kark.org', '["Arama Kurtarma", "İlk Yardım", "Ekip Yönetimi"]', 1),
('Ayşe', 'Demir', 'K9 Eğitmeni', '/images/team2.jpg', 'ayse@kark.org', '["Köpek Eğitimi", "Davranış Analizi", "Operasyon Planlama"]', 1),
('Mehmet', 'Kaya', 'Tıbbi Destek Uzmanı', '/images/team3.jpg', 'mehmet@kark.org', '["İlk Yardım", "Travma Müdahalesi", "Acil Tıp"]', 1);

-- =====================================================
-- INITIAL DATA: Donation Methods
-- =====================================================

INSERT INTO `your_prefix_donation_methods` (`bank_name`, `account_name`, `iban`, `branch_code`, `account_number`, `currency`, `description`, `logo_url`, `created_by`) VALUES
('Ziraat Bankası', 'KARK Derneği', 'TR12 3456 7890 1234 5678 9012 34', '1234', '12345678', 'TRY', 'TL hesabı için bağış', '/images/banks/ziraat.png', 1),
('İş Bankası', 'KARK Derneği', 'TR98 7654 3210 9876 5432 1098 76', '5678', '87654321', 'USD', 'Dolar hesabı için bağış', '/images/banks/isbank.png', 1),
('Garanti BBVA', 'KARK Derneği', 'TR55 1111 2222 3333 4444 5555 66', '9999', '11223344', 'EUR', 'Euro hesabı için bağış', '/images/banks/garanti.png', 1);

-- =====================================================
-- INITIAL DATA: Archive Items
-- =====================================================

INSERT INTO `your_prefix_archive_items` (`title`, `description`, `content`, `item_type`, `date`, `location`, `participants`, `outcome`, `image_url`, `video_url`, `tags`, `is_published`, `is_featured`, `created_by`) VALUES
('İzmir Depremi Arama Kurtarma Operasyonu', 
'30 Ekim 2020 İzmir depreminde gerçekleştirilen arama kurtarma operasyonu', 
'KARK ekibi, İzmir''de meydana gelen 6.6 büyüklüğündeki depremde 72 saat boyunca aralıksız çalışarak 15 kişinin kurtarılmasına katkı sağladı. Operasyonda 8 eğitimli arama köpeği ve 25 gönüllü görev aldı.', 
'operation', 
'2020-10-30 14:51:00', 
'İzmir, Bayraklı', 
'25 KARK gönüllüsü, 8 arama köpeği', 
'15 kişi kurtarıldı, 48 enkaz bölgesinde arama yapıldı', 
'/images/archive/izmir-deprem.jpg', 
'https://youtube.com/watch?v=example1', 
'["deprem", "izmir", "arama kurtarma", "operasyon"]', 
true, 
true, 
1),

('K9 İleri Seviye Eğitim Programı 2024', 
'Arama kurtarma köpekleri için düzenlenen ileri seviye eğitim programı', 
'6 aylık yoğun eğitim programında 12 köpek ve eğitmeni, enkaz altı arama, su üstü arama ve dağ kurtarma teknikleri konusunda eğitim aldı. Program uluslararası standartlarda sertifikasyon ile tamamlandı.', 
'training', 
'2024-06-15 09:00:00', 
'Ankara Eğitim Merkezi', 
'12 köpek, 12 eğitmen, 4 uluslararası eğitici', 
'12 köpek uluslararası sertifika aldı', 
'/images/archive/k9-training.jpg', 
NULL, 
'["eğitim", "k9", "sertifika", "köpek eğitimi"]', 
true, 
false, 
1),

('Afet Hazırlık Raporu 2024', 
'Türkiye geneli afet hazırlık durumu değerlendirme raporu', 
'KARK tarafından hazırlanan bu rapor, Türkiye''nin 81 ilindeki arama kurtarma kapasitesini, ekipman durumunu ve personel yeterliliğini değerlendirmektedir. Rapor, gelecek 5 yıl için öneriler içermektedir.', 
'report', 
'2024-12-01 10:00:00', 
'Türkiye Geneli', 
'KARK Araştırma Ekibi', 
'81 il değerlendirildi, 145 öneri sunuldu', 
'/images/archive/report-cover.jpg', 
NULL, 
'["rapor", "afet hazırlık", "değerlendirme", "strateji"]', 
true, 
true, 
1);

-- =====================================================
-- STORED PROCEDURES FOR API ENDPOINTS
-- =====================================================

DELIMITER $$

-- Procedure: Get visitor count
CREATE PROCEDURE sp_get_visitor_count()
BEGIN
    SELECT COALESCE(
        (SELECT `value` FROM settings WHERE `key` = 'stats.visitor_count'),
        '0'
    ) as count;
END$$

-- Procedure: Increment visitor count
CREATE PROCEDURE sp_increment_visitor_count()
BEGIN
    INSERT INTO settings (`key`, `value`) 
    VALUES ('stats.visitor_count', '1')
    ON DUPLICATE KEY UPDATE 
        `value` = CAST(CAST(`value` AS UNSIGNED) + 1 AS CHAR);
END$$

-- Procedure: Search archive items
CREATE PROCEDURE sp_search_archive_items(
    IN search_term VARCHAR(255),
    IN item_type VARCHAR(50),
    IN start_date DATE,
    IN end_date DATE
)
BEGIN
    SELECT * FROM archive_items
    WHERE is_published = true
    AND (search_term IS NULL OR search_term = '' OR 
         MATCH(title, description, content) AGAINST(search_term IN NATURAL LANGUAGE MODE))
    AND (item_type IS NULL OR item_type = '' OR archive_items.item_type = item_type)
    AND (start_date IS NULL OR date >= start_date)
    AND (end_date IS NULL OR date <= end_date)
    ORDER BY date DESC;
END$$

DELIMITER ;

-- =====================================================
-- VIEWS FOR COMMON QUERIES
-- =====================================================

-- View: Active events with creator info
CREATE VIEW v_active_events AS
SELECT 
    e.*,
    u.username as creator_username,
    u.first_name as creator_first_name,
    u.last_name as creator_last_name
FROM events e
LEFT JOIN users u ON e.created_by = u.id
WHERE e.date >= CURRENT_DATE
ORDER BY e.date ASC;

-- View: Published archive items with media count
CREATE VIEW v_archive_with_media_count AS
SELECT 
    ai.*,
    COUNT(am.id) as media_count
FROM archive_items ai
LEFT JOIN archive_media am ON ai.id = am.archive_item_id
WHERE ai.is_published = true
GROUP BY ai.id;

-- View: User activity summary
CREATE VIEW v_user_activity AS
SELECT 
    u.id,
    u.username,
    u.first_name,
    u.last_name,
    u.role,
    COUNT(DISTINCT e.id) as events_created,
    COUNT(DISTINCT ai.id) as archive_items_created,
    COUNT(DISTINCT al.id) as admin_actions,
    MAX(al.timestamp) as last_activity
FROM users u
LEFT JOIN events e ON u.id = e.created_by
LEFT JOIN archive_items ai ON u.id = ai.created_by
LEFT JOIN admin_logs al ON u.id = al.user_id
GROUP BY u.id;

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- Additional performance indexes
CREATE INDEX idx_archive_items_published_featured ON archive_items(is_published, is_featured);
CREATE INDEX idx_media_items_type_created ON media_items(media_type, created_at);
CREATE INDEX idx_events_date_category ON events(date, category);
CREATE INDEX idx_admin_logs_user_timestamp ON admin_logs(user_id, timestamp);

-- =====================================================
-- TRIGGERS FOR DATA INTEGRITY
-- =====================================================

DELIMITER $$

-- Trigger: Update archive item view count
CREATE TRIGGER tr_increment_view_count
BEFORE UPDATE ON archive_items
FOR EACH ROW
BEGIN
    IF NEW.view_count != OLD.view_count THEN
        SET NEW.updated_at = CURRENT_TIMESTAMP;
    END IF;
END$$

-- Trigger: Log user deletions
CREATE TRIGGER tr_log_user_deletion
BEFORE DELETE ON users
FOR EACH ROW
BEGIN
    INSERT INTO admin_logs (user_id, action, details, resource_type, resource_id)
    VALUES (OLD.id, 'USER_DELETED', CONCAT('User ', OLD.username, ' deleted'), 'user', OLD.id);
END$$

DELIMITER ;

-- =====================================================
-- GRANT PERMISSIONS (Adjust as needed)
-- =====================================================

-- Example: Create application user with limited permissions
-- CREATE USER 'kark_app'@'localhost' IDENTIFIED BY 'secure_password';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON kark_database.* TO 'kark_app'@'localhost';
-- GRANT EXECUTE ON kark_database.* TO 'kark_app'@'localhost';
-- FLUSH PRIVILEGES;

-- =====================================================
-- DATABASE CONFIGURATION COMPLETE
-- =====================================================

-- Final check
SELECT 'KARK Database Setup Complete!' as Status,
       (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'kark_database') as 'Total Tables',
       (SELECT COUNT(*) FROM users) as 'Total Users',
       (SELECT COUNT(*) FROM settings) as 'Total Settings';