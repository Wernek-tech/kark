#!/bin/bash

echo "🔍 Simple VPS Debug..."

cd /var/www/kark

# Check PM2 logs for errors
echo "=== PM2 Error Logs ==="
pm2 logs --err --lines 20

# Check if the built server file works
echo -e "\n=== Test Built Server Directly ==="
node dist/server.js &
SERVER_PID=$!
sleep 2
curl http://localhost:5000/api/visitor-count || echo "Direct server test failed"
kill $SERVER_PID 2>/dev/null

# Show PM2 detailed status
echo -e "\n=== PM2 Detailed Status ==="
pm2 show 0

# Check if it's a port binding issue
echo -e "\n=== Port Check ==="
ss -tlnp | grep :5000 || echo "Port 5000 is free"