# Complete VPS Deployment Fix

## Root Problem
Your VPS is trying to run `node dist/index.js` but the TypeScript hasn't been compiled to JavaScript.

## Three Solutions (Try in Order)

### Solution 1: Build TypeScript Properly
```bash
cd /var/www/kark
pm2 stop kark-website
pm2 delete kark-website

# Install all dependencies
npm install

# Build the project
npm run build

# Check if build succeeded
ls -la dist/
# You should see index.js file

# If build succeeded, start PM2
pm2 start ecosystem.config.cjs
pm2 logs kark-website
```

### Solution 2: Use TypeScript Directly (Recommended)
If build fails, run TypeScript directly:

```bash
cd /var/www/kark
pm2 stop kark-website
pm2 delete kark-website

# Create new PM2 config that runs TypeScript directly
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'npx',
    args: 'tsx server/index.ts',
    cwd: process.cwd(),
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-session-secret-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    }
  }]
}
EOF

# Install tsx if not present
npm install -g tsx

# Start with TypeScript
pm2 start ecosystem.config.cjs
pm2 logs kark-website
```

### Solution 3: Simple Node.js Start
Use the development approach:

```bash
cd /var/www/kark
pm2 stop kark-website
pm2 delete kark-website

# Create simple PM2 config
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'npm',
    args: 'run dev',
    cwd: process.cwd(),
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-session-secret-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    }
  }]
}
EOF

pm2 start ecosystem.config.cjs
pm2 logs kark-website
```

## Environment File
Create this `.env` file in all solutions:

```bash
cat > .env << 'EOF'
NODE_ENV=production
PORT=5000
DB_TYPE=json
SESSION_SECRET=kark-vps-session-secret-2025
TRUST_PROXY=true
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
EOF
```

## Expected Success Output
After running any solution, you should see in `pm2 logs kark-website`:
```
serving on port 5000
```

## Verification
1. `pm2 status` - should show "online"
2. `curl http://localhost:5000` - should return HTML
3. `curl http://localhost:5000/api/user` - should return 401 (expected)
4. Open browser: `http://your-vps-ip:5000/admin`

## If Still Blank Admin Panel
After fixing the server startup, if admin still goes blank:

```bash
# Clear browser cache completely
# Or try incognito mode
# Or try different browser

# Test direct API calls
curl -c cookies.txt -X POST http://localhost:5000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"supermanager","password":"admin123"}'

curl -b cookies.txt http://localhost:5000/api/user
```

## Debug Commands
```bash
# Check PM2 status
pm2 status

# Check logs in real-time
pm2 logs kark-website --lines 50

# Check if port is listening
netstat -tlnp | grep :5000

# Check disk space
df -h

# Check memory
free -h
```