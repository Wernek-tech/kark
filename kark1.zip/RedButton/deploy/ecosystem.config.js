// PM2 Ecosystem Configuration for KARK Website
module.exports = {
  apps: [
    {
      name: 'kark-website',
      script: 'tsx',
      args: 'server/index.ts',
      cwd: '/var/www/kark',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
        HOST: '127.0.0.1'
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
        HOST: '127.0.0.1'
      },
      // Restart configuration
      watch: false,
      max_memory_restart: '1G',
      restart_delay: 5000,
      max_restarts: 10,
      min_uptime: '10s',
      
      // Logging
      log_file: '/var/log/pm2/kark-website.log',
      out_file: '/var/log/pm2/kark-website-out.log',
      error_file: '/var/log/pm2/kark-website-error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      
      // Advanced settings
      kill_timeout: 5000,
      listen_timeout: 10000,
      
      // Health monitoring
      health_check_url: 'http://127.0.0.1:3000/health',
      health_check_grace_period: 3000
    }
  ]
};