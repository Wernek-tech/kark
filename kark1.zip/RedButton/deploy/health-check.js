#!/usr/bin/env node

// Health check script for KARK website
import http from 'http';

const HEALTH_CHECK_URL = 'http://127.0.0.1:3000/health';
const WEBSITE_URL = 'http://127.0.0.1:3000/';

function checkEndpoint(url, name) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    
    const req = http.get(url, (res) => {
      const responseTime = Date.now() - startTime;
      
      if (res.statusCode === 200) {
        console.log(`✅ ${name}: OK (${responseTime}ms)`);
        resolve(true);
      } else {
        console.log(`❌ ${name}: Failed (Status: ${res.statusCode})`);
        resolve(false);
      }
    });
    
    req.on('error', (error) => {
      console.log(`❌ ${name}: Error - ${error.message}`);
      resolve(false);
    });
    
    req.setTimeout(5000, () => {
      console.log(`❌ ${name}: Timeout`);
      req.destroy();
      resolve(false);
    });
  });
}

async function runHealthCheck() {
  console.log('🔍 KARK Website Health Check');
  console.log('============================');
  console.log(`📅 ${new Date().toISOString()}`);
  console.log('');
  
  const results = await Promise.all([
    checkEndpoint(HEALTH_CHECK_URL, 'Health Endpoint'),
    checkEndpoint(WEBSITE_URL, 'Main Website'),
  ]);
  
  const allHealthy = results.every(result => result === true);
  
  console.log('');
  console.log(`📊 Overall Status: ${allHealthy ? '✅ HEALTHY' : '❌ UNHEALTHY'}`);
  
  if (!allHealthy) {
    console.log('');
    console.log('🔧 Troubleshooting:');
    console.log('- Check PM2 process: pm2 status');
    console.log('- View logs: pm2 logs kark-website');
    console.log('- Restart: pm2 restart kark-website');
    console.log('- Check Nginx: sudo systemctl status nginx');
  }
  
  process.exit(allHealthy ? 0 : 1);
}

runHealthCheck();