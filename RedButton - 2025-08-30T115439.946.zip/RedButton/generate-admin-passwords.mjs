import bcrypt from 'bcryptjs';

// Function to generate bcrypt hash
async function generatePasswordHash(password) {
    const saltRounds = 10;
    const hash = await bcrypt.hash(password, saltRounds);
    return hash;
}

// Generate hashes for admin passwords
async function generateAdminPasswords() {
    console.log('=== KARK Admin Password Hash Generator ===\n');
    
    // Default passwords (you should change these)
    const passwords = {
        supermanager: 'SuperAdmin123!',
        admin: 'Admin123!'
    };
    
    console.log('Generating bcrypt hashes for admin users...\n');
    
    for (const [username, password] of Object.entries(passwords)) {
        const hash = await generatePasswordHash(password);
        console.log(`Username: ${username}`);
        console.log(`Password: ${password}`);
        console.log(`Hash: ${hash}`);
        console.log('---');
    }
    
    console.log('\nIMPORTANT: Change these default passwords immediately after first login!');
    console.log('Copy the hash values above and replace $2b$10$YourHashHere in the SQL file.');
}

// Run the generator
generateAdminPasswords().catch(console.error);