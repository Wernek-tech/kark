module.exports = {
  apps: [{
    name: 'kark-production',
    script: 'npm',
    args: 'start',
    cwd: process.cwd(),
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    },
    // Production-specific settings
    log_file: '/var/log/pm2/kark-production.log',
    out_file: '/var/log/pm2/kark-production-out.log',
    error_file: '/var/log/pm2/kark-production-error.log',
    merge_logs: true,
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
}