import { db } from "../server/db";
import { users } from "../shared/schema";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import { eq } from "drizzle-orm";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function createUsers() {
  try {
    // Create supermanager with correct password
    const superPwd = await hashPassword("supermanager123");
    console.log("Supermanager password hash:", superPwd);
    
    // Create or update the supermanager user
    const existingSuper = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, "supermanager")
    });
    
    if (existingSuper) {
      console.log("Updating existing supermanager account");
      await db.update(users)
        .set({ password: superPwd })
        .where(eq(users.username, "supermanager"))
        .execute();
    } else {
      console.log("Creating new supermanager account");
      await db.insert(users).values({
        username: "supermanager",
        password: superPwd,
        firstName: "Super",
        lastName: "Manager",
        email: "super@example.com",
        isAdmin: true,
        role: "major_admin",
        permissions: ["manage_users", "manage_events", "manage_media", "manage_team", "manage_donations", "manage_settings", "manage_sliders", "manage_admins"],
      }).execute();
    }
    
    // Create or update admin user
    const adminPwd = await hashPassword("admin123");
    console.log("Admin password hash:", adminPwd);
    
    const existingAdmin = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, "admin")
    });
    
    if (existingAdmin) {
      console.log("Updating existing admin account");
      await db.update(users)
        .set({ password: adminPwd })
        .where(eq(users.username, "admin"))
        .execute();
    } else {
      console.log("Creating new admin account");
      await db.insert(users).values({
        username: "admin",
        password: adminPwd,
        firstName: "Admin",
        lastName: "User",
        email: "admin@example.com",
        isAdmin: true,
        role: "admin",
        permissions: ["manage_events", "manage_media", "manage_team"],
      }).execute();
    }
    
    // Create test user
    const testPwd = await hashPassword("test123");
    console.log("Test user password hash:", testPwd);
    
    const existingTest = await db.query.users.findFirst({
      where: (users, { eq }) => eq(users.username, "test")
    });
    
    if (existingTest) {
      console.log("Updating existing test account");
      await db.update(users)
        .set({ password: testPwd })
        .where(eq(users.username, "test"))
        .execute();
    } else {
      console.log("Creating new test account");
      await db.insert(users).values({
        username: "test",
        password: testPwd,
        firstName: "Test",
        lastName: "User",
        email: "test@example.com",
        isAdmin: false,
        role: "user",
        permissions: null,
      }).execute();
    }
    
    console.log("\nUser accounts updated. Use these credentials to log in:");
    console.log("- Supermanager: username=supermanager, password=supermanager123");
    console.log("- Admin: username=admin, password=admin123");
    console.log("- Test User: username=test, password=test123");
    
  } catch (error) {
    console.error("Error creating/updating users:", error);
  }
}

createUsers();