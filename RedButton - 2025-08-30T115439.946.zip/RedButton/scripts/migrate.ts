import { db } from '../server/db';
import { migrate } from 'drizzle-orm/postgres-js/migrator';
import path from 'path';

// Run migrations
async function main() {
  console.log('Running migrations...');
  
  try {
    await migrate(db, { migrationsFolder: path.join(process.cwd(), 'migrations') });
    console.log('Migrations completed successfully');
  } catch (error) {
    console.error('Migration error:', error);
    process.exit(1);
  }
  
  console.log('Finished running migrations');
  process.exit(0);
}

main();