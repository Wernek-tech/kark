#!/bin/bash

# KARK Website VPS Fix for Cloudflare Setup
echo "🔧 KARK Website VPS Fix (Cloudflare Setup)..."

# Navigate to application directory
cd /var/www/kark || exit 1

# 1. Stop existing services
echo "Stopping existing services..."
pm2 stop all 2>/dev/null || true
pm2 delete all 2>/dev/null || true

# 2. Build application
echo "Building application..."
npm run build

# 3. Create PM2 configuration
echo "Creating PM2 configuration..."
cat > ecosystem.production.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'dist/index.js',
    cwd: '/var/www/kark',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax',
      HOST: '0.0.0.0'
    }
  }]
}
EOF

# 4. Start with PM2
echo "Starting application with PM2..."
pm2 start ecosystem.production.cjs --env production
pm2 save
pm2 startup systemd -u $USER --hp /home/$USER

# 5. Create NGINX configuration for Cloudflare
echo "Configuring NGINX for Cloudflare..."
sudo tee /etc/nginx/sites-available/kark > /dev/null << 'EOF'
# KARK Website - Cloudflare Configuration
server {
    listen 80;
    listen [::]:80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;
    
    # Real IP from Cloudflare
    set_real_ip_from 173.245.48.0/20;
    set_real_ip_from 103.21.244.0/22;
    set_real_ip_from 103.22.200.0/22;
    set_real_ip_from 103.31.4.0/22;
    set_real_ip_from 141.101.64.0/18;
    set_real_ip_from 108.162.192.0/18;
    set_real_ip_from 190.93.240.0/20;
    set_real_ip_from 188.114.96.0/20;
    set_real_ip_from 197.234.240.0/22;
    set_real_ip_from 198.41.128.0/17;
    set_real_ip_from 162.158.0.0/15;
    set_real_ip_from 104.16.0.0/13;
    set_real_ip_from 104.24.0.0/14;
    set_real_ip_from 172.64.0.0/13;
    set_real_ip_from 131.0.72.0/22;
    set_real_ip_from 2400:cb00::/32;
    set_real_ip_from 2606:4700::/32;
    set_real_ip_from 2803:f800::/32;
    set_real_ip_from 2405:b500::/32;
    set_real_ip_from 2405:8100::/32;
    set_real_ip_from 2a06:98c0::/29;
    set_real_ip_from 2c0f:f248::/32;
    
    real_ip_header CF-Connecting-IP;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # Proxy timeouts
    proxy_connect_timeout 60s;
    proxy_send_timeout 60s;
    proxy_read_timeout 60s;
    proxy_buffer_size 4k;
    proxy_buffers 8 4k;
    proxy_busy_buffers_size 8k;
    
    # Main proxy configuration
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        
        # Headers for proper proxying
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $http_x_forwarded_proto;
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header X-Forwarded-Port $server_port;
        
        # WebSocket support
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_cache_bypass $http_upgrade;
        
        # Disable buffering for SSE
        proxy_buffering off;
    }
    
    # API routes with specific handling
    location /api {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $http_x_forwarded_proto;
        
        # API specific timeouts
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
    
    # Health check endpoint
    location /health {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        access_log off;
    }
    
    # Static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        proxy_pass http://127.0.0.1:5000;
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
    
    # Deny access to hidden files
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
    
    # Error pages
    error_page 502 503 504 /50x.html;
    location = /50x.html {
        root /var/www/html;
        internal;
    }
}
EOF

# 6. Create error page
sudo mkdir -p /var/www/html
sudo tee /var/www/html/50x.html > /dev/null << 'EOF'
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KARK - Geçici Bakım</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            text-align: center;
            padding: 50px;
            background: #f5f5f5;
            color: #333;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 { color: #e74c3c; margin-bottom: 20px; }
        p { margin: 20px 0; line-height: 1.6; }
        a { color: #3498db; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h1>KARK - Kuzey Kıbrıs Arama Kurtarma</h1>
        <p>Sitemiz şu anda bakım modunda. Lütfen birkaç dakika sonra tekrar deneyin.</p>
        <p>Acil durumlar için: <a href="tel:+905338765432">0533 876 54 32</a></p>
        <p><a href="/">Ana Sayfaya Dön</a></p>
    </div>
</body>
</html>
EOF

# 7. Enable site and restart NGINX
sudo ln -sf /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# 8. Create health check endpoint if missing
echo "Adding health check endpoint..."
cat > add-health-check.js << 'EOF'
const fs = require('fs');
const path = require('path');

const indexPath = path.join(__dirname, 'server/index.ts');
let content = fs.readFileSync(indexPath, 'utf8');

// Add health check route if not exists
if (!content.includes('/api/health')) {
    const routeRegistration = 'registerRoutes(app);';
    const healthRoute = `
// Health check endpoint
app.get('/api/health', (req: Request, res: Response) => {
    res.json({ 
        status: 'ok', 
        timestamp: new Date().toISOString(),
        uptime: process.uptime()
    });
});

${routeRegistration}`;
    
    content = content.replace(routeRegistration, healthRoute);
    fs.writeFileSync(indexPath, content);
    console.log('✅ Health check endpoint added');
} else {
    console.log('✅ Health check endpoint already exists');
}
EOF

node add-health-check.js
rm add-health-check.js

# 9. Rebuild and restart
npm run build
pm2 restart all

# 10. Status check
echo ""
echo "🔍 Status Check:"
echo "===================="
pm2 list
echo ""
echo "Testing local connection..."
curl -s http://localhost:5000/health | jq . || echo "Health check failed"
echo ""
echo "NGINX status:"
sudo systemctl status nginx --no-pager -l
echo ""

echo "✅ VPS Cloudflare Fix Complete!"
echo ""
echo "Next steps:"
echo "1. Ensure Cloudflare DNS points to this server"
echo "2. Set Cloudflare SSL mode to 'Flexible' or 'Full'"
echo "3. Enable Cloudflare proxy (orange cloud)"
echo "4. Test: https://kibrisaramakurtarma.org"
echo ""
echo "Monitor logs:"
echo "- PM2: pm2 logs"
echo "- NGINX: sudo tail -f /var/log/nginx/error.log"