#!/bin/bash

echo "=== VPS Connection Refused Fix ==="
echo "Diagnosing and fixing external access to port 5000..."

# 1. Check if server is actually listening on the right interface
echo "Step 1: Checking what ports are listening..."
echo "Current listening ports:"
netstat -tlnp | grep :5000 || ss -tlnp | grep :5000 || echo "No process listening on port 5000"

# 2. Check PM2 status
echo ""
echo "Step 2: PM2 Status:"
pm2 status

# 3. Force server to bind to all interfaces
echo ""
echo "Step 3: Updating server to bind to 0.0.0.0..."

# Update the server index.ts to explicitly bind to 0.0.0.0
cp server/index.ts server/index.ts.backup 2>/dev/null || true

# Check if the server is binding to 0.0.0.0
if ! grep -q "0.0.0.0" server/index.ts; then
    echo "Updating server to listen on all interfaces..."
    
    # Find the listen call and update it
    sed -i 's/app\.listen(PORT)/app.listen(PORT, "0.0.0.0")/g' server/index.ts 2>/dev/null || \
    sed -i 's/\.listen(port)/\.listen(port, "0.0.0.0")/g' server/index.ts 2>/dev/null || \
    echo "Could not automatically update server binding. Manual update needed."
fi

# 4. Restart PM2 with proper configuration
echo ""
echo "Step 4: Restarting PM2 with external access configuration..."
pm2 stop kark-website 2>/dev/null || true
pm2 delete kark-website 2>/dev/null || true

# Create comprehensive PM2 config
cat > ecosystem.external.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    autorestart: true,
    watch: false,
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      HOST: '0.0.0.0',
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-kibris-secret-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    }
  }]
}
EOF

pm2 start ecosystem.external.cjs

# 5. Check firewall rules
echo ""
echo "Step 5: Checking and configuring firewall..."

# UFW (Ubuntu/Debian)
if command -v ufw >/dev/null 2>&1; then
    echo "Configuring UFW firewall..."
    ufw allow 5000/tcp
    ufw status numbered
fi

# Firewalld (CentOS/RHEL)
if command -v firewall-cmd >/dev/null 2>&1; then
    echo "Configuring Firewalld..."
    firewall-cmd --permanent --add-port=5000/tcp
    firewall-cmd --reload
    firewall-cmd --list-ports
fi

# IPTables fallback
if command -v iptables >/dev/null 2>&1 && ! command -v ufw >/dev/null 2>&1 && ! command -v firewall-cmd >/dev/null 2>&1; then
    echo "Configuring IPTables..."
    iptables -I INPUT -p tcp --dport 5000 -j ACCEPT
    # Try to save iptables rules
    iptables-save > /etc/iptables/rules.v4 2>/dev/null || \
    service iptables save 2>/dev/null || \
    echo "Warning: Could not save iptables rules permanently"
fi

# 6. Wait and test
echo ""
echo "Step 6: Testing server startup..."
sleep 5

echo "PM2 Status after restart:"
pm2 status

echo ""
echo "Ports now listening:"
netstat -tlnp | grep :5000 || ss -tlnp | grep :5000

# 7. Test local connection
echo ""
echo "Step 7: Testing local connection..."
if curl -s http://localhost:5000 | head -1 | grep -q "DOCTYPE"; then
    echo "✓ Local connection works"
else
    echo "✗ Local connection failed"
    echo "PM2 logs:"
    pm2 logs kark-website --lines 5
fi

# 8. Show external IP and instructions
echo ""
echo "Step 8: External access information..."
EXTERNAL_IP=$(curl -s ifconfig.me 2>/dev/null || curl -s ipinfo.io/ip 2>/dev/null || echo "Unable to detect")
echo "Your VPS external IP: $EXTERNAL_IP"

echo ""
echo "=== Next Steps ==="
echo "1. Test access: http://$EXTERNAL_IP:5000"
echo "2. If still blocked, check your VPS provider's firewall/security groups"
echo "3. Contact your hosting provider if port 5000 is blocked at network level"
echo ""

# 9. Alternative port test
echo "Alternative: Try a different port (8080)..."
cat > ecosystem.port8080.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-alt-port',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    autorestart: true,
    env: {
      NODE_ENV: 'production',
      PORT: 8080,
      HOST: '0.0.0.0',
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-kibris-secret-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    }
  }]
}
EOF

echo "To try port 8080 instead:"
echo "pm2 start ecosystem.port8080.cjs"
echo "Then test: http://$EXTERNAL_IP:8080"
EOF