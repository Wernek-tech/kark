# Complete VPS Port 5000 Fix

## Problem Identified
Your VPS has 2 PM2 processes running but neither is listening on port 5000:
- `ecosystem.external` (running but not bound to port)
- `ecosystem.working` (running but not bound to port)

## Complete Fix for Your VPS

Copy and paste this entire command block into your VPS terminal:

```bash
cd /var/www/kark

# 1. Stop all PM2 processes
pm2 stop all
pm2 delete all
pm2 flush

# 2. Kill any remaining processes
pkill -f "node|tsx" 2>/dev/null || true

# 3. Fix server binding in code
cp server/index.ts server/index.ts.backup
sed -i 's/app\.listen(PORT)/app.listen(PORT, "0.0.0.0", () => console.log(`Server running on http:\/\/0.0.0.0:${PORT}`))/g' server/index.ts

# 4. Create working PM2 config
cat > ecosystem.final.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-final',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    autorestart: true,
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-kibris-secret-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    }
  }]
}
EOF

# 5. Start single process
pm2 start ecosystem.final.cjs

# 6. Wait and verify
sleep 5
echo "PM2 Status:"
pm2 status

echo "Port check:"
netstat -tlnp | grep :5000 || echo "Port 5000 not listening"

echo "Server test:"
curl -s http://localhost:5000 | head -1

echo "External IP test: http://$(curl -s ifconfig.me):5000"
```

## Expected Success Output

After running the fix, you should see:
1. `pm2 status` shows 1 process named `kark-final` as `online`
2. `netstat` shows something like: `tcp 0 0 0.0.0.0:5000 LISTEN`
3. `curl` returns HTML starting with `<!DOCTYPE html>`

## If Server Still Won't Bind to Port 5000

Try manual server test first:
```bash
cd /var/www/kark
PORT=5000 tsx server/index.ts
```

You should see: `Server running on http://0.0.0.0:5000`

## Alternative Port Solution

If port 5000 is blocked by your hosting provider:
```bash
# Try port 8080 instead
cat > ecosystem.port8080.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-port8080',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    autorestart: true,
    env: {
      NODE_ENV: 'production',
      PORT: 8080,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-kibris-secret-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    }
  }]
}
EOF

pm2 stop all; pm2 delete all
pm2 start ecosystem.port8080.cjs
```

Then test: `http://193.31.31.171:8080`

## NGINX Proxy Solution (Recommended)

Set up NGINX to proxy port 80 to your internal port:
```bash
# Edit NGINX config
nano /etc/nginx/sites-available/kibrisaramakurtarma.org

# Add this configuration:
server {
    listen 80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

# Enable and reload
ln -sf /etc/nginx/sites-available/kibrisaramakurtarma.org /etc/nginx/sites-enabled/
systemctl reload nginx
```

With NGINX proxy, access your site at:
- `http://kibrisaramakurtarma.org` (main site)
- `http://kibrisaramakurtarma.org/admin` (admin panel)

## Final Verification

Once working, test admin panel:
1. Go to admin panel URL
2. Login: `supermanager` / `admin123`
3. Verify admin panel doesn't go blank (session fix applied)

The key issue was multiple PM2 processes not properly binding to the port. This fix ensures a single, properly configured process.