# PM2 Session Authentication Fix

## Problem
PM2-deployed KARK website experiencing 403 authentication errors and session loss after login, even with correct auth.ts configuration.

## Root Cause
Missing environment variables for session configuration in PM2 deployment:
- No SESSION_SECRET defined
- Missing COOKIE_SECURE and COOKIE_SAME_SITE settings
- TRUST_PROXY not configured for Cloudflare proxy setup

## Solution Applied

### 1. Environment Configuration
Created `.env` file with essential session settings:
```env
NODE_ENV=production
PORT=5000
DB_TYPE=json
SESSION_SECRET=kark-super-secret-session-key-2025-kibris
TRUST_PROXY=true
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
```

### 2. PM2 Ecosystem Update
Updated `ecosystem.config.js` to include session variables:
```javascript
env: {
  NODE_ENV: 'production',
  PORT: 5000,
  DB_TYPE: 'json',
  SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
  TRUST_PROXY: 'true',
  COOKIE_SECURE: 'false',
  COOKIE_SAME_SITE: 'lax'
}
```

### 3. Deployment Commands
Use the provided script for proper PM2 restart:
```bash
# Run the fix script
./pm2-session-fix.sh

# Or manually:
pm2 stop kark-website
pm2 delete kark-website
pm2 start ecosystem.config.js --env production
```

## Key Settings Explained

- **SESSION_SECRET**: Unique secret for session encryption
- **TRUST_PROXY**: Enables Express to trust Cloudflare proxy headers
- **COOKIE_SECURE=false**: Allows cookies through Cloudflare proxy
- **COOKIE_SAME_SITE=lax**: Permits cross-origin session cookies

## For Production Server (kibrisaramakurtarma.org)

Copy these files to your production server:
1. `.env` (with same content)
2. Updated `ecosystem.config.js`
3. `pm2-session-fix.sh` script

Then run:
```bash
cd /var/www/kark
./pm2-session-fix.sh
```

## Verification
After applying fixes:
1. Admin login should maintain session
2. No 403 errors on authenticated pages
3. Admin panel remains accessible without blank screens
4. Session persistence across page navigation

## Admin Credentials
- Username: `supermanager`, Password: `admin123`
- Username: `admin`, Password: `Admin123!`