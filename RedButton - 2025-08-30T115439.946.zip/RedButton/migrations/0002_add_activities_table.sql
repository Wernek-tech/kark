-- Create activities table
CREATE TABLE IF NOT EXISTS "activities" (
  "id" serial PRIMARY KEY NOT NULL,
  "title" varchar(255) NOT NULL,
  "description" text NOT NULL,
  "category" varchar(100) NOT NULL,
  "image_url" text,
  "date" varchar(100),
  "link" varchar(255),
  "display_order" integer DEFAULT 0 NOT NULL,
  "is_active" boolean DEFAULT true NOT NULL,
  "created_at" timestamp DEFAULT now() NOT NULL,
  "created_by" integer,
  "updated_at" timestamp DEFAULT now() NOT NULL,
  "updated_by" integer
);

-- Add foreign key constraints
ALTER TABLE "activities" ADD CONSTRAINT "activities_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "users"("id") ON DELETE no action ON UPDATE no action;
ALTER TABLE "activities" ADD CONSTRAINT "activities_updated_by_users_id_fk" FOREIGN KEY ("updated_by") REFERENCES "users"("id") ON DELETE no action ON UPDATE no action;

-- Create index for display order
CREATE INDEX IF NOT EXISTS "activities_display_order_idx" ON "activities" ("display_order");

-- Migrate existing activity settings to the new table
INSERT INTO "activities" ("title", "description", "category", "image_url", "date", "link", "display_order", "is_active")
SELECT 
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity1_title'), 'Arama Kurtarma Eğitimi') as title,
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity1_description'), 'Ekip üyelerimiz için düzenlenen eğitim kampında, zorlu arazi şartlarında arama ve kurtarma teknikleri uygulamalı olarak gösterildi.') as description,
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity1_category'), 'Eğitim') as category,
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity1_image'), 'https://images.unsplash.com/photo-1541726260-e6b6a6a08b27?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=800') as image_url,
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity1_date'), '23 Nisan 2023') as date,
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity1_link'), '/photos') as link,
  1 as display_order,
  true as is_active
WHERE EXISTS (SELECT 1 FROM settings WHERE key LIKE 'home.activity1_%')
UNION ALL
SELECT 
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity2_title'), 'Deprem Bölgesi Operasyonu') as title,
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity2_description'), 'Son deprem bölgesinde gerçekleştirdiğimiz arama kurtarma çalışmalarında 8 vatandaşımızı enkaz altından sağ olarak çıkardık.') as description,
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity2_category'), 'Operasyon') as category,
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity2_image'), 'https://images.unsplash.com/photo-1542652184-04d26a7598de?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=800') as image_url,
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity2_date'), '15 Şubat 2023') as date,
  COALESCE((SELECT value FROM settings WHERE key = 'home.activity2_link'), '/photos') as link,
  2 as display_order,
  true as is_active
WHERE EXISTS (SELECT 1 FROM settings WHERE key LIKE 'home.activity2_%');