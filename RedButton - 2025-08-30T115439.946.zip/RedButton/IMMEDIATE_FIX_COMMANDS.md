# IMMEDIATE FIX - Run These Commands Now

Your nginx configuration still has SSL references. Here's the exact fix:

## Step 1: Check Current Nginx Configuration

```bash
# See what's currently in your nginx config
sudo cat /etc/nginx/sites-available/kibrisaramakurtarma
```

## Step 2: Replace with HTTP-Only Configuration

```bash
# Remove the broken configuration
sudo rm /etc/nginx/sites-enabled/kibrisaramakurtarma
sudo rm /etc/nginx/sites-available/kibrisaramakurtarma

# Copy the correct HTTP-only configuration
sudo cp /var/www/kark/nginx-http-only.conf /etc/nginx/sites-available/kibrisaramakurtarma

# Enable it
sudo ln -s /etc/nginx/sites-available/kibrisaramakurtarma /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# If test passes, restart nginx
sudo systemctl restart nginx
```

## Step 3: Start Your KARK Application

```bash
# Start your KARK app with PM2
cd /var/www/kark
pm2 start ecosystem.config.js
pm2 save

# Check if it's running
pm2 status
curl http://localhost:5000
```

## Step 4: Test HTTP Access

```bash
# Test if your site works on HTTP
curl -I http://kibrisaramakurtarma.org
```

## Step 5: Enable Firewall

```bash
# Enable firewall (answer 'y' when prompted)
sudo ufw enable
sudo ufw status
```

## Step 6: Get SSL Certificate (Only After Above Works)

```bash
# Only run this after HTTP is working
sudo certbot --nginx -d kibrisaramakurtarma.org -d www.kibrisaramakurtarma.org
```

The problem is your nginx configuration has SSL certificate paths that don't exist yet. We need to start with HTTP-only, then add SSL.