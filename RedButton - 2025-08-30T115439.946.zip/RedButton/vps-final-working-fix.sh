#!/bin/bash

# VPS Final Working Fix - Step by step approach
echo "🔧 VPS Final Working Fix - Step by step..."

cd /var/www/kark

# 1. Stop everything
echo "🛑 Stopping all processes..."
pm2 stop all
pm2 delete all
pkill -f node 2>/dev/null

# 2. Check if original npm start works
echo "🧪 Testing original npm start..."
timeout 10s npm start &
sleep 5
curl -s http://localhost:5000/api/visitor-count && echo "✅ npm start works" || echo "❌ npm start fails"
pkill -f node 2>/dev/null

# 3. If npm start works, use it directly with PM2
if curl -s http://localhost:5000/api/visitor-count > /dev/null 2>&1; then
    echo "✅ Using npm start approach..."
    
    cat > ecosystem.working.js << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-production',
    script: 'npm',
    args: 'start',
    cwd: '/var/www/kark',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    },
    log_file: '/var/log/pm2/kark-production.log',
    out_file: '/var/log/pm2/kark-production-out.log',
    error_file: '/var/log/pm2/kark-production-error.log',
    merge_logs: true,
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
};
EOF

else
    echo "❌ npm start failed, building fresh..."
    
    # Rebuild everything
    rm -rf dist/
    npm install
    npm run build
    
    # Test the built version
    timeout 10s node dist/index.js &
    sleep 5
    curl -s http://localhost:5000/api/visitor-count && echo "✅ Built version works" || echo "❌ Built version fails"
    pkill -f node 2>/dev/null
    
    # Create config for built version
    cat > ecosystem.working.js << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-production',
    script: 'node',
    args: 'dist/index.js',
    cwd: '/var/www/kark',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    },
    log_file: '/var/log/pm2/kark-production.log',
    out_file: '/var/log/pm2/kark-production-out.log',
    error_file: '/var/log/pm2/kark-production-error.log',
    merge_logs: true,
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
};
EOF
fi

# 4. Ensure directories exist
mkdir -p /var/log/pm2
mkdir -p data/sessions
chmod 755 data/sessions

# 5. Start PM2 with working config
echo "🚀 Starting PM2 with working config..."
pm2 start ecosystem.working.js

# 6. Wait and test
echo "⏳ Waiting for startup..."
sleep 10

echo "🔍 Testing API..."
curl -s http://localhost:5000/api/visitor-count && echo "✅ API is working!" || echo "❌ API still not working"

# 7. Show status and logs
echo "📊 PM2 Status:"
pm2 status

echo "📋 Recent logs:"
pm2 logs --lines 10

# 8. Save if working
if curl -s http://localhost:5000/api/visitor-count > /dev/null 2>&1; then
    echo "💾 Saving working configuration..."
    pm2 save
    pm2 startup
    echo "✅ Success! API is responding."
else
    echo "❌ Still not working. Check logs above."
    pm2 logs --err --lines 20
fi

echo "🔄 Restarting nginx..."
systemctl restart nginx

echo "✅ Fix attempt complete!"