# VPS Blank Admin Panel Fix

## Problem
Admin panel works perfectly in Replit but goes blank after authentication on VPS server (kibrisaramakurtarma.org).

## Root Cause Analysis
The issue occurs because:
1. VPS environment has different network/proxy configuration than Replit
2. Session cookies are not being properly maintained between requests
3. Browser security policies may be blocking session cookies on VPS
4. NGINX/Apache reverse proxy may be interfering with session handling

## Complete Fix for Your VPS

### Step 1: SSH into Your VPS
```bash
ssh root@your-vps-ip
cd /var/www/kark
```

### Step 2: Apply the VPS Fix
Run this command to create and execute the fix:

```bash
cat > vps-blank-admin-fix.sh << 'EOF'
#!/bin/bash
echo "=== Fixing VPS Blank Admin Panel Issue ==="

# Stop PM2
pm2 stop kark-website 2>/dev/null || true
pm2 delete kark-website 2>/dev/null || true

# Create VPS-specific environment
cat > .env << 'ENVEOF'
NODE_ENV=production
PORT=5000
DB_TYPE=json
SESSION_SECRET=kark-vps-kibris-2025-secret
TRUST_PROXY=true
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
COOKIE_HTTP_ONLY=true
COOKIE_MAX_AGE=86400000
ENVEOF

# Update PM2 config for VPS
cat > ecosystem.config.cjs << 'PMEOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'npm',
    args: 'start',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-kibris-2025-secret',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax',
      COOKIE_HTTP_ONLY: 'true'
    }
  }]
}
PMEOF

# Clear sessions and restart
rm -rf data/sessions 2>/dev/null || true
mkdir -p data/sessions
pm2 flush
pm2 start ecosystem.config.cjs

echo "Fix applied! Testing in 5 seconds..."
sleep 5
pm2 status
echo "Admin panel should now work at: http://kibrisaramakurtarma.org/admin"
EOF

chmod +x vps-blank-admin-fix.sh
./vps-blank-admin-fix.sh
```

### Step 3: NGINX Configuration Fix (if using NGINX)
If you're using NGINX, also update your NGINX config:

```bash
# Edit NGINX config
nano /etc/nginx/sites-available/kibrisaramakurtarma.org

# Add these lines inside the server block:
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto $scheme;
proxy_set_header Host $host;
proxy_set_header X-Real-IP $remote_addr;

# Reload NGINX
systemctl reload nginx
```

### Step 4: Browser Cache Clear
Clear your browser cache and cookies for kibrisaramakurtarma.org completely.

## Alternative Quick Test
If the above doesn't work, try accessing the admin panel directly via IP:
```
http://your-vps-ip:5000/admin
```

## Verification Steps
1. Open browser (preferably incognito/private mode)
2. Go to http://kibrisaramakurtarma.org/admin
3. Login with: supermanager / admin123
4. Admin panel should remain visible (not go blank)

## If Still Blank - Debug Steps
```bash
# Check PM2 logs in real-time
pm2 logs kark-website

# Check if session files are being created
ls -la data/sessions/

# Test session endpoint
curl -c cookies.txt -b cookies.txt -X POST http://localhost:5000/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"supermanager","password":"admin123"}'

# Test admin endpoint with cookies
curl -b cookies.txt http://localhost:5000/api/user
```

## Key Differences from Replit
- **Replit**: Automatic proxy handling, internal networking
- **VPS**: Manual proxy configuration, external networking, potential firewall issues
- **Session Storage**: VPS needs explicit session directory permissions
- **Cookie Security**: VPS requires specific cookie settings for domain/IP access