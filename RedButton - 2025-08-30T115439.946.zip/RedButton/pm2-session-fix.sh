#!/bin/bash

echo "=== KARK PM2 Session Fix Script ==="
echo "Fixing PM2 session authentication issues..."

# Stop existing PM2 process
echo "Stopping existing PM2 processes..."
pm2 stop kark-website 2>/dev/null || true
pm2 delete kark-website 2>/dev/null || true

# Clear PM2 logs
echo "Clearing PM2 logs..."
pm2 flush

# Create or update .env file with proper session settings
echo "Creating .env file with session configuration..."
cat > .env << 'EOF'
NODE_ENV=production
PORT=5000
DB_TYPE=json
SESSION_SECRET=kark-super-secret-session-key-2025-kibris
TRUST_PROXY=true
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
EOF

echo "Environment file created successfully."

# Start PM2 with the updated configuration
echo "Starting PM2 with session fixes..."
pm2 start ecosystem.config.js --env production

# Show PM2 status
echo "PM2 Status:"
pm2 status

# Show logs for a few seconds
echo "Checking application logs..."
timeout 10s pm2 logs kark-website --lines 20 || true

echo ""
echo "=== Fix Applied Successfully ==="
echo "Session configuration has been updated with:"
echo "- Proper session secret"
echo "- Trust proxy enabled for Cloudflare"
echo "- Secure cookies disabled for proxy compatibility"
echo "- Lax SameSite policy for cross-origin requests"
echo ""
echo "Your admin panel should now maintain sessions properly."
echo "Test your admin login at: http://your-domain/admin"