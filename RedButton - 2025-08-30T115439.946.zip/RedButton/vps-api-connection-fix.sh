#!/bin/bash

# VPS API Connection Fix Script for KARK Website
echo "🔧 Fixing VPS API Connection Issues..."

# 1. Check if Node.js backend is running
echo "🔍 Checking backend status..."
pm2 status

# 2. Check if port 5000 is accessible
echo "🔍 Testing port 5000..."
curl -s http://localhost:5000/api/visitor-count || echo "❌ Backend not responding"

# 3. Check PM2 logs for errors
echo "📋 Checking PM2 logs for errors..."
pm2 logs --lines 20

# 4. Check if build was successful
echo "🔍 Checking build output..."
ls -la /var/www/kark/dist/public/

# 5. Ensure all dependencies are installed
echo "📦 Installing dependencies..."
cd /var/www/kark
npm install

# 6. Build the project
echo "🔨 Building the project..."
npm run build

# 7. Stop and restart PM2 processes
echo "🔄 Restarting PM2 processes..."
pm2 stop all
pm2 delete all

# 8. Create necessary directories
echo "📁 Creating directories..."
mkdir -p /var/www/kark/data/sessions
chmod 755 /var/www/kark/data/sessions

# 9. Start with production config
echo "🚀 Starting with production config..."
pm2 start ecosystem.production.js --env production

# 10. Wait and test
echo "⏳ Waiting for startup..."
sleep 5

# 11. Test API endpoints
echo "🔍 Testing API endpoints..."
curl -s http://localhost:5000/api/visitor-count && echo "✅ API working" || echo "❌ API still not working"

# 12. Check nginx configuration
echo "🔍 Testing nginx configuration..."
nginx -t

# 13. Reload nginx
echo "🔄 Reloading nginx..."
systemctl reload nginx

# 14. Final status check
echo "📊 Final status check..."
pm2 status
systemctl status nginx --no-pager

echo "✅ API connection fix completed!"
echo "🌐 Test your website now at http://kibrisaramakurtarma.org"