# Quick Fix for Your Directory Structure

## Current Situation
Your KARK files are located at: `/var/www/kark/karksite/RedButtonSimulator`
They need to be at: `/var/www/kark`

## Commands to Run on Your Server

Connect to your server and run these commands:

```bash
# Connect to your VPS
ssh root@193.31.31.171

# Navigate to the kark directory
cd /var/www/kark

# Move all files from nested directory to root
cp -r karksite/RedButtonSimulator/* .
cp -r karksite/RedButtonSimulator/.* . 2>/dev/null || true

# Remove the nested directories
rm -rf karksite/

# Install dependencies
npm install

# Build the application
npm run build

# Set correct permissions
chown -R www-data:www-data /var/www/kark
chmod -R 755 /var/www/kark

# Check if everything is in place
ls -la

# You should now see files like:
# package.json, server/, client/, data/, etc.
```

## Alternative: Use the Fix Script

Or simply run the automated fix script:

```bash
cd /var/www/kark
chmod +x fix-directory-structure.sh
./fix-directory-structure.sh
```

After running either method, your files will be properly positioned and you can continue with the nginx deployment!