#!/bin/bash

# Force API to work - trying different approaches
echo "🔧 Forcing API to work..."

cd /var/www/kark

# Clean slate
pm2 stop all
pm2 delete all
pkill -f node 2>/dev/null

# Method 1: Direct node execution with PM2
echo "=== Method 1: Direct node with PM2 ==="
cat > pm2-direct.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-api',
    script: 'node',
    args: 'dist/index.js',
    cwd: '/var/www/kark',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris'
    }
  }]
}
EOF

pm2 start pm2-direct.cjs
sleep 5
curl -s http://localhost:5000/api/visitor-count && echo "✅ Method 1 works!" || echo "❌ Method 1 failed"

# If Method 1 failed, try Method 2
if ! curl -s http://localhost:5000/api/visitor-count > /dev/null 2>&1; then
    pm2 stop all && pm2 delete all
    
    echo -e "\n=== Method 2: NPM script with PM2 ==="
    cat > pm2-npm.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-api',
    script: 'npm',
    args: 'run start',
    cwd: '/var/www/kark',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    }
  }]
}
EOF
    
    pm2 start pm2-npm.cjs
    sleep 5
    curl -s http://localhost:5000/api/visitor-count && echo "✅ Method 2 works!" || echo "❌ Method 2 failed"
fi

# If both failed, try Method 3: Shell script wrapper
if ! curl -s http://localhost:5000/api/visitor-count > /dev/null 2>&1; then
    pm2 stop all && pm2 delete all
    
    echo -e "\n=== Method 3: Shell script wrapper ==="
    cat > start-kark.sh << 'EOF'
#!/bin/bash
cd /var/www/kark
export NODE_ENV=production
export PORT=5000
export DB_TYPE=json
export SESSION_SECRET=kark-super-secret-session-key-2025-kibris
node dist/index.js
EOF
    
    chmod +x start-kark.sh
    
    cat > pm2-shell.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-api',
    script: './start-kark.sh',
    cwd: '/var/www/kark'
  }]
}
EOF
    
    pm2 start pm2-shell.cjs
    sleep 5
    curl -s http://localhost:5000/api/visitor-count && echo "✅ Method 3 works!" || echo "❌ Method 3 failed"
fi

# Show final status
echo -e "\n=== Final Status ==="
pm2 status
curl -s http://localhost:5000/api/visitor-count && echo "✅ API is accessible!" || echo "❌ API still not working"

# If working, save
if curl -s http://localhost:5000/api/visitor-count > /dev/null 2>&1; then
    pm2 save
    echo "✅ Saved working configuration!"
else
    echo "📋 Check logs:"
    pm2 logs --lines 20
fi