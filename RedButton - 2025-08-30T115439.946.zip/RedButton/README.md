# KARK - Arama Kurtarma Derneği Web Sitesi

Bu proje, KARK Arama Kurtarma Derneği için geliştirilmiş kapsamlı bir web sitesidir. Site, derneğin faaliyetlerini, etkinliklerini, eğitim videolarını ve fotoğraf galerilerini tanıtmak, ekip üyelerini göstermek ve bağış toplamak için bir platform sağlar.

## İçerik

- [Genel Bakış](#genel-bakış)
- [Özellikler](#özellikler)
- [Teknolojiler](#teknolojiler)
- [Kurulum](#kurulum)
- [Admin Paneli](#admin-paneli)
- [Güvenlik Kayıtları](#güvenlik-kayıtları)
- [API Endpoints](#api-endpoints)
- [Veritabanı Şeması](#veritabanı-şeması)
- [Kullanım Kılavuzu](#kullanım-kılavuzu)

## Genel Bakış

Bu web sitesi, arama kurtarma derneği için modern bir web arayüzü sunar. Ziyaretçiler etkinlikleri görüntüleyebilir, fotoğraf ve video galerilerine erişebilir, bağış yapabilir ve iletişim kurabilir. Admin paneli sayesinde tüm içerikler yönetilebilir.

![Ana Sayfa Örnek](https://images.unsplash.com/photo-1584744982271-69ccbec775aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1280&h=720)

## Özellikler

### Genel Özellikler
- **Tepkili (Responsive) Tasarım**: Mobil, tablet ve masaüstü görünümleri
- **Çok Dilli Destek**: Türkçe arayüz
- **SEO Optimizasyonu**: Meta etiketleri ve yapılandırılmış veri
- **Güvenli Kimlik Doğrulama**: Admin girişi için güvenli kimlik doğrulama

### Ziyaretçi Özellikler
- **Ana Sayfa Slider**: Öne çıkan içerik ve haberler için özelleştirilebilir slider
- **Etkinlikler**: Kategorilendirilmiş etkinlik listesi (Arama Kurtarma, Eğitim, Bağış, Farkındalık)
- **Video Galerisi**: Eğitim ve tanıtım videoları
- **Fotoğraf Galerisi**: Albümlere ayrılmış fotoğraflar
- **Ekip Sayfası**: Ekip üyeleri hakkında bilgi
- **İletişim Formu**: Ziyaretçilerin mesaj gönderebileceği form
- **Bağış Sayfası**: Çeşitli bağış yöntemleri ve kampanyalar

### Admin Özellikleri
- **Dashboard**: Genel istatistikler ve özet bilgiler
- **İçerik Yönetimi**: Tüm içeriklerin yönetimi
  - Etkinlik ekleme, düzenleme, silme
  - Video ve fotoğraf yönetimi
  - Fotoğraf albümleri oluşturma
  - Ekip üyeleri yönetimi
  - Ana sayfa slider yönetimi
- **Bağış Yönetimi**: Bağış yöntemleri ve kampanyaları yönetme
- **Ayarlar**: Site ayarlarını düzenleme

## Teknolojiler

### Frontend
- **React**: UI yapısı için
- **TypeScript**: Tip güvenliği
- **Vite**: Hızlı geliştirme ve derleme
- **Tailwind CSS**: Stil ve tepkili tasarım
- **Shadcn/ui**: Component kütüphanesi
- **React Query**: Veri yönetimi
- **React Hook Form**: Form yönetimi
- **Zod**: Form doğrulama
- **Wouter**: Sayfa yönlendirmesi

### Backend
- **Express**: RESTful API sunucusu
- **Node.js**: Sunucu ortamı
- **PostgreSQL**: Veritabanı
- **Drizzle ORM**: Veritabanı erişimi
- **Passport.js**: Kimlik doğrulama

## Kurulum

### Gereksinimler
- Node.js (v20+)
- PostgreSQL (13+)
- npm veya yarn

### Adımlar

1. Repoyu klonlayın
```bash
git clone <repo-url>
cd <repo-name>
```

2. Bağımlılıkları yükleyin
```bash
npm install
```

3. `.env` dosyası oluşturun veya örnek dosyayı kopyalayın
```bash
cp .env.example .env
```

4. Veritabanını oluşturun
```bash
npm run db:push
```

5. Admin kullanıcı oluşturun
```bash
npm run create-admin
```

6. Uygulamayı başlatın
```bash
npm run dev
```

## Admin Paneli

Admin paneline `/auth` sayfasından erişebilirsiniz. Varsayılan giriş bilgileri:

- **Kullanıcı Adı**: supermanager
- **Şifre**: Admin123!

> **Not**: Güvenlik için ilk girişte şifrenizi değiştirmeniz önerilir.

## Güvenlik Kayıtları

Site, tüm admin işlemlerini detaylı bir şekilde kayıt altına almaktadır. Bu güvenlik kaydı sistemi aşağıdaki özelliklere sahiptir:

- **Detaylı IP Adresi Kaydı**: Tüm admin işlemleri için IP adresleri kaydedilir
- **Kullanıcı Cihaz Bilgileri**: User-Agent ve tarayıcı bilgileri detaylı olarak görüntülenir
- **İşletim Sistemi Bilgisi**: İşlem yapılan cihazın işletim sistemi analizi
- **Tarayıcı Bilgisi**: İşlem yapılan tarayıcı bilgileri
- **Cihaz Türü Tespiti**: Masaüstü, mobil, tablet veya diğer cihaz türü tespiti
- **Zaman Damgası**: Tüm işlemler için kesin zaman kaydı
- **İşlem Türü Filtreleme**: GET, POST, PUT, DELETE gibi işlem türlerine göre filtreleme
- **Kaynak Türü Filtreleme**: İşlem yapılan kaynak türüne göre filtreleme (etkinlikler, medya, bağışlar, vs.)

### Güvenlik Kayıtlarına Erişim

Yalnızca "major_admin" rolüne sahip kullanıcılar (supermanager) tüm güvenlik kayıtlarına erişebilir. Admin panelinde sağ üst köşedeki "Güvenlik Kayıtları" butonuna tıklayarak tüm kayıtlara erişilebilir.

### Admin Panel Özellikleri

#### Slider Yönetimi
Admin panelinde "Ana Sayfa Slider" menüsünden ana sayfada görünen slider'ları yönetebilirsiniz:
- Yeni slider ekleyebilirsiniz
- Mevcut slider'ları düzenleyebilirsiniz
- Slider'ları sıralayabilirsiniz
- Slider'ları aktif veya pasif yapabilirsiniz
- Slider'ları silebilirsiniz

Her slider için şu bilgileri girebilirsiniz:
- Başlık
- Açıklama
- Buton metni
- Buton linki
- Görsel URL'i
- Aktiflik durumu
- Görüntülenme sırası

#### Etkinlik Yönetimi
"Operasyonlar" menüsünden etkinlikleri yönetebilirsiniz:
- Etkinlik ekleyebilirsiniz
- Mevcut etkinlikleri düzenleyebilirsiniz
- Etkinlikleri silebilirsiniz

#### Medya Yönetimi
"Eğitim Videoları" ve "Fotoğraf Galerisi" menülerinden medya içeriklerini yönetebilirsiniz:
- Video ekleyebilirsiniz (YouTube bağlantıları)
- Fotoğraf ekleyebilirsiniz
- Albümler oluşturabilirsiniz
- İçerikleri düzenleyebilirsiniz

#### Ekip Yönetimi
"Ekip Üyeleri" menüsünden ekip üyelerini yönetebilirsiniz:
- Ekip üyesi ekleyebilirsiniz
- Mevcut üyeleri düzenleyebilirsiniz
- Üyeleri silebilirsiniz

#### Bağış Yönetimi
"Bağış Yönetimi" menüsünden bağış seçeneklerini yapılandırabilirsiniz:
- Bağış yöntemleri ekleyebilirsiniz (banka hesapları, vs.)
- Bağış kampanyaları oluşturabilirsiniz
- Hedef ve toplanan miktarları güncelleyebilirsiniz

#### Site Ayarları
"Ayarlar" menüsünden site genelindeki ayarları yapılandırabilirsiniz:
- Genel iletişim bilgileri
- Sosyal medya hesapları
- Ana sayfa içerikleri

## API Endpoints

### Kimlik Doğrulama Endpoints
- `POST /api/login`: Giriş işlemi
- `POST /api/logout`: Çıkış işlemi

### Etkinlik Endpoints
- `GET /api/events`: Tüm etkinlikleri getir
- `GET /api/events/:id`: Belirli bir etkinliği getir
- `GET /api/events?category=rescue`: Kategoriye göre etkinlikleri filtrele
- `POST /api/events`: Yeni etkinlik ekle (admin)
- `PUT /api/events/:id`: Etkinlik güncelle (admin)
- `DELETE /api/events/:id`: Etkinlik sil (admin)

### Medya Endpoints
- `GET /api/media`: Tüm medya öğelerini getir
- `GET /api/media?type=video`: Tüm videoları getir
- `GET /api/media?type=photo`: Tüm fotoğrafları getir
- `GET /api/media/:id`: Belirli bir medya öğesini getir
- `POST /api/media`: Yeni medya öğesi ekle (admin)
- `DELETE /api/media/:id`: Medya öğesi sil (admin)

### Albüm Endpoints
- `GET /api/albums`: Tüm albümleri getir
- `GET /api/albums/:id`: Belirli bir albümü getir
- `GET /api/albums/:id/media`: Albümdeki tüm medya öğelerini getir
- `POST /api/albums`: Yeni albüm ekle (admin)
- `PUT /api/albums/:id`: Albüm güncelle (admin)
- `DELETE /api/albums/:id`: Albüm sil (admin)

### Ekip Endpoints
- `GET /api/team`: Tüm ekip üyelerini getir
- `GET /api/team/:id`: Belirli bir ekip üyesini getir
- `POST /api/team`: Yeni ekip üyesi ekle (admin)
- `PUT /api/team/:id`: Ekip üyesi güncelle (admin)
- `DELETE /api/team/:id`: Ekip üyesi sil (admin)

### İletişim Endpoints
- `GET /api/contact`: Tüm iletişim mesajlarını getir (admin)
- `POST /api/contact`: Yeni iletişim mesajı gönder
- `PUT /api/contact/:id/read`: İletişim mesajını okundu olarak işaretle (admin)

### Ayarlar Endpoints
- `GET /api/settings`: Tüm ayarları getir
- `GET /api/settings/:key`: Belirli bir ayarı getir
- `PUT /api/settings/:key`: Ayar güncelle (admin)

### Bağış Endpoints
- `GET /api/donation/methods`: Tüm bağış yöntemlerini getir
- `GET /api/donation/campaigns`: Tüm bağış kampanyalarını getir
- `POST /api/donation/methods`: Yeni bağış yöntemi ekle (admin)
- `POST /api/donation/campaigns`: Yeni bağış kampanyası ekle (admin)
- `PUT /api/donation/methods/:id`: Bağış yöntemi güncelle (admin)
- `PUT /api/donation/campaigns/:id`: Bağış kampanyası güncelle (admin)
- `DELETE /api/donation/methods/:id`: Bağış yöntemi sil (admin)
- `DELETE /api/donation/campaigns/:id`: Bağış kampanyası sil (admin)

### Hero Slider Endpoints
- `GET /api/hero-sliders`: Tüm slider'ları getir
- `GET /api/hero-sliders?active=true`: Aktif slider'ları getir
- `GET /api/hero-sliders/:id`: Belirli bir slider'ı getir
- `POST /api/hero-sliders`: Yeni slider ekle (admin)
- `PUT /api/hero-sliders/:id`: Slider güncelle (admin)
- `PUT /api/hero-sliders/:id/order`: Slider sırasını güncelle (admin)
- `DELETE /api/hero-sliders/:id`: Slider sil (admin)

## Veritabanı Şeması

### Tablolar

#### `users`
Admin kullanıcıları için.

| Alan | Tür | Açıklama |
|------|-----|----------|
| id | SERIAL | Birincil anahtar |
| username | TEXT | Kullanıcı adı |
| password | TEXT | Şifrelenmiş parola |
| firstName | TEXT | Ad |
| lastName | TEXT | Soyad |
| email | TEXT | E-posta |
| isAdmin | BOOLEAN | Admin yetkisi |
| createdAt | TIMESTAMP | Oluşturulma tarihi |

#### `events`
Etkinlikler için.

| Alan | Tür | Açıklama |
|------|-----|----------|
| id | SERIAL | Birincil anahtar |
| title | TEXT | Etkinlik başlığı |
| description | TEXT | Etkinlik açıklaması |
| date | TIMESTAMP | Etkinlik tarihi |
| location | TEXT | Etkinlik konumu |
| imageUrl | TEXT | Etkinlik görseli |
| category | ENUM | Kategori (rescue, training, donation, awareness) |
| createdAt | TIMESTAMP | Oluşturulma tarihi |
| createdBy | INTEGER | Oluşturan kullanıcı |

#### `media_items`
Fotoğraf ve videolar için.

| Alan | Tür | Açıklama |
|------|-----|----------|
| id | SERIAL | Birincil anahtar |
| title | TEXT | Medya başlığı |
| description | TEXT | Medya açıklaması |
| filePath | TEXT | Dosya yolu veya URL |
| mediaType | ENUM | Medya türü (photo, video) |
| albumId | INTEGER | Albüm ID (Fotoğraflar için) |
| eventId | INTEGER | Etkinlik ID (İlişkili etkinlik varsa) |
| createdAt | TIMESTAMP | Oluşturulma tarihi |
| createdBy | INTEGER | Oluşturan kullanıcı |

#### `albums`
Fotoğraf albümleri için.

| Alan | Tür | Açıklama |
|------|-----|----------|
| id | SERIAL | Birincil anahtar |
| title | TEXT | Albüm başlığı |
| description | TEXT | Albüm açıklaması |
| coverImage | TEXT | Kapak görseli |
| createdAt | TIMESTAMP | Oluşturulma tarihi |
| createdBy | INTEGER | Oluşturan kullanıcı |

#### `team_members`
Ekip üyeleri için.

| Alan | Tür | Açıklama |
|------|-----|----------|
| id | SERIAL | Birincil anahtar |
| firstName | TEXT | Ad |
| lastName | TEXT | Soyad |
| position | TEXT | Pozisyon |
| bio | TEXT | Biyografi |
| imageUrl | TEXT | Profil görseli |
| order | INTEGER | Görüntülenme sırası |
| createdAt | TIMESTAMP | Oluşturulma tarihi |
| createdBy | INTEGER | Oluşturan kullanıcı |

#### `contact_messages`
İletişim mesajları için.

| Alan | Tür | Açıklama |
|------|-----|----------|
| id | SERIAL | Birincil anahtar |
| name | TEXT | İsim |
| email | TEXT | E-posta |
| phone | TEXT | Telefon |
| subject | TEXT | Konu |
| message | TEXT | Mesaj |
| isRead | BOOLEAN | Okunma durumu |
| createdAt | TIMESTAMP | Oluşturulma tarihi |

#### `settings`
Site ayarları için.

| Alan | Tür | Açıklama |
|------|-----|----------|
| id | SERIAL | Birincil anahtar |
| key | TEXT | Ayar anahtarı |
| value | TEXT | Ayar değeri |
| updatedAt | TIMESTAMP | Güncellenme tarihi |
| updatedBy | INTEGER | Güncelleyen kullanıcı |

#### `donation_methods`
Bağış yöntemleri için.

| Alan | Tür | Açıklama |
|------|-----|----------|
| id | SERIAL | Birincil anahtar |
| bankName | TEXT | Banka adı |
| accountName | TEXT | Hesap adı |
| iban | TEXT | IBAN |
| branchCode | TEXT | Şube kodu |
| accountNumber | TEXT | Hesap numarası |
| currency | TEXT | Para birimi |
| description | TEXT | Açıklama |
| createdAt | TIMESTAMP | Oluşturulma tarihi |
| createdBy | INTEGER | Oluşturan kullanıcı |
| updatedAt | TIMESTAMP | Güncellenme tarihi |
| updatedBy | INTEGER | Güncelleyen kullanıcı |

#### `donation_campaigns`
Bağış kampanyaları için.

| Alan | Tür | Açıklama |
|------|-----|----------|
| id | SERIAL | Birincil anahtar |
| title | TEXT | Kampanya başlığı |
| description | TEXT | Kampanya açıklaması |
| targetAmount | INTEGER | Hedef miktar |
| currentAmount | INTEGER | Şu anki miktar |
| endDate | TIMESTAMP | Bitiş tarihi |
| imageUrl | TEXT | Kampanya görseli |
| isActive | BOOLEAN | Aktiflik durumu |
| createdAt | TIMESTAMP | Oluşturulma tarihi |
| createdBy | INTEGER | Oluşturan kullanıcı |
| updatedAt | TIMESTAMP | Güncellenme tarihi |
| updatedBy | INTEGER | Güncelleyen kullanıcı |

#### `hero_sliders`
Ana sayfa slider'ları için.

| Alan | Tür | Açıklama |
|------|-----|----------|
| id | SERIAL | Birincil anahtar |
| title | TEXT | Slider başlığı |
| description | TEXT | Slider açıklaması |
| buttonText | TEXT | Buton metni |
| buttonLink | TEXT | Buton linki |
| imageUrl | TEXT | Slider görseli |
| isActive | BOOLEAN | Aktiflik durumu |
| order | INTEGER | Görüntülenme sırası |
| createdAt | TIMESTAMP | Oluşturulma tarihi |
| createdBy | INTEGER | Oluşturan kullanıcı |
| updatedAt | TIMESTAMP | Güncellenme tarihi |
| updatedBy | INTEGER | Güncelleyen kullanıcı |

## Kullanım Kılavuzu

### Slider Yönetimi

1. Admin paneline giriş yapın
2. Sol menüden "Ana Sayfa Slider" seçeneğine tıklayın
3. "Yeni Slider Ekle" butonuna tıklayarak yeni bir slider ekleyin
   - Başlık: Slider'ın ana başlığı (örn. "KARK Arama Kurtarma Derneği")
   - Açıklama: Başlığın altında görünecek açıklama
   - Buton Metni: Slider'da görünecek buton metni (örn. "Destek Ol")
   - Buton Linki: Butona tıklandığında gidilecek sayfa (örn. "/donations")
   - Görsel URL: Slider arka plan görseli (1920x1080 önerilir)
   - Aktif: Slider'ın ana sayfada görünüp görünmeyeceği
4. Mevcut slider'ları düzenlemek için ilgili slider'ın sağındaki menüyü açıp "Düzenle" seçeneğine tıklayın
5. Slider'ları sıralamak için yukarı-aşağı oklarını kullanın
6. Slider'ı silmek için ilgili slider'ın sağındaki menüyü açıp "Sil" seçeneğine tıklayın

### Eklenen Slider'ları Görüntüleme

Ana sayfada eklediğiniz slider'lar otomatik olarak görüntülenecektir. Slider'lar arasında geçiş yapmak için:

- Otomatik geçiş: 5 saniye aralıklarla otomatik geçiş yapılır
- Manuel geçiş: 
  - Yanlardaki ok tuşlarına tıklayın
  - Alttaki noktalara tıklayın
  - Mobil cihazlarda sağa/sola kaydırın

Slider'ların görünümüyle ilgili aşağıdaki özellikler mevcuttur:
- Metin ve buton sol tarafta görünür
- Arka plan görseli ekran boyutuna göre otomatik ölçeklenir
- Slider butonlarına tıklandığında ilgili sayfaya yönlendirilirsiniz

---

© 2025 KARK Arama Kurtarma Derneği. Tüm hakları saklıdır.