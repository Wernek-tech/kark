#!/bin/bash

# VPS Production Build Fix - Solves the Vite bundling issue
echo "🔧 Fixing VPS Production Build with clean separation..."

cd /var/www/kark

# 1. Stop all PM2 processes
echo "🛑 Stopping PM2 processes..."
pm2 stop all
pm2 delete all

# 2. Clean everything
echo "🧹 Cleaning build artifacts..."
rm -rf dist/
rm -rf node_modules/.cache/

# 3. Install all dependencies
echo "📦 Installing dependencies..."
npm install

# 4. Build frontend only (no server bundling)
echo "🔨 Building frontend..."
npx vite build

# 5. Build server separately with esbuild (excluding Vite)
echo "🔨 Building production server..."
npx esbuild server/index-production.ts \
  --platform=node \
  --packages=external \
  --bundle \
  --format=esm \
  --outfile=dist/server.js \
  --external:vite \
  --external:@vitejs/plugin-react \
  --external:@replit/vite-plugin-cartographer \
  --external:@replit/vite-plugin-runtime-error-modal

# 6. Verify builds
echo "🔍 Verifying build output..."
ls -la dist/
ls -la dist/public/

# 7. Test the built server
echo "🧪 Testing production server..."
timeout 10s node dist/server.js &
SERVER_PID=$!
sleep 3
curl -s http://localhost:5000/api/visitor-count && echo "✅ Production server works!" || echo "❌ Server test failed"
kill $SERVER_PID 2>/dev/null

# 8. Create clean PM2 config for production server
echo "⚙️  Creating production PM2 config..."
cat > ecosystem.production-clean.js << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-production',
    script: 'dist/server.js',
    cwd: '/var/www/kark',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    },
    log_file: '/var/log/pm2/kark-production.log',
    out_file: '/var/log/pm2/kark-production-out.log',
    error_file: '/var/log/pm2/kark-production-error.log',
    merge_logs: true,
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
};
EOF

# 9. Create directories
echo "📁 Creating directories..."
mkdir -p /var/log/pm2
mkdir -p data/sessions
chmod 755 data/sessions

# 10. Remove dev dependencies
echo "🗑️  Removing dev dependencies..."
npm prune --production

# 11. Start PM2 with clean config
echo "🚀 Starting PM2 with clean production server..."
pm2 start ecosystem.production-clean.js

# 12. Save configuration
echo "💾 Saving PM2 configuration..."
pm2 save

# 13. Final test
echo "🔍 Final verification..."
sleep 5
pm2 status
curl -s http://localhost:5000/api/visitor-count && echo "✅ Production deployment successful!" || echo "❌ Still having issues"

# 14. Restart nginx
echo "🔄 Restarting nginx..."
systemctl restart nginx

echo "✅ Clean Production Build Complete!"
echo "🌐 Website: http://kibrisaramakurtarma.org"
echo "📊 Monitor: pm2 monit"
echo "📋 Logs: pm2 logs"