#!/bin/bash

echo "=== Complete VPS Admin Panel Fix ==="
echo "Fixing blank admin panel after authentication on VPS..."

# Stop all PM2 processes
pm2 stop all 2>/dev/null || true
pm2 delete all 2>/dev/null || true

# Create VPS-optimized .env file
cat > .env << 'EOF'
NODE_ENV=production
PORT=5000
DB_TYPE=json
SESSION_SECRET=kark-vps-session-secret-2025
TRUST_PROXY=true
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
COOKIE_HTTP_ONLY=true
COOKIE_MAX_AGE=86400000
CORS_ORIGIN=*
EOF

# Update ecosystem config for VPS
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'npm',
    args: 'start',
    cwd: process.cwd(),
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-session-secret-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax',
      COOKIE_HTTP_ONLY: 'true',
      CORS_ORIGIN: '*'
    }
  }]
}
EOF

# Clear browser-related cache/sessions
rm -rf data/sessions 2>/dev/null || true
mkdir -p data/sessions

# Clear PM2 logs and restart
pm2 flush
pm2 start ecosystem.config.cjs

echo ""
echo "=== VPS Fix Complete ==="
echo "Changes applied:"
echo "- VPS-specific session configuration"
echo "- Cleared existing session data"
echo "- Updated CORS settings"
echo "- Optimized cookie settings for VPS"
echo ""
echo "FOR YOUR VPS SERVER:"
echo "1. Copy this script to /var/www/kark/"
echo "2. Run: chmod +x vps-complete-fix.sh"
echo "3. Run: ./vps-complete-fix.sh"
echo ""
echo "If admin panel still goes blank, also run:"
echo "sudo systemctl reload nginx"
echo "pm2 restart kark-website"
EOF