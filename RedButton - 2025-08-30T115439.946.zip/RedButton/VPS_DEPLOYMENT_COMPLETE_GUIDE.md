# Complete KARK Website VPS Deployment Guide

## Overview
This guide provides the exact steps to deploy your KARK website on Ubuntu VPS, addressing the specific differences between Replit's automatic configuration and VPS requirements.

## Why Your Website Works in Replit but Fails on VPS

**Replit Automatically Provides:**
- Session handling with memory store
- Proxy configuration for HTTPS
- Port binding to 0.0.0.0
- Environment variable management
- Process management

**VPS Requires Manual Configuration:**
- NGINX reverse proxy setup
- SSL certificate configuration
- PM2 process management
- Session persistence configuration
- Firewall and security settings

## Step 1: Server Preparation

### Update System
```bash
sudo apt update
sudo apt upgrade -y
```

### Install Required Software
```bash
# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2, NGINX, and Certbot
sudo npm install -g pm2
sudo apt install nginx certbot python3-certbot-nginx -y

# Install Git if not present
sudo apt install git -y
```

## Step 2: Deploy Application Files

### Create Directory and Clone/Upload Files
```bash
# Create application directory
sudo mkdir -p /var/www/kark
sudo chown $USER:$USER /var/www/kark
cd /var/www/kark

# Upload your KARK files here (via SCP, Git, or file transfer)
# Make sure all files from your Replit project are copied
```

### Install Dependencies
```bash
cd /var/www/kark
npm install
```

## Step 3: Environment Configuration

### Create Production Environment File
```bash
cat > /var/www/kark/.env << 'EOF'
# Database Configuration
DB_TYPE=json
DATABASE_URL=postgresql://user:pass@localhost:5432/kark

# Session Configuration - CRITICAL FOR VPS
SESSION_SECRET=your-super-secure-random-session-secret-change-this
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
TRUST_PROXY=true

# Node Environment
NODE_ENV=production

# Port Configuration
PORT=5000
EOF
```

**⚠️ IMPORTANT:** Replace `your-super-secure-random-session-secret-change-this` with a strong random string.

## Step 4: Build Application
```bash
cd /var/www/kark
npm run build
```

## Step 5: PM2 Configuration

### Create PM2 Ecosystem File
```bash
cat > /var/www/kark/ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'dist/index.js',
    cwd: '/var/www/kark',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      // Critical session environment variables
      SESSION_SECRET: 'your-super-secure-random-session-secret-change-this',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax',
      TRUST_PROXY: 'true',
      DB_TYPE: 'json'
    },
    // VPS-specific configuration
    node_args: '--max-old-space-size=1024',
    exec_mode: 'fork',
    
    // Logging
    log_file: '/var/log/pm2/kark-combined.log',
    out_file: '/var/log/pm2/kark-out.log',
    error_file: '/var/log/pm2/kark-error.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
};
EOF
```

### Create Log Directory
```bash
sudo mkdir -p /var/log/pm2
sudo chown $USER:$USER /var/log/pm2
```

### Start Application with PM2
```bash
cd /var/www/kark
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup
```

## Step 6: NGINX Configuration

### Create NGINX Configuration
```bash
sudo tee /etc/nginx/sites-available/kark << 'EOF'
server {
    listen 80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    # Proxy to Node.js application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Session handling - CRITICAL
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header X-Forwarded-Server $host;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Static file serving
    location /static {
        alias /var/www/kark/dist/public;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/javascript;
}
EOF
```

### Enable Site
```bash
sudo ln -s /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## Step 7: SSL Certificate Setup

### Get SSL Certificate
```bash
sudo certbot --nginx -d kibrisaramakurtarma.org -d www.kibrisaramakurtarma.org
```

## Step 8: Firewall Configuration

### Configure UFW Firewall
```bash
sudo ufw allow 'Nginx Full'
sudo ufw allow ssh
sudo ufw --force enable
```

## Step 9: Final Configuration

### Set File Permissions
```bash
sudo chown -R $USER:$USER /var/www/kark
chmod -R 755 /var/www/kark
```

### Test Application
```bash
# Check PM2 status
pm2 status

# Check application logs
pm2 logs kark-website

# Test local connection
curl http://localhost:5000

# Check NGINX status
sudo systemctl status nginx
```

## Step 10: Admin Account Setup

### Default Admin Credentials
- **Username:** supermanager
- **Password:** admin123
- **Username:** admin  
- **Password:** Admin123!

### Access Admin Panel
- Visit: `https://kibrisaramakurtarma.org/admin`
- Login with supermanager credentials
- Change default passwords immediately

## Troubleshooting Common Issues

### Issue 1: 403 Errors After Login
**Solution:** Check session configuration in `.env` and `ecosystem.config.cjs`
```bash
# Restart PM2 with proper environment
pm2 restart kark-website
```

### Issue 2: Blank Admin Panel
**Solution:** Verify static file serving and build process
```bash
cd /var/www/kark
npm run build
pm2 restart kark-website
```

### Issue 3: Session Loss
**Solution:** Ensure TRUST_PROXY is set correctly
```bash
# Check PM2 environment
pm2 show kark-website
```

### Issue 4: NGINX 502 Errors
**Solution:** Check if Node.js application is running
```bash
pm2 status
pm2 restart kark-website
```

## Monitoring Commands

### Regular Maintenance
```bash
# View application logs
pm2 logs kark-website --lines 100

# Monitor application
pm2 monit

# Restart application
pm2 restart kark-website

# View NGINX logs
sudo tail -f /var/log/nginx/error.log
sudo tail -f /var/log/nginx/access.log
```

## Key Differences from Replit

1. **Session Handling:** VPS requires explicit session secret and proxy trust
2. **Port Binding:** VPS needs NGINX reverse proxy instead of direct port access
3. **HTTPS:** VPS requires SSL certificate setup
4. **Process Management:** VPS needs PM2 for application lifecycle
5. **Static Files:** VPS requires build process and static file serving configuration

## Security Notes

- Change default admin passwords immediately
- Use strong SESSION_SECRET
- Keep system updated
- Monitor logs regularly
- Configure proper backup strategy

## Support

If you encounter issues:
1. Check PM2 logs: `pm2 logs kark-website`
2. Check NGINX logs: `sudo tail -f /var/log/nginx/error.log`
3. Verify environment variables: `pm2 show kark-website`
4. Test local connection: `curl http://localhost:5000`

This configuration replicates the exact working setup from Replit and addresses all the differences that cause issues on VPS deployment.