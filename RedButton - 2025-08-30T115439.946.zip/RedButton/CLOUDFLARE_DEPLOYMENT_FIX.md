# KARK Website Deployment with Cloudflare

## The Cloudflare Difference

Since you're using Cloudflare, the SSL setup is different:
- **Cloudflare handles SSL termination** (between users and Cloudflare)
- **Your server only needs HTTP** (between Cloudflare and your server)
- **No need for Let's Encrypt certificates** on your server

## Cloudflare SSL Settings

In your Cloudflare dashboard, set:
- **SSL/TLS Mode:** "Flexible" or "Full" (not "Full (strict)")
- **Always Use HTTPS:** ON
- **Edge Certificates:** Enabled (automatic)

## Server Configuration (HTTP Only)

Your server should only serve HTTP on port 80:

```bash
# Remove any SSL configurations
sudo rm -f /etc/nginx/sites-enabled/kibrisaramakurtarma
sudo rm -f /etc/nginx/sites-available/kibrisaramakurtarma

# Create Cloudflare-compatible configuration
sudo tee /etc/nginx/sites-available/kibrisaramakurtarma > /dev/null << 'EOF'
server {
    listen 80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;
    
    # Cloudflare real IP restoration
    real_ip_header CF-Connecting-IP;
    set_real_ip_from 173.245.48.0/20;
    set_real_ip_from 103.21.244.0/22;
    set_real_ip_from 103.22.200.0/22;
    set_real_ip_from 103.31.4.0/22;
    set_real_ip_from 141.101.64.0/18;
    set_real_ip_from 108.162.192.0/18;
    set_real_ip_from 190.93.240.0/20;
    set_real_ip_from 188.114.96.0/20;
    set_real_ip_from 197.234.240.0/22;
    set_real_ip_from 198.41.128.0/17;
    set_real_ip_from 162.158.0.0/15;
    set_real_ip_from 104.16.0.0/13;
    set_real_ip_from 104.24.0.0/14;
    set_real_ip_from 172.64.0.0/13;
    set_real_ip_from 131.0.72.0/22;
    
    # Proxy to KARK application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300;
        proxy_connect_timeout 300;
        proxy_send_timeout 300;
    }
    
    # Health check endpoint
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
EOF

# Enable the site
sudo ln -s /etc/nginx/sites-available/kibrisaramakurtarma /etc/nginx/sites-enabled/

# Test and restart nginx
sudo nginx -t
sudo systemctl restart nginx
```

## Start KARK Application

```bash
cd /var/www/kark

# Start with PM2
pm2 start ecosystem.config.js
pm2 save
pm2 startup systemd

# Check status
pm2 status
```

## Firewall Configuration

Only allow HTTP (port 80) and SSH:

```bash
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw --force enable
sudo ufw status
```

## Testing

```bash
# Test local application
curl http://localhost:5000

# Test nginx proxy
curl -H "Host: kibrisaramakurtarma.org" http://localhost

# Test external access (should work through Cloudflare)
curl -I http://kibrisaramakurtarma.org
```

## Cloudflare DNS Settings

Make sure your DNS points to your server:
- **A Record:** kibrisaramakurtarma.org → 193.31.31.171 (Proxied: ON)
- **A Record:** www.kibrisaramakurtarma.org → 193.31.31.171 (Proxied: ON)

## No SSL Certificates Needed

With Cloudflare:
- ❌ **Don't run certbot**
- ❌ **Don't install SSL certificates**
- ✅ **Only serve HTTP on port 80**
- ✅ **Cloudflare handles HTTPS**

Your website will be accessible via HTTPS through Cloudflare, even though your server only serves HTTP.