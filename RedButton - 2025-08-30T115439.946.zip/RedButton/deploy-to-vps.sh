#!/bin/bash

# KARK Website VPS Deployment Script
# This script automates the deployment process on Ubuntu VPS

set -e  # Exit on any error

echo "🚀 Starting KARK Website VPS Deployment..."

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   print_error "This script should not be run as root. Please run as regular user with sudo privileges."
   exit 1
fi

# Validate domain name
if [ -z "$1" ]; then
    print_error "Usage: $0 <domain-name>"
    print_error "Example: $0 kibrisaramakurtarma.org"
    exit 1
fi

DOMAIN_NAME=$1
APP_DIR="/var/www/kark"

print_status "Deploying KARK website for domain: $DOMAIN_NAME"

# Step 1: Update system
print_status "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Step 2: Install Node.js 20
print_status "Installing Node.js 20..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
    print_status "Node.js $(node --version) installed"
else
    print_status "Node.js $(node --version) already installed"
fi

# Step 3: Install PM2
print_status "Installing PM2..."
if ! command -v pm2 &> /dev/null; then
    sudo npm install -g pm2
    print_status "PM2 installed"
else
    print_status "PM2 already installed"
fi

# Step 4: Install NGINX
print_status "Installing NGINX..."
if ! command -v nginx &> /dev/null; then
    sudo apt install nginx -y
    sudo systemctl enable nginx
    sudo systemctl start nginx
    print_status "NGINX installed and started"
else
    print_status "NGINX already installed"
fi

# Step 5: Install Certbot
print_status "Installing Certbot for SSL..."
if ! command -v certbot &> /dev/null; then
    sudo apt install certbot python3-certbot-nginx -y
    print_status "Certbot installed"
else
    print_status "Certbot already installed"
fi

# Step 6: Create application directory
print_status "Creating application directory..."
sudo mkdir -p $APP_DIR
sudo chown $USER:$USER $APP_DIR

# Step 7: Copy application files (assuming they're in current directory)
print_status "Copying application files..."
if [ -f "package.json" ]; then
    cp -r . $APP_DIR/
    print_status "Application files copied to $APP_DIR"
else
    print_warning "package.json not found in current directory"
    print_warning "Please manually copy your KARK website files to $APP_DIR"
    print_warning "Then run: cd $APP_DIR && npm install"
fi

# Step 8: Install dependencies
if [ -f "$APP_DIR/package.json" ]; then
    print_status "Installing application dependencies..."
    cd $APP_DIR
    npm install
    print_status "Dependencies installed"
fi

# Step 9: Create environment file
print_status "Creating environment configuration..."
cat > $APP_DIR/.env << EOF
# Database Configuration
DB_TYPE=json
DATABASE_URL=postgresql://user:pass@localhost:5432/kark

# Session Configuration - CRITICAL FOR VPS
SESSION_SECRET=$(openssl rand -base64 32)
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
TRUST_PROXY=true

# Node Environment
NODE_ENV=production

# Port Configuration
PORT=5000
EOF

print_status "Environment file created with secure session secret"

# Step 10: Build application
if [ -f "$APP_DIR/package.json" ]; then
    print_status "Building application..."
    cd $APP_DIR
    npm run build
    print_status "Application built successfully"
fi

# Step 11: Create PM2 ecosystem file
print_status "Creating PM2 configuration..."
cat > $APP_DIR/ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'dist/index.js',
    cwd: '$APP_DIR',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      SESSION_SECRET: '$(openssl rand -base64 32)',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax',
      TRUST_PROXY: 'true',
      DB_TYPE: 'json'
    },
    node_args: '--max-old-space-size=1024',
    exec_mode: 'fork',
    log_file: '/var/log/pm2/kark-combined.log',
    out_file: '/var/log/pm2/kark-out.log',
    error_file: '/var/log/pm2/kark-error.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
};
EOF

# Step 12: Create log directory
print_status "Creating log directory..."
sudo mkdir -p /var/log/pm2
sudo chown $USER:$USER /var/log/pm2

# Step 13: Start application with PM2
print_status "Starting application with PM2..."
cd $APP_DIR
pm2 start ecosystem.config.cjs
pm2 save
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Step 14: Configure NGINX
print_status "Configuring NGINX..."
sudo tee /etc/nginx/sites-available/kark << EOF
server {
    listen 80;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    # Proxy to Node.js application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        
        # Session handling - CRITICAL
        proxy_set_header X-Forwarded-Host \$host;
        proxy_set_header X-Forwarded-Server \$host;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Static file serving
    location /static {
        alias $APP_DIR/dist/public;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/javascript;
}
EOF

# Enable site
sudo ln -sf /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Step 15: Configure firewall
print_status "Configuring firewall..."
sudo ufw allow 'Nginx Full'
sudo ufw allow ssh
sudo ufw --force enable

# Step 16: Set file permissions
print_status "Setting file permissions..."
sudo chown -R $USER:$USER $APP_DIR
chmod -R 755 $APP_DIR

# Step 17: Test deployment
print_status "Testing deployment..."
sleep 5

# Check PM2 status
if pm2 list | grep -q "kark-website"; then
    print_status "✓ PM2 application is running"
else
    print_error "✗ PM2 application failed to start"
    pm2 logs kark-website --lines 20
fi

# Check local connection
if curl -s http://localhost:5000 > /dev/null; then
    print_status "✓ Application responds on localhost:5000"
else
    print_error "✗ Application not responding on localhost:5000"
fi

# Check NGINX status
if sudo systemctl is-active --quiet nginx; then
    print_status "✓ NGINX is running"
else
    print_error "✗ NGINX is not running"
fi

print_status "Deployment completed!"
echo ""
echo "🎉 KARK Website deployment summary:"
echo "   📁 Application: $APP_DIR"
echo "   🌐 Domain: http://$DOMAIN_NAME"
echo "   👤 Admin URL: http://$DOMAIN_NAME/admin"
echo "   📊 PM2 Status: pm2 status"
echo "   📝 Logs: pm2 logs kark-website"
echo ""
print_warning "Next steps:"
echo "1. Set up SSL certificate: sudo certbot --nginx -d $DOMAIN_NAME -d www.$DOMAIN_NAME"
echo "2. Access admin panel at http://$DOMAIN_NAME/admin"
echo "3. Login with: username 'supermanager', password 'admin123'"
echo "4. Change default admin passwords immediately!"
echo ""
print_status "If you encounter issues, check:"
echo "   - PM2 logs: pm2 logs kark-website"
echo "   - NGINX logs: sudo tail -f /var/log/nginx/error.log"
echo "   - Application status: curl http://localhost:5000"