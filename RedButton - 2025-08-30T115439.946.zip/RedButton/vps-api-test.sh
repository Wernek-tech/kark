#!/bin/bash

# KARK Website API Testing Script
echo "🔍 KARK Website API Testing"
echo "==========================="

BASE_URL="${1:-http://localhost:5000}"
echo "Testing against: $BASE_URL"
echo ""

# Color codes for output
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Test function
test_api() {
    local endpoint="$1"
    local method="${2:-GET}"
    local data="$3"
    local expected_status="${4:-200}"
    
    echo -n "Testing $method $endpoint... "
    
    if [ "$method" = "GET" ]; then
        response=$(curl -s -w "\n%{http_code}" "$BASE_URL$endpoint")
    else
        response=$(curl -s -w "\n%{http_code}" -X "$method" -H "Content-Type: application/json" -d "$data" "$BASE_URL$endpoint")
    fi
    
    status_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$status_code" = "$expected_status" ]; then
        echo -e "${GREEN}✓ $status_code${NC}"
        if [ -n "$body" ] && command -v jq &> /dev/null; then
            echo "$body" | jq '.' 2>/dev/null | head -5 || echo "$body" | head -5
        fi
    else
        echo -e "${RED}✗ $status_code (expected $expected_status)${NC}"
        echo "$body" | head -5
    fi
    echo ""
}

# Public API Tests
echo "📍 Public API Endpoints"
echo "----------------------"
test_api "/api/health"
test_api "/api/visitor-count"
test_api "/api/team"
test_api "/api/activities"
test_api "/api/events"
test_api "/api/media"
test_api "/api/albums"
test_api "/api/archive"
test_api "/api/operations"
test_api "/api/news"
test_api "/api/reports"
test_api "/api/hero-sliders"
test_api "/api/settings"
test_api "/api/donation/methods"
test_api "/api/donation/campaigns"
test_api "/api/contact"

# Authentication Tests
echo "🔐 Authentication Endpoints"
echo "--------------------------"
test_api "/api/user" "GET" "" "401"
test_api "/api/login" "POST" '{"username":"invalid","password":"invalid"}' "401"

# Admin API Tests (requires authentication)
echo "👤 Admin Endpoints (expect 401 without auth)"
echo "-------------------------------------------"
test_api "/api/users" "GET" "" "401"
test_api "/api/analytics/traffic" "GET" "" "401"
test_api "/api/admin/logs" "GET" "" "401"

# Test Static Files
echo "📁 Static File Serving"
echo "--------------------"
echo -n "Testing / (should return HTML)... "
status=$(curl -s -o /dev/null -w "%{http_code}" "$BASE_URL/")
if [ "$status" = "200" ]; then
    echo -e "${GREEN}✓ $status${NC}"
else
    echo -e "${RED}✗ $status${NC}"
fi

# Summary
echo ""
echo "📊 Test Summary"
echo "=============="
echo "Base URL: $BASE_URL"
echo "Test completed at: $(date)"
echo ""
echo "If any tests failed:"
echo "1. Check if the application is running: pm2 list"
echo "2. Check application logs: pm2 logs"
echo "3. Check NGINX logs: sudo tail -f /var/log/nginx/error.log"
echo "4. Verify JSON data files exist in data/ directory"