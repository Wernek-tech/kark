# KARK Website VPS Deployment with Cloudflare

## Pre-Deployment Checklist

### 1. Local Verification
- [ ] All APIs working locally
- [ ] Build completes without errors
- [ ] JSON data files are valid
- [ ] No console errors in browser

### 2. VPS Requirements
- [ ] Ubuntu 20.04 or higher
- [ ] Node.js 20.x installed
- [ ] PM2 installed globally
- [ ] NGINX installed
- [ ] Git installed
- [ ] Sufficient disk space (>2GB)

### 3. Cloudflare Setup
- [ ] Domain added to Cloudflare
- [ ] DNS records pointing to VPS IP
- [ ] SSL/TLS mode set to "Flexible" or "Full"
- [ ] Proxy enabled (orange cloud)

## Deployment Steps

### Step 1: Upload Files to VPS
```bash
# On your local machine
rsync -avz --exclude 'node_modules' --exclude '.git' ./ user@vps-ip:/var/www/kark/
```

### Step 2: SSH to VPS and Setup
```bash
ssh user@vps-ip
cd /var/www/kark
```

### Step 3: Install Dependencies
```bash
npm install
```

### Step 4: Set Permissions
```bash
chmod +x vps-cloudflare-fix.sh
chmod +x vps-api-test.sh
```

### Step 5: Run Cloudflare Fix Script
```bash
sudo ./vps-cloudflare-fix.sh
```

### Step 6: Test APIs
```bash
./vps-api-test.sh
```

### Step 7: Verify Deployment
```bash
# Check PM2 status
pm2 list

# Check logs
pm2 logs --lines 50

# Test health endpoint
curl http://localhost:5000/api/health
```

## Cloudflare Configuration

### DNS Settings
```
Type    Name    Content         Proxy
A       @       YOUR-VPS-IP     ✓ (Proxied)
A       www     YOUR-VPS-IP     ✓ (Proxied)
```

### SSL/TLS Settings
- **SSL/TLS Mode**: Full or Flexible
- **Always Use HTTPS**: On
- **Automatic HTTPS Rewrites**: On
- **Minimum TLS Version**: 1.2

### Page Rules (Optional)
1. `*kibrisaramakurtarma.org/*` - Cache Level: Standard
2. `*kibrisaramakurtarma.org/api/*` - Cache Level: Bypass

### Firewall Rules
Allow traffic from Cloudflare IPs only:
```bash
# Add to VPS firewall (ufw)
sudo ufw allow from 173.245.48.0/20
sudo ufw allow from 103.21.244.0/22
sudo ufw allow from 103.22.200.0/22
# ... (add all Cloudflare IPs)
```

## Troubleshooting

### 502 Bad Gateway
1. Check if app is running: `pm2 list`
2. Check app logs: `pm2 logs`
3. Test local connection: `curl http://localhost:5000/api/health`
4. Check NGINX error log: `sudo tail -f /var/log/nginx/error.log`

### 521 Web Server Down
1. Ensure NGINX is running: `sudo systemctl status nginx`
2. Check if port 80 is open: `sudo ufw status`
3. Verify server is listening: `sudo netstat -tlnp | grep :80`

### 523 Origin Unreachable
1. Check if VPS is accessible
2. Verify DNS records in Cloudflare
3. Ensure firewall allows Cloudflare IPs

### JSON Data Issues
1. Check file permissions: `ls -la data/`
2. Verify JSON validity: `for f in data/*.json; do jq . "$f" > /dev/null || echo "Invalid: $f"; done`
3. Check available disk space: `df -h`

## Monitoring

### Real-time Logs
```bash
# PM2 logs
pm2 logs --lines 100

# NGINX access logs
sudo tail -f /var/log/nginx/access.log

# NGINX error logs
sudo tail -f /var/log/nginx/error.log
```

### Performance Monitoring
```bash
# PM2 monitoring
pm2 monit

# System resources
htop
```

## Maintenance

### Update Application
```bash
cd /var/www/kark
git pull origin main  # or upload new files
npm install
npm run build
pm2 restart all
```

### Backup Data
```bash
# Backup JSON data
tar -czf kark-data-backup-$(date +%Y%m%d).tar.gz data/

# Backup entire application
tar -czf kark-full-backup-$(date +%Y%m%d).tar.gz /var/www/kark/
```

### SSL Certificate (if not using Cloudflare SSL)
If you decide to use Full (strict) mode later:
```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d kibrisaramakurtarma.org -d www.kibrisaramakurtarma.org
```

## Security Best Practices

1. **Keep Software Updated**
   ```bash
   sudo apt update && sudo apt upgrade
   npm update
   ```

2. **Use Strong Passwords**
   - Change default admin passwords
   - Use secure session secrets

3. **Limit Access**
   - Only allow SSH from specific IPs
   - Use SSH keys instead of passwords

4. **Monitor Logs**
   - Check for suspicious activity
   - Set up log rotation

5. **Regular Backups**
   - Automate daily backups
   - Test restore procedures