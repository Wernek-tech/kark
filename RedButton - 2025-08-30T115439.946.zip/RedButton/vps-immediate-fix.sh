#!/bin/bash

# VPS Immediate Fix - ES Module Issue
echo "🔧 Fixing ES Module PM2 Config Issue..."

cd /var/www/kark

# Stop the crashing process
pm2 stop all
pm2 delete all

# Create the PM2 config with .cjs extension (CommonJS)
cat > ecosystem.production-clean.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-production',
    script: 'dist/server.js',
    cwd: '/var/www/kark',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    },
    log_file: '/var/log/pm2/kark-production.log',
    out_file: '/var/log/pm2/kark-production-out.log',
    error_file: '/var/log/pm2/kark-production-error.log',
    merge_logs: true,
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
};
EOF

# Ensure directories exist
mkdir -p /var/log/pm2
mkdir -p data/sessions
chmod 755 data/sessions

# Start PM2 with the .cjs file
pm2 start ecosystem.production-clean.cjs

# Wait and test
sleep 5
curl -s http://localhost:5000/api/visitor-count && echo "✅ API working!" || echo "❌ Still not working"

# Show status
pm2 status

# Save if working
if curl -s http://localhost:5000/api/visitor-count > /dev/null 2>&1; then
    pm2 save
    echo "✅ Success! Saved working configuration."
else
    echo "📋 Error logs:"
    pm2 logs --err --lines 10
fi

systemctl restart nginx