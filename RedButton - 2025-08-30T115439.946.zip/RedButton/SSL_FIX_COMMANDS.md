# Fix SSL Certificate Issue - Step by Step

## The Problem
Nginx is trying to load SSL certificates that don't exist yet. We need to:
1. First get nginx working with HTTP only
2. Then get SSL certificates
3. Finally enable HTTPS

## Step 1: Remove Broken Configuration

```bash
# Remove any existing broken configuration
sudo rm -f /etc/nginx/sites-enabled/kibrisaramakurtarma
sudo rm -f /etc/nginx/sites-available/kibrisaramakurtarma
```

## Step 2: Use HTTP-Only Configuration First

```bash
# Copy the HTTP-only configuration
sudo cp /var/www/kark/nginx-http-only.conf /etc/nginx/sites-available/kibrisaramakurtarma

# Enable the site
sudo ln -s /etc/nginx/sites-available/kibrisaramakurtarma /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Start nginx
sudo systemctl restart nginx
sudo systemctl enable nginx

# Check if nginx is running
sudo systemctl status nginx
```

## Step 3: Test HTTP Access

```bash
# Test if your site works on HTTP
curl -I http://kibrisaramakurtarma.org

# You should see a 200 OK response
```

## Step 4: Get SSL Certificates

Now that nginx is working, get SSL certificates:

```bash
# Install certbot if not already installed
sudo apt update
sudo apt install certbot python3-certbot-nginx -y

# Get SSL certificate (this will automatically update nginx config)
sudo certbot --nginx -d kibrisaramakurtarma.org -d www.kibrisaramakurtarma.org

# Follow the prompts:
# - Enter email address
# - Agree to terms of service
# - Choose redirect option (recommended: 2)
```

## Step 5: Verify Everything Works

```bash
# Test nginx configuration
sudo nginx -t

# Check HTTPS
curl -I https://kibrisaramakurtarma.org

# Check if auto-renewal works
sudo certbot renew --dry-run
```

## Important Notes

1. **DNS Must Be Working**: Make sure your domain points to 193.31.31.171
2. **Port 80 Open**: Certbot needs port 80 to verify domain ownership
3. **KARK App Running**: Make sure your KARK app is running on port 5000

## Troubleshooting

If certbot fails:
```bash
# Check DNS
nslookup kibrisaramakurtarma.org

# Check if port 80 is accessible
sudo netstat -tulpn | grep :80

# Check KARK app
sudo netstat -tulpn | grep :5000
```

After completing these steps, your website will be accessible via HTTPS with automatic HTTP redirect.