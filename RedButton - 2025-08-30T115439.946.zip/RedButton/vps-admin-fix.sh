#!/bin/bash

echo "=== VPS Admin Panel Fix Script ==="
echo "Fixing blank admin panel issue on VPS..."

# Stop PM2 processes
echo "Stopping PM2 processes..."
pm2 stop kark-website 2>/dev/null || true
pm2 delete kark-website 2>/dev/null || true

# Create VPS-specific .env file
echo "Creating VPS-specific .env configuration..."
cat > .env << 'EOF'
NODE_ENV=production
PORT=5000
DB_TYPE=json
SESSION_SECRET=kark-super-secret-session-key-2025-kibris-vps
TRUST_PROXY=true
COOKIE_SECURE=false
COOKIE_SAME_SITE=none
COOKIE_HTTP_ONLY=true
COOKIE_MAX_AGE=86400000
EOF

# Clear any existing sessions
echo "Clearing existing sessions..."
rm -rf data/sessions 2>/dev/null || true
mkdir -p data/sessions

# Clear PM2 logs
echo "Clearing PM2 logs..."
pm2 flush 2>/dev/null || true

# Start with fresh session configuration
echo "Starting PM2 with VPS-optimized session settings..."
pm2 start ecosystem.config.cjs --env production

# Wait a moment for startup
sleep 3

# Show status
echo "PM2 Status:"
pm2 status

echo ""
echo "=== VPS Fix Applied ==="
echo "Configuration changes for VPS environment:"
echo "- Updated session secret for VPS"
echo "- Set COOKIE_SAME_SITE=none for VPS compatibility"
echo "- Enabled trust proxy for reverse proxy setups"
echo "- Cleared existing session data"
echo ""
echo "Your admin panel should now work properly on VPS."
echo "Test admin login at: http://your-vps-ip:5000/admin"
echo "Credentials: supermanager / admin123"