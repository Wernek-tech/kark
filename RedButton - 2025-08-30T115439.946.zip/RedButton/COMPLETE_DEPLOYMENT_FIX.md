# Complete KARK Website Deployment Fix for kibrisaramakurtarma.org

## The Problem
The nginx configuration fails because it references SSL certificates that don't exist yet. We need to deploy in the correct order.

## SOLUTION: Run These Commands in Exact Order

### Step 1: Clean Up Any Broken Configuration
```bash
# Remove any existing broken nginx configurations
sudo rm -f /etc/nginx/sites-enabled/kibrisaramakurtarma
sudo rm -f /etc/nginx/sites-available/kibrisaramakurtarma
sudo rm -f /etc/nginx/sites-enabled/default
```

### Step 2: Start with HTTP-Only Configuration
```bash
# Copy the HTTP-only configuration (no SSL references)
sudo cp /var/www/kark/nginx-http-only.conf /etc/nginx/sites-available/kibrisaramakurtarma

# Enable the site
sudo ln -s /etc/nginx/sites-available/kibrisaramakurtarma /etc/nginx/sites-enabled/

# Test and restart nginx
sudo nginx -t
sudo systemctl restart nginx
sudo systemctl enable nginx
```

### Step 3: Start Your KARK Application
```bash
cd /var/www/kark

# Make sure your app is built and ready
npm install
npm run build

# Start with PM2
pm2 start ecosystem.config.js
pm2 save
pm2 startup systemd
# Follow the instructions PM2 gives you

# Verify app is running
pm2 status
curl http://localhost:5000
```

### Step 4: Test HTTP Access
```bash
# Test if your site works on HTTP first
curl -I http://kibrisaramakurtarma.org

# You should see response from your KARK app
```

### Step 5: Get SSL Certificates
```bash
# Install certbot if needed
sudo apt update
sudo apt install certbot python3-certbot-nginx -y

# Get SSL certificate - this will automatically modify your nginx config
sudo certbot --nginx -d kibrisaramakurtarma.org -d www.kibrisaramakurtarma.org

# When prompted:
# 1. Enter your email address
# 2. Agree to terms (Y)
# 3. Choose whether to share email (Y/N - your choice)
# 4. Choose redirect option: 2 (Redirect HTTP to HTTPS)
```

### Step 6: Configure Firewall
```bash
# Allow necessary ports
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw enable
sudo ufw status
```

### Step 7: Set Correct Permissions
```bash
# Set ownership and permissions
sudo chown -R www-data:www-data /var/www/kark
sudo chmod -R 755 /var/www/kark
sudo chmod -R 644 /var/www/kark/data/*.json
```

### Step 8: Final Verification
```bash
# Test HTTPS
curl -I https://kibrisaramakurtarma.org

# Check nginx configuration
sudo nginx -t

# View nginx configuration (certbot modified it)
sudo cat /etc/nginx/sites-available/kibrisaramakurtarma

# Check PM2 status
pm2 status

# Check nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

## What This Fix Does

1. **Uses HTTP-only first** - nginx-http-only.conf has no SSL certificate references
2. **Gets app running** - Ensures KARK is accessible on port 5000
3. **Lets certbot handle SSL** - certbot automatically adds SSL configuration
4. **Proper order** - HTTP → SSL → HTTPS redirect

## Expected Results

- ✅ http://kibrisaramakurtarma.org works (redirects to HTTPS)
- ✅ https://kibrisaramakurtarma.org works with valid SSL
- ✅ https://www.kibrisaramakurtarma.org works
- ✅ Your KARK website loads properly
- ✅ Admin panel accessible at /admin

## If Something Goes Wrong

### DNS not working:
```bash
nslookup kibrisaramakurtarma.org
# Should return: 193.31.31.171
```

### App not starting:
```bash
cd /var/www/kark
npm start
# Check for errors
```

### Nginx errors:
```bash
sudo systemctl status nginx
sudo tail -f /var/log/nginx/error.log
```

### SSL certificate fails:
```bash
# Make sure port 80 is open and nginx is running
sudo netstat -tulpn | grep :80
curl http://kibrisaramakurtarma.org
```

This solution eliminates the SSL certificate chicken-and-egg problem by establishing HTTP first, then adding SSL.