#!/bin/bash

# KARK VPS Automatic Fix Script
# This script will diagnose and fix all VPS deployment issues automatically

echo "=============================================="
echo "  KARK VPS Automatic Fix Script"
echo "=============================================="
echo "This script will fix your VPS deployment completely."
echo ""

# Function to log with timestamp
log() {
    echo "[$(date '+%H:%M:%S')] $1"
}

# Function to run command and check result
run_cmd() {
    local cmd="$1"
    local desc="$2"
    log "$desc..."
    if eval "$cmd"; then
        log "✓ $desc completed successfully"
        return 0
    else
        log "✗ $desc failed"
        return 1
    fi
}

# Step 1: Environment Check
log "=== STEP 1: Environment Check ==="
log "Current directory: $(pwd)"
log "Node.js version: $(node --version 2>/dev/null || echo 'Not installed')"
log "NPM version: $(npm --version 2>/dev/null || echo 'Not installed')"
log "PM2 version: $(pm2 --version 2>/dev/null || echo 'Not installed')"

# Step 2: Install Dependencies
log "=== STEP 2: Installing Dependencies ==="
run_cmd "npm install -g tsx pm2" "Installing tsx and pm2 globally"
run_cmd "npm install" "Installing project dependencies"

# Step 3: Clean PM2 State
log "=== STEP 3: Cleaning PM2 State ==="
run_cmd "pm2 stop all" "Stopping all PM2 processes"
run_cmd "pm2 delete all" "Deleting all PM2 processes"
run_cmd "pm2 flush" "Flushing PM2 logs"
run_cmd "pkill -f 'node|tsx' || true" "Killing remaining processes"

# Step 4: Backup and Update Server Code
log "=== STEP 4: Updating Server Configuration ==="
run_cmd "cp server/index.ts server/index.ts.backup" "Backing up server file"

# Check current server configuration
log "Current server listen configuration:"
grep -n "listen" server/index.ts | head -5

# Update server to bind to all interfaces
sed -i.orig 's/app\.listen(PORT)/app.listen(PORT, "0.0.0.0", () => console.log(`🚀 KARK Server running on http:\/\/0.0.0.0:${PORT}`))/g' server/index.ts

log "Updated server configuration:"
grep -n "listen" server/index.ts | head -5

# Step 5: Create Production Environment
log "=== STEP 5: Creating Production Environment ==="
cat > .env << 'EOF'
NODE_ENV=production
PORT=5000
DB_TYPE=json
SESSION_SECRET=kark-vps-kibris-production-secret-2025
TRUST_PROXY=true
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
COOKIE_HTTP_ONLY=true
EOF
log "✓ Environment file created"

# Step 6: Create PM2 Configuration
log "=== STEP 6: Creating PM2 Configuration ==="
cat > ecosystem.production.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-production',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '500M',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-kibris-production-secret-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
}
EOF
log "✓ PM2 configuration created"

# Step 7: Prepare Session Storage
log "=== STEP 7: Preparing Session Storage ==="
run_cmd "rm -rf data/sessions" "Removing old sessions"
run_cmd "mkdir -p data/sessions logs" "Creating directories"
run_cmd "chmod 755 data/sessions logs" "Setting permissions"

# Step 8: Configure Firewall
log "=== STEP 8: Configuring Firewall ==="
if command -v ufw >/dev/null 2>&1; then
    run_cmd "ufw allow 5000/tcp" "Opening port 5000 with UFW"
    ufw status numbered | grep 5000 || log "⚠ UFW rule may not be active"
elif command -v firewall-cmd >/dev/null 2>&1; then
    run_cmd "firewall-cmd --permanent --add-port=5000/tcp" "Opening port 5000 with firewalld"
    run_cmd "firewall-cmd --reload" "Reloading firewall"
else
    log "⚠ No common firewall detected - may need manual configuration"
fi

# Step 9: Start Production Server
log "=== STEP 9: Starting Production Server ==="
run_cmd "pm2 start ecosystem.production.cjs" "Starting PM2 production server"

# Step 10: Wait for Startup
log "=== STEP 10: Waiting for Server Startup ==="
sleep 8

# Step 11: Verification
log "=== STEP 11: Verification ==="
log "PM2 Status:"
pm2 status

log "Port binding check:"
netstat -tlnp | grep :5000 && log "✓ Port 5000 is listening" || log "✗ Port 5000 not listening"

log "Server response test:"
if curl -s http://localhost:5000 | head -1 | grep -q "DOCTYPE"; then
    log "✓ Server responding with HTML"
else
    log "✗ Server not responding correctly"
    log "Recent logs:"
    pm2 logs kark-production --lines 10
fi

# Step 12: External Access Test
log "=== STEP 12: External Access Information ==="
EXTERNAL_IP=$(curl -s ifconfig.me 2>/dev/null || curl -s ipinfo.io/ip 2>/dev/null || echo "Unable to detect")
log "Your VPS External IP: $EXTERNAL_IP"

log "Testing external connectivity..."
if timeout 5 curl -s http://$EXTERNAL_IP:5000 >/dev/null 2>&1; then
    log "✓ External access working!"
else
    log "⚠ External access blocked - may need hosting provider firewall configuration"
fi

# Final Results
echo ""
echo "=============================================="
echo "  KARK VPS Fix Complete!"
echo "=============================================="
echo ""
echo "🌐 Access your website:"
echo "   Main site: http://$EXTERNAL_IP:5000"
echo "   Admin panel: http://$EXTERNAL_IP:5000/admin"
echo ""
echo "🔐 Admin credentials:"
echo "   Username: supermanager"
echo "   Password: admin123"
echo ""
echo "📊 Monitor your site:"
echo "   pm2 status"
echo "   pm2 logs kark-production"
echo "   pm2 restart kark-production"
echo ""

if netstat -tlnp | grep -q ":5000.*LISTEN"; then
    echo "✅ SUCCESS: Your KARK website is now running!"
    echo "   The admin panel should work without going blank."
else
    echo "❌ ISSUE: Server not properly listening on port 5000"
    echo "   Run: pm2 logs kark-production --lines 20"
    echo "   Or contact your hosting provider about port 5000 access"
fi

echo ""
echo "If external access is still blocked, your hosting provider"
echo "may be blocking port 5000. Contact them to open the port,"
echo "or use NGINX proxy to serve on port 80."