#!/bin/bash

echo "🔍 KARK Website API Testing (Improved)"
echo "======================================"
echo "Testing at: $(date)"
echo ""

# Function to test endpoint
test_endpoint() {
    local method=$1
    local endpoint=$2
    local expected=$3
    local data=$4
    
    echo -n "Testing $method $endpoint... "
    
    if [ "$method" = "GET" ]; then
        response=$(curl -s -o /dev/null -w "%{http_code}" -m 5 http://localhost:5000$endpoint)
    else
        response=$(curl -s -o /dev/null -w "%{http_code}" -m 5 -X $method -H "Content-Type: application/json" -d "$data" http://localhost:5000$endpoint)
    fi
    
    if [ "$response" = "000" ]; then
        echo "❌ Connection Failed"
        return 1
    elif [ "$response" = "$expected" ]; then
        echo "✅ $response (OK)"
        return 0
    else
        echo "⚠️  $response (expected $expected)"
        return 1
    fi
}

# First, check if the application is running
echo "🔧 System Checks"
echo "================"

# Check if PM2 is running
echo -n "PM2 Status: "
if pm2 list > /dev/null 2>&1; then
    echo "✅ Running"
    pm2 list
else
    echo "❌ Not running"
fi

# Check if port 5000 is listening
echo -n "Port 5000: "
if netstat -tuln | grep -q ":5000 "; then
    echo "✅ Listening"
else
    echo "❌ Not listening"
    echo "Checking what's using ports:"
    netstat -tuln | grep LISTEN
fi

# Check Node.js process
echo -n "Node.js process: "
if pgrep -f "node.*dist/index.js" > /dev/null; then
    echo "✅ Running"
else
    echo "❌ Not found"
fi

echo ""
echo "📍 API Endpoint Tests"
echo "===================="

# Public endpoints
echo "Public Endpoints:"
test_endpoint GET "/api/health" 200
test_endpoint GET "/api/visitor-count" 200
test_endpoint GET "/api/team" 200
test_endpoint GET "/api/activities" 200
test_endpoint GET "/api/events" 200
test_endpoint GET "/api/media" 200
test_endpoint GET "/api/albums" 200
test_endpoint GET "/api/archive" 200
test_endpoint GET "/api/hero-sliders" 200
test_endpoint GET "/api/settings" 200

echo ""
echo "Authentication Endpoints:"
test_endpoint GET "/api/user" 401
test_endpoint POST "/api/login" 401 '{"username":"","password":""}'

echo ""
echo "Admin Endpoints (should return 401):"
test_endpoint GET "/api/users" 401
test_endpoint GET "/api/admin/logs" 401

echo ""
echo "🔍 Detailed Diagnostics"
echo "======================"

# Check if application files exist
echo "Application files:"
[ -f "/var/www/kark/dist/index.js" ] && echo "✅ dist/index.js exists" || echo "❌ dist/index.js missing"
[ -f "/var/www/kark/package.json" ] && echo "✅ package.json exists" || echo "❌ package.json missing"
[ -d "/var/www/kark/node_modules" ] && echo "✅ node_modules exists" || echo "❌ node_modules missing"
[ -d "/var/www/kark/data" ] && echo "✅ data directory exists" || echo "❌ data directory missing"

# Check PM2 logs
echo ""
echo "Recent PM2 logs:"
pm2 logs --lines 5 --nostream 2>/dev/null || echo "Could not retrieve PM2 logs"

# Check NGINX
echo ""
echo "NGINX Status:"
systemctl status nginx --no-pager | head -n 5

# Test direct curl to localhost
echo ""
echo "Direct connection test:"
response=$(curl -s -m 5 http://localhost:5000/ | head -c 100)
if [ -n "$response" ]; then
    echo "✅ Can connect to localhost:5000"
    echo "Response preview: $response..."
else
    echo "❌ Cannot connect to localhost:5000"
fi

echo ""
echo "📊 Summary"
echo "========="
echo "If all tests show '000 Connection Failed':"
echo "1. Run: bash /var/www/kark/vps-complete-fix-cloudflare.sh"
echo "2. Check PM2 logs: pm2 logs"
echo "3. Check if build succeeded: ls -la /var/www/kark/dist/"
echo "4. Verify Node modules: ls -la /var/www/kark/node_modules/ | head"