# Admin Panel Blank Screen Fix

## The Issue
Your KARK website loads perfectly and authentication works (you successfully logged in as "supermanager"), but the admin panel becomes blank after login. This is typically caused by:

1. JavaScript errors in the browser console
2. Routing issues with the admin components
3. Component rendering failures
4. Security logs panel causing React crashes

## Fix Commands for Your Server

```bash
cd /var/www/kark

# 1. Check for any build issues and rebuild
npm run build

# 2. Restart the application to clear any memory issues
pm2 restart kark-website

# 3. Check if there are any server errors
pm2 logs kark-website --lines 50
```

## Browser Debugging Steps

1. **Open Browser Developer Tools** (F12)
2. **Go to Console tab** - Look for JavaScript errors
3. **Go to Network tab** - Check if API calls are failing
4. **Try admin panel again** and watch for errors

## Common Fixes

### Fix 1: Clear Browser Cache
- Hard refresh: Ctrl+F5 (Windows) or Cmd+Shift+R (Mac)
- Or clear browser cache completely

### Fix 2: Check Admin Panel URL
Make sure you're accessing:
- https://kibrisaramakurtarma.org/admin
- Not https://kibrisaramakurtarma.org/admin/

### Fix 3: Test Different Admin Routes
Try accessing specific admin pages directly:
- https://kibrisaramakurtarma.org/admin/users
- https://kibrisaramakurtarma.org/admin/events
- https://kibrisaramakurtarma.org/admin/media

## JavaScript Console Commands to Test

Open browser console and run:

```javascript
// Check if user is logged in
console.log("Current user:", window.localStorage.getItem('user'));

// Check for React errors
console.log("React errors:", window.__REACT_DEVTOOLS_GLOBAL_HOOK__?.rendererInterfaces);

// Force reload admin components
window.location.reload();
```

## Most Likely Causes

Based on your setup:
1. **Security Logs Panel**: The auto-refreshing security logs might be causing React to crash
2. **Permission Check**: There might be a role permission mismatch
3. **API Timeout**: Admin API calls might be timing out

## Quick Test

Try accessing the admin panel in **Incognito/Private mode** to rule out cache issues.

The fact that login works and server logs show successful API calls means the backend is fine - this is a frontend rendering issue.