# VPS API Connection Troubleshooting Guide

## Common API Connection Issues on VPS

### 1. Backend Not Running
**Symptoms:** API calls fail, nginx shows 502 Bad Gateway
**Solution:**
```bash
# Check if backend is running
pm2 status

# If not running, start it
pm2 start ecosystem.production.js --env production

# Check logs for errors
pm2 logs --lines 20
```

### 2. Port 5000 Not Accessible
**Symptoms:** Connection refused errors
**Solution:**
```bash
# Check what's listening on port 5000
netstat -tlnp | grep :5000

# Test locally
curl http://localhost:5000/api/visitor-count

# If nothing, restart PM2
pm2 restart all
```

### 3. Build Issues
**Symptoms:** Static files not found, blank pages
**Solution:**
```bash
# Rebuild the project
cd /var/www/kark
npm run build

# Check build output
ls -la dist/public/
```

### 4. Environment Variables
**Symptoms:** Database connection issues, session problems
**Solution:**
```bash
# Check PM2 environment
pm2 show kark-production

# Restart with environment
pm2 restart kark-production --update-env
```

### 5. Nginx Configuration Issues
**Symptoms:** API calls return 404, routing problems
**Solution:**
```bash
# Test nginx config
nginx -t

# Reload nginx
systemctl reload nginx

# Check nginx logs
tail -f /var/log/nginx/kark_error.log
```

## Quick Fix Commands

### Run These Commands in Order:
```bash
# 1. Navigate to project directory
cd /var/www/kark

# 2. Stop all PM2 processes
pm2 stop all && pm2 delete all

# 3. Install dependencies
npm install

# 4. Build project
npm run build

# 5. Create necessary directories
mkdir -p data/sessions
chmod 755 data/sessions

# 6. Start PM2 with production config
pm2 start ecosystem.production.js --env production

# 7. Save PM2 config
pm2 save

# 8. Test API
curl http://localhost:5000/api/visitor-count

# 9. Restart nginx
systemctl restart nginx
```

## Automated Fix Scripts

### Option 1: Run Diagnostic Script
```bash
chmod +x vps-api-diagnostic.sh
./vps-api-diagnostic.sh
```

### Option 2: Run Fix Script
```bash
chmod +x vps-api-connection-fix.sh
./vps-api-connection-fix.sh
```

## Manual Verification Steps

### 1. Check Backend Status
```bash
pm2 status
# Should show: kark-production | online
```

### 2. Test API Endpoints
```bash
curl http://localhost:5000/api/visitor-count
# Should return: {"count": number}

curl http://localhost:5000/api/settings
# Should return: JSON array
```

### 3. Check Nginx Proxy
```bash
curl -H "Host: kibrisaramakurtarma.org" http://localhost/api/visitor-count
# Should return: {"count": number}
```

### 4. Verify File Permissions
```bash
ls -la /var/www/kark/ecosystem.production.js
ls -la /var/www/kark/data/sessions/
```

## Expected Output After Fix

### PM2 Status:
```
┌────┬─────────────────┬──────────┬──────┬───────────┬──────────┬──────────┐
│ id │ name            │ mode     │ ↺    │ status    │ cpu      │ memory   │
├────┼─────────────────┼──────────┼──────┼───────────┼──────────┼──────────┤
│ 0  │ kark-production │ fork     │ 0    │ online    │ 0%       │ 45.2mb   │
└────┴─────────────────┴──────────┴──────┴───────────┴──────────┴──────────┘
```

### API Test:
```bash
curl http://localhost:5000/api/visitor-count
# Expected: {"count":1}
```

### Nginx Status:
```bash
systemctl status nginx
# Expected: active (running)
```

## If Issues Persist

### Check These:
1. **Firewall blocking port 5000**
2. **Database connection issues**
3. **File permission problems**
4. **Missing environment variables**
5. **Incorrect nginx configuration**

### Get Help:
Run the diagnostic script and share the output:
```bash
./vps-api-diagnostic.sh > diagnostic-output.txt
```

This will help identify the specific issue causing the API connection problem.