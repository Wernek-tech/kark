# VPS Deployment Complete Fix for KARK Website

## Root Cause Analysis

After thorough inspection, I've identified why your site works in Replit but fails on VPS:

1. **Server Binding**: Replit auto-configures networking, but your server code has Windows-specific binding that doesn't work on Ubuntu VPS
2. **Session Store**: Using memory store which doesn't persist properly in PM2 cluster mode
3. **HTTP Server**: The code doesn't create an explicit HTTP server instance for VPS
4. **Trust Proxy**: Set after middleware initialization instead of before

## Complete Fix Instructions

### Step 1: Update Server for VPS
```bash
cd /var/www/kark

# Backup original server file
cp server/index.ts server/index.ts.replit-backup

# Replace with VPS-optimized version
cp server/index-vps.ts server/index.ts
```

### Step 2: Fix Session Store for Production
Create this file on your VPS:

```bash
cat > server/session-store-vps.ts << 'EOF'
import session from 'express-session';
import fs from 'fs';
import path from 'path';

// File-based session store for VPS persistence
class FileSessionStore extends session.Store {
  private sessionsDir: string;

  constructor() {
    super();
    this.sessionsDir = path.join(process.cwd(), 'data', 'sessions');
    // Ensure sessions directory exists
    if (!fs.existsSync(this.sessionsDir)) {
      fs.mkdirSync(this.sessionsDir, { recursive: true });
    }
  }

  get(sid: string, callback: (err: any, session?: any) => void) {
    const sessionFile = path.join(this.sessionsDir, `${sid}.json`);
    fs.readFile(sessionFile, 'utf8', (err, data) => {
      if (err) {
        if (err.code === 'ENOENT') {
          return callback(null, null);
        }
        return callback(err);
      }
      try {
        const session = JSON.parse(data);
        callback(null, session);
      } catch (e) {
        callback(e);
      }
    });
  }

  set(sid: string, session: any, callback?: (err?: any) => void) {
    const sessionFile = path.join(this.sessionsDir, `${sid}.json`);
    const data = JSON.stringify(session);
    fs.writeFile(sessionFile, data, 'utf8', callback || (() => {}));
  }

  destroy(sid: string, callback?: (err?: any) => void) {
    const sessionFile = path.join(this.sessionsDir, `${sid}.json`);
    fs.unlink(sessionFile, callback || (() => {}));
  }

  clear(callback?: (err?: any) => void) {
    fs.readdir(this.sessionsDir, (err, files) => {
      if (err) return callback?.(err);
      
      const unlinkPromises = files
        .filter(file => file.endsWith('.json'))
        .map(file => fs.promises.unlink(path.join(this.sessionsDir, file)));
      
      Promise.all(unlinkPromises)
        .then(() => callback?.())
        .catch(callback);
    });
  }
}

export default FileSessionStore;
EOF
```

### Step 3: Update Auth Configuration
```bash
# Update auth.ts to use file-based session store for VPS
sed -i 's/store: storage.sessionStore/store: process.env.NODE_ENV === "production" ? new FileSessionStore() : storage.sessionStore/g' server/auth.ts
```

### Step 4: Create Production PM2 Config
```bash
cat > ecosystem.production.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-production',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    exec_mode: 'fork',  // Important: Use fork mode, not cluster
    autorestart: true,
    watch: false,
    max_memory_restart: '500M',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      HOST: '0.0.0.0',
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-vps-kibris-production-2025',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax',
      COOKIE_HTTP_ONLY: 'true'
    },
    error_file: './logs/error.log',
    out_file: './logs/output.log',
    log_file: './logs/combined.log',
    time: true,
    merge_logs: true
  }]
}
EOF
```

### Step 5: Apply All Fixes
```bash
# Clean everything
pm2 stop all
pm2 delete all
pm2 flush

# Clear old sessions
rm -rf data/sessions
mkdir -p data/sessions logs

# Set permissions
chmod -R 755 data logs

# Create .env file
cat > .env << 'EOF'
NODE_ENV=production
PORT=5000
HOST=0.0.0.0
DB_TYPE=json
SESSION_SECRET=kark-vps-kibris-production-2025
TRUST_PROXY=true
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
COOKIE_HTTP_ONLY=true
EOF

# Start with production config
pm2 start ecosystem.production.cjs

# Save PM2 config for auto-restart
pm2 save
pm2 startup
```

### Step 6: Configure NGINX (Recommended)
```bash
# Create NGINX config
cat > /etc/nginx/sites-available/kark << 'EOF'
server {
    listen 80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Session affinity
        proxy_set_header Cookie $http_cookie;
        proxy_pass_header Set-Cookie;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}
EOF

# Enable site
ln -sf /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

## Verification

1. Check PM2 status: `pm2 status`
2. Check logs: `pm2 logs kark-production`
3. Test locally: `curl http://localhost:5000`
4. Test externally: `curl http://kibrisaramakurtarma.org`
5. Test admin panel: Go to `/admin` and login

## Key Differences Fixed

1. **Replit**: Auto-configures proxy, uses memory store, handles Windows compatibility
2. **VPS**: Needs explicit proxy trust, file-based sessions, Linux-specific binding

Your admin panel should now work without going blank or showing 403 errors.