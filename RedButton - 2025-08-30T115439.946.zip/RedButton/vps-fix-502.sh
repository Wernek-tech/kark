#!/bin/bash

# KARK Website VPS 502 Error Fix Script
# This script fixes common issues causing 502 errors on VPS deployments

echo "🔧 Starting KARK Website VPS 502 Error Fix..."

# Stop any existing processes
echo "Stopping existing processes..."
pm2 stop all
pm2 delete all
sudo systemctl stop nginx

# Navigate to application directory
cd /var/www/kark

# Clean up and reinstall dependencies
echo "Cleaning and reinstalling dependencies..."
rm -rf node_modules package-lock.json dist
npm install

# Build the application
echo "Building application..."
npm run build

# Check if build was successful
if [ ! -f "dist/index.js" ]; then
    echo "❌ Build failed! Creating manual build..."
    mkdir -p dist
    
    # Create a simple production server file
    cat > dist/index.js << 'EOF'
import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { readFileSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Trust proxy
app.set('trust proxy', true);

// Serve static files
app.use(express.static(join(__dirname, '../client/dist')));

// API middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: false, limit: '50mb' }));

// Simple health check
app.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Serve index.html for all routes (SPA fallback)
app.get('*', (req, res) => {
    try {
        const indexPath = join(__dirname, '../client/dist/index.html');
        const indexHtml = readFileSync(indexPath, 'utf8');
        res.send(indexHtml);
    } catch (error) {
        res.status(500).send('Server Error');
    }
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 KARK Website running on port ${PORT}`);
});
EOF
fi

# Create optimized PM2 configuration
echo "Creating PM2 configuration..."
cat > ecosystem.vps.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'dist/index.js',
    cwd: '/var/www/kark',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    error_file: '/var/log/pm2/kark-error.log',
    out_file: '/var/log/pm2/kark-out.log',
    log_file: '/var/log/pm2/kark-combined.log',
    time: true,
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax',
      HOST: '0.0.0.0'
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax',
      HOST: '0.0.0.0'
    }
  }]
}
EOF

# Create PM2 log directory
sudo mkdir -p /var/log/pm2
sudo chown $USER:$USER /var/log/pm2

# Start application with PM2
echo "Starting application with PM2..."
pm2 start ecosystem.vps.config.cjs --env production

# Wait for app to start
sleep 5

# Check if application is running
if pm2 list | grep -q "online"; then
    echo "✅ Application started successfully"
else
    echo "❌ Application failed to start"
    pm2 logs --lines 50
    exit 1
fi

# Test local connection
echo "Testing local connection..."
if curl -s http://localhost:5000/health | grep -q "ok"; then
    echo "✅ Local connection successful"
else
    echo "❌ Local connection failed"
    echo "App logs:"
    pm2 logs --lines 20
    exit 1
fi

# Create optimized NGINX configuration
echo "Creating NGINX configuration..."
sudo tee /etc/nginx/sites-available/kark > /dev/null << 'EOF'
server {
    listen 80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;
    
    # SSL Configuration (update paths as needed)
    ssl_certificate /etc/letsencrypt/live/kibrisaramakurtarma.org/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/kibrisaramakurtarma.org/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    
    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    # Increase timeouts for better stability
    proxy_connect_timeout 60s;
    proxy_send_timeout 60s;
    proxy_read_timeout 60s;
    
    # Proxy to Node.js application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Health check failover
        proxy_next_upstream error timeout invalid_header http_500 http_502 http_503 http_504;
    }
    
    # Health check endpoint
    location /health {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Return 503 if backend is down
        proxy_intercept_errors on;
        error_page 502 503 504 /50x.html;
    }
    
    # Static files with caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        proxy_pass http://127.0.0.1:5000;
        expires 1y;
        add_header Cache-Control "public, immutable";
        
        # Fallback for static files
        proxy_intercept_errors on;
        error_page 404 /index.html;
    }
    
    # Custom error pages
    error_page 500 502 503 504 /50x.html;
    location = /50x.html {
        root /var/www/html;
        internal;
    }
}
EOF

# Create custom error page
sudo tee /var/www/html/50x.html > /dev/null << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>KARK - Geçici Hizmet Dışı</title>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
        .error { color: #e74c3c; }
        .message { color: #2c3e50; margin: 20px 0; }
    </style>
</head>
<body>
    <h1 class="error">KARK Website</h1>
    <p class="message">Sistem geçici olarak bakım altında. Lütfen birkaç dakika sonra tekrar deneyin.</p>
    <p>Acil durumlar için: <a href="tel:+905338765432">0533 876 54 32</a></p>
</body>
</html>
EOF

# Enable the site
sudo ln -sf /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test NGINX configuration
echo "Testing NGINX configuration..."
if sudo nginx -t; then
    echo "✅ NGINX configuration is valid"
else
    echo "❌ NGINX configuration is invalid"
    exit 1
fi

# Restart NGINX
echo "Restarting NGINX..."
sudo systemctl restart nginx

# Final status check
echo "Final status check..."
echo "PM2 Status:"
pm2 status

echo "NGINX Status:"
sudo systemctl status nginx --no-pager

echo "Port 5000 Status:"
sudo netstat -tlnp | grep :5000

echo "🎉 VPS 502 Error Fix Complete!"
echo ""
echo "Next steps:"
echo "1. Test your domain: curl -I https://kibrisaramakurtarma.org"
echo "2. Check logs: pm2 logs"
echo "3. Monitor: pm2 monit"
echo ""
echo "If issues persist:"
echo "- Check PM2 logs: pm2 logs --lines 50"
echo "- Check NGINX logs: sudo tail -f /var/log/nginx/error.log"
echo "- Test health endpoint: curl http://localhost:5000/health"