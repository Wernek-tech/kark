#!/bin/bash

# VPS API Diagnostic Script for KARK Website
echo "🔍 Diagnosing API Connection Issues..."

echo "=== 1. System Information ==="
echo "OS: $(lsb_release -d 2>/dev/null || echo "Unknown")"
echo "Node.js: $(node --version 2>/dev/null || echo "Not installed")"
echo "NPM: $(npm --version 2>/dev/null || echo "Not installed")"
echo "PM2: $(pm2 --version 2>/dev/null || echo "Not installed")"

echo -e "\n=== 2. PM2 Status ==="
pm2 status || echo "PM2 not running"

echo -e "\n=== 3. Port 5000 Check ==="
netstat -tlnp | grep :5000 || echo "Nothing listening on port 5000"

echo -e "\n=== 4. Process Check ==="
ps aux | grep -E "(node|npm)" | grep -v grep || echo "No Node.js processes found"

echo -e "\n=== 5. API Test ==="
curl -v -s http://localhost:5000/api/visitor-count 2>&1 || echo "API not accessible"

echo -e "\n=== 6. Nginx Status ==="
systemctl status nginx --no-pager | head -10

echo -e "\n=== 7. Nginx Configuration Test ==="
nginx -t 2>&1

echo -e "\n=== 8. Directory Structure ==="
ls -la /var/www/kark/ | head -20

echo -e "\n=== 9. Build Output ==="
ls -la /var/www/kark/dist/public/ 2>/dev/null || echo "Build directory not found"

echo -e "\n=== 10. PM2 Logs (Last 20 lines) ==="
pm2 logs --lines 20 2>/dev/null || echo "No PM2 logs available"

echo -e "\n=== 11. System Logs ==="
journalctl -u nginx --no-pager -n 5 2>/dev/null || echo "No nginx logs available"

echo -e "\n=== 12. Environment Variables ==="
echo "NODE_ENV: ${NODE_ENV:-not set}"
echo "PORT: ${PORT:-not set}"

echo -e "\n=== 13. Firewall Status ==="
ufw status 2>/dev/null || iptables -L INPUT -n | head -10 2>/dev/null || echo "Firewall info not available"

echo -e "\n=== 14. File Permissions ==="
ls -la /var/www/kark/ecosystem.production.js 2>/dev/null || echo "ecosystem.production.js not found"
ls -la /var/www/kark/package.json 2>/dev/null || echo "package.json not found"

echo -e "\n=== Diagnosis Complete ==="
echo "Please share this output to help identify the issue."