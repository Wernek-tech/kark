# PM2 Configuration Guide for KARK Website

## ✅ Current Status
PM2 is now successfully configured and running locally. The application is accessible at http://localhost:5000

## 🔧 Configuration Files

### 1. ecosystem.config.cjs (Production Ready)
```javascript
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'npm',
    args: 'start',
    cwd: process.cwd(),
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    }
  }]
}
```

### 2. ecosystem.production.js (VPS Ready)
```javascript
module.exports = {
  apps: [{
    name: 'kark-production',
    script: 'npm',
    args: 'start',
    cwd: process.cwd(),
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'kark-super-secret-session-key-2025-kibris',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    },
    log_file: '/var/log/pm2/kark-production.log',
    out_file: '/var/log/pm2/kark-production-out.log',
    error_file: '/var/log/pm2/kark-production-error.log',
    merge_logs: true,
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
}
```

## 🚀 PM2 Commands

### Local Development
```bash
# Start PM2 locally
npx pm2 start ecosystem.config.cjs --env production

# Check status
npx pm2 status

# View logs
npx pm2 logs

# Restart app
npx pm2 restart kark-website

# Stop app
npx pm2 stop kark-website

# Delete app
npx pm2 delete kark-website
```

### VPS Production
```bash
# Start production app
pm2 start ecosystem.production.js --env production

# Check status
pm2 status

# View logs
pm2 logs

# Monitor
pm2 monit

# Restart
pm2 restart kark-production

# Save configuration
pm2 save

# Setup startup script
pm2 startup
```

## 📊 Current PM2 Status (Local)
```
┌────┬────────────────────┬──────────┬──────┬───────────┬──────────┬──────────┐
│ id │ name               │ mode     │ ↺    │ status    │ cpu      │ memory   │
├────┼────────────────────┼──────────┼──────┼───────────┼──────────┼──────────┤
│ 0  │ kark-website       │ cluster  │ 0    │ online    │ 0%       │ 49.5mb   │
└────┴────────────────────┴──────────┴──────┴───────────┴──────────┴──────────┘
```

## 🛠️ VPS Deployment Steps

1. **Copy files to VPS:**
   ```bash
   scp ecosystem.production.js root@your-vps:/var/www/kark/
   scp vps-deploy-fix.sh root@your-vps:/var/www/kark/
   ```

2. **Run deployment script:**
   ```bash
   cd /var/www/kark
   chmod +x vps-deploy-fix.sh
   ./vps-deploy-fix.sh
   ```

3. **Or manual setup:**
   ```bash
   # Stop all processes
   pm2 stop all && pm2 delete all
   
   # Create directories
   mkdir -p /var/www/kark/data/sessions
   chmod 755 /var/www/kark/data/sessions
   
   # Start with production config
   pm2 start ecosystem.production.js --env production
   
   # Save and setup startup
   pm2 save
   pm2 startup
   ```

## 🔍 Troubleshooting

### Common Issues:
1. **Port 5000 already in use**: Stop other processes on port 5000
2. **Permission denied**: Check file permissions and create directories
3. **Module not found**: Run `npm install` before starting PM2
4. **Session directory**: Ensure `/var/www/kark/data/sessions/` exists

### Debug Commands:
```bash
# Check what's running on port 5000
lsof -i :5000

# Check PM2 logs
pm2 logs --lines 50

# Test API endpoint
curl http://localhost:5000/api/visitor-count

# Check nginx status
systemctl status nginx
```

## ✅ Verified Working
- ✅ PM2 daemon started successfully
- ✅ KARK website running on port 5000
- ✅ API endpoints responding correctly
- ✅ Session management configured
- ✅ Production environment variables set
- ✅ Automatic restart enabled
- ✅ Memory limit protection (1GB)