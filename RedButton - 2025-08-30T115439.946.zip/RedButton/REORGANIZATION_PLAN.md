# KARK Website Reorganization Plan

## Current Issues
1. **Conceptual Confusion**: Operations (operasyonlar), Events (etkinlikler), and Activities (faaliyetler) are mixed
2. **Archive System**: Everything is under "archive_items" with different types
3. **URL Management**: No support for multiple URLs per item
4. **Navigation**: Mixed categories in navbar and admin panel

## Proposed Structure

### 1. Data Organization
```
Operations (Operasyonlar) - Search & Rescue Operations
├── Operation Details
├── Date & Time
├── Location
├── Team Members
├── Multiple URLs (photos, videos, reports)
└── Status (ongoing, completed)

Events (Etkinlikler) - Public Events, Meetings, Ceremonies
├── Event Name
├── Date & Time
├── Location
├── Description
├── Multiple URLs (invitation, photos, videos)
└── Registration Link

Activities (Faaliyetler) - Regular Activities, Training Programs
├── Activity Name
├── Type (training, education, drill)
├── Schedule (recurring or one-time)
├── Description
├── Multiple URLs (materials, photos, videos)
└── Participants

News (Haberler) - News and Announcements
├── Title
├── Date
├── Content
├── Multiple URLs (sources, images)
└── Category

Reports (Raporlar) - Official Reports
├── Title
├── Date
├── Type
├── Content
├── Multiple URLs (documents, attachments)
└── Access Level
```

### 2. Database Changes

#### New Tables Structure:
- `operations` - For search & rescue operations
- `events` - Keep existing but clarify as public events
- `activities` - Keep existing but clarify as training/regular activities
- `news` - For news items
- `reports` - For official reports
- `media_urls` - Polymorphic table for multiple URLs per item

#### Media URLs Table:
```sql
media_urls {
  id
  entity_type (operation, event, activity, news, report)
  entity_id
  url
  title
  type (photo, video, document, link)
  order_index
}
```

### 3. Admin Panel Reorganization

#### New Menu Structure:
```
Admin Panel
├── Dashboard
├── Operations Management
│   ├── Add Operation
│   ├── List Operations
│   └── Operation Reports
├── Events Management
│   ├── Add Event
│   ├── List Events
│   └── Past Events
├── Activities Management
│   ├── Add Activity
│   ├── List Activities
│   └── Activity Schedule
├── News Management
│   ├── Add News
│   └── List News
├── Reports Management
│   ├── Add Report
│   └── List Reports
├── Media Gallery
├── Team Management
├── User Management
└── Settings
```

### 4. Frontend Navigation Changes

#### New Navbar Structure:
```
KARK
├── Ana Sayfa (Home)
├── Operasyonlar (Operations)
├── Etkinlikler (Events)
├── Faaliyetler (Activities)
├── Haberler (News)
├── Hakkımızda (About)
│   ├── Misyon & Vizyon
│   ├── Ekibimiz
│   └── İletişim
├── Medya (Media)
│   ├── Fotoğraflar
│   └── Videolar
└── Bağış (Donate)
```

### 5. URL Management Feature

#### Multiple URL Support:
- Add dynamic URL input fields with + button
- Each URL can have:
  - URL/Link
  - Title/Description
  - Type (Photo, Video, Document, External Link)
  - Order (for display sequence)

### 6. Implementation Steps

1. **Phase 1: Database Migration**
   - Create new tables for operations, news, reports
   - Create media_urls table
   - Migrate existing archive_items data

2. **Phase 2: Backend API Updates**
   - Create separate API endpoints for each entity
   - Implement media URL management
   - Update existing endpoints

3. **Phase 3: Admin Panel Updates**
   - Create new admin pages for each section
   - Implement multiple URL management UI
   - Update navigation

4. **Phase 4: Frontend Updates**
   - Update navbar with new structure
   - Create separate pages for each section
   - Update existing pages

5. **Phase 5: Data Migration**
   - Move existing archive items to appropriate tables
   - Preserve all existing data
   - Update references

## Benefits
1. **Clear Separation**: Each content type has its own section
2. **Better UX**: Users know exactly where to find what
3. **Flexibility**: Multiple URLs per item
4. **Scalability**: Easy to add new content types
5. **Maintainability**: Cleaner code structure

## Timeline Estimate
- Phase 1-2: Backend changes (2-3 hours)
- Phase 3-4: Frontend changes (2-3 hours)
- Phase 5: Data migration (1 hour)
- Testing: 1 hour

Total: ~8 hours of implementation