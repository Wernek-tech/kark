import { Express, Request, Response } from "express";
import { storage } from "./storage";
import { z } from "zod";
import { hashPassword } from "./auth";
import { userRoleEnum, adminLogs } from "@shared/schema";
import { db, pool } from "./db";
import { desc } from "drizzle-orm";
import { logAdminAction } from "./admin-logger";

const adminPermissionSchema = z.object({
  username: z.string().min(3),
  firstName: z.string().min(2),
  lastName: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8).optional(),
  role: z.enum(["admin", "major_admin"]),
  permissions: z.array(z.string())
});

// Middleware to check if user is a major admin
function requireMajorAdmin(req: Request, res: Response, next: Function) {
  const user = req.user as any;
  if (!user) {
    return res.status(401).json({ message: "Oturum açmanız gerekiyor" });
  }
  
  // SECURITY: Strict role checking - only major_admin can create/manage other admins
  if (user.role !== "major_admin" && !user.permissions?.includes("manage_admins")) {
    // Log the unauthorized access attempt
    console.warn(`Security Alert: Unauthorized admin access attempt by user ${user.username} (ID: ${user.id}) from IP ${req.ip}`);
    return res.status(403).json({ message: "Bu işlem için yetkiniz bulunmuyor" });
  }
  
  // SECURITY: Additional validation to ensure user is actually an admin
  if (!user.isAdmin) {
    console.warn(`Security Alert: Non-admin user ${user.username} (ID: ${user.id}) attempted admin action from IP ${req.ip}`);
    return res.status(403).json({ message: "Bu işlem için yetkiniz bulunmuyor" });
  }
  
  next();
}

// Middleware to check if user is an admin (any admin level)
function requireAdmin(req: Request, res: Response, next: Function) {
  const user = req.user as any;
  if (!user) {
    return res.status(401).json({ message: "Oturum açmanız gerekiyor" });
  }
  
  if (!user.isAdmin && user.role !== "admin" && user.role !== "major_admin") {
    return res.status(403).json({ message: "Bu işlem için yetkiniz bulunmuyor" });
  }
  
  next();
}

export function registerAdminRoutes(app: Express) {
  // Get all users (for user management)
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Kullanıcılar getirilirken bir hata oluştu" });
    }
  });
  
  // Ban a user
  app.post("/api/admin/ban-user/:id", requireAdmin, async (req, res) => {
    try {
      const userId = req.params.id;
      
      // Log the user ban action
      await logAdminAction(
        (req.user as any).id,
        "Kullanıcı Banlama",
        `Kullanıcı banlandı: ID ${userId}`,
        "users",
        userId,
        req
      );
      
      await storage.banUser(userId);
      res.status(200).json({ message: "Kullanıcı başarıyla banlandı" });
    } catch (error) {
      console.error("Error banning user:", error);
      res.status(500).json({ 
        message: "Kullanıcı banlanırken bir hata oluştu", 
        error: (error as Error).message 
      });
    }
  });
  
  // Unban a user
  app.post("/api/admin/unban-user/:id", requireAdmin, async (req, res) => {
    try {
      const userId = req.params.id;
      
      // Log the user unban action
      await logAdminAction(
        (req.user as any).id,
        "Kullanıcı Yasağı Kaldırma",
        `Kullanıcı yasağı kaldırıldı: ID ${userId}`,
        "users",
        userId,
        req
      );
      
      await storage.unbanUser(userId);
      res.status(200).json({ message: "Kullanıcı yasağı başarıyla kaldırıldı" });
    } catch (error) {
      console.error("Error unbanning user:", error);
      res.status(500).json({ 
        message: "Kullanıcı yasağı kaldırılırken bir hata oluştu", 
        error: (error as Error).message 
      });
    }
  });
  // Get admin logs (only available to major_admin)
  app.get("/api/admin-logs", requireMajorAdmin, async (req, res) => {
    try {
      // Get query parameters for filtering
      const limit = parseInt(req.query.limit as string) || 100;
      const offset = parseInt(req.query.offset as string) || 0;
      const resourceType = req.query.resourceType as string;
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      
      console.log(`Fetching logs with filters - resourceType: ${resourceType}, userId: ${userId}, limit: ${limit}, offset: ${offset}`);
      
      // Read admin logs from JSON file
      const fs = await import('fs/promises');
      const path = await import('path');
      const ADMIN_LOGS_FILE = path.join(process.cwd(), 'data', 'admin_logs.json');
      
      let logs = [];
      try {
        const data = await fs.readFile(ADMIN_LOGS_FILE, 'utf-8');
        logs = JSON.parse(data) || [];
      } catch (error) {
        console.error('Error reading admin logs:', error);
        logs = [];
      }
      
      // Apply filters
      let filteredLogs = logs;
      
      if (resourceType && resourceType !== 'all') {
        filteredLogs = filteredLogs.filter((log: any) => log.resource_type === resourceType || log.resourceType === resourceType);
      }
      
      if (userId) {
        filteredLogs = filteredLogs.filter((log: any) => log.user_id === userId || log.userId === userId);
      }
      
      // Get total count before pagination
      const totalCount = filteredLogs.length;
      
      // Apply pagination
      const paginatedLogs = filteredLogs.slice(offset, offset + limit);
      
      // Transform logs to match expected format (handle both snake_case and camelCase)
      const transformedLogs = paginatedLogs.map((log: any) => ({
        id: log.id,
        user_id: log.userId || log.user_id,
        action: log.action,
        details: log.details,
        ip_address: log.ipAddress || log.ip_address,
        user_agent: log.userAgent || log.user_agent,
        resource_type: log.resourceType || log.resource_type,
        resource_id: log.resourceId || log.resource_id,
        timestamp: log.timestamp
      }));
      
      res.json({
        logs: transformedLogs,
        pagination: {
          total: totalCount,
          limit,
          offset
        }
      });
    } catch (error) {
      console.error("Error fetching admin logs:", error);
      res.status(500).json({ message: "Yönetici kayıtları getirilirken bir hata oluştu" });
    }
  });
  // Get all admin users
  app.get("/api/admins", requireMajorAdmin, async (req, res) => {
    try {
      const users = await storage.getAllAdmins();
      res.json(users);
    } catch (error) {
      console.error("Error fetching admins:", error);
      res.status(500).json({ message: "Admin kullanıcıları getirirken bir hata oluştu" });
    }
  });
  
  // Create a new admin user
  app.post("/api/admins", requireMajorAdmin, async (req, res) => {
    try {
      const validatedData = adminPermissionSchema.parse(req.body);
      const currentUser = req.user as any;
      
      // SECURITY: Additional validation - ensure only major_admin can create other major_admin accounts
      if (validatedData.role === "major_admin" && currentUser.role !== "major_admin") {
        console.warn(`Security Alert: User ${currentUser.username} (ID: ${currentUser.id}) attempted to create major_admin account from IP ${req.ip}`);
        return res.status(403).json({ message: "Major admin hesapları sadece diğer major adminler tarafından oluşturulabilir" });
      }
      
      // SECURITY: Validate role is only admin or major_admin
      if (!["admin", "major_admin"].includes(validatedData.role)) {
        console.warn(`Security Alert: Invalid role '${validatedData.role}' attempted by user ${currentUser.username} from IP ${req.ip}`);
        return res.status(400).json({ message: "Geçersiz rol" });
      }
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Bu kullanıcı adı zaten kullanımda" });
      }
      
      if (!validatedData.password) {
        return res.status(400).json({ message: "Şifre gereklidir" });
      }
      
      // Create admin user with hashed password
      const adminUser = await storage.createUser({
        username: validatedData.username,
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
        email: validatedData.email,
        password: await hashPassword(validatedData.password),
        role: validatedData.role,
        permissions: validatedData.permissions
      });
      
      // Log the admin user creation
      await logAdminAction(
        (req.user as any).id,
        "Admin Kullanıcı Oluşturma",
        `Yeni admin kullanıcı oluşturuldu: ${validatedData.username} (${validatedData.role})`,
        "users",
        adminUser.id.toString(),
        req
      );
      
      res.status(201).json(adminUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Geçersiz veri", errors: error.errors });
      }
      console.error("Error creating admin:", error);
      res.status(500).json({ message: "Admin kullanıcı oluşturulurken bir hata oluştu" });
    }
  });
  
  // Update an existing admin user
  app.put("/api/admins/:id", requireMajorAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Make sure the user exists and is an admin
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Current user cannot modify their own role/permissions unless they are the supermanager
      const currentUser = req.user as any;
      if (currentUser.id === userId && currentUser.role !== "major_admin" && 
          (req.body.role !== existingUser.role || JSON.stringify(req.body.permissions) !== JSON.stringify(existingUser.permissions))) {
        return res.status(403).json({ message: "Kendi rolünüzü veya izinlerinizi değiştiremezsiniz" });
      }
      
      const validatedData = adminPermissionSchema.omit({ password: true }).parse(req.body);
      
      // Update the admin user
      const updatedUser = await storage.updateAdmin(userId, {
        ...validatedData
      });
      
      // Log the admin user update
      await logAdminAction(
        (req.user as any).id,
        "Admin Kullanıcı Güncelleme",
        `Admin kullanıcı güncellendi: ${validatedData.username} (${validatedData.role})`,
        "users",
        userId.toString(),
        req
      );
      
      res.json(updatedUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Geçersiz veri", errors: error.errors });
      }
      console.error("Error updating admin:", error);
      res.status(500).json({ message: "Admin kullanıcı güncellenirken bir hata oluştu" });
    }
  });
  
  // Delete an admin user
  app.delete("/api/admins/:id", requireMajorAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Make sure the user exists
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Prevent deleting yourself
      const currentUser = req.user as any;
      if (currentUser.id === userId) {
        return res.status(403).json({ message: "Kendi hesabınızı silemezsiniz" });
      }
      
      // Store user details before deletion for logging
      const userBeingDeleted = existingUser.username;
      const userRole = existingUser.role;
      
      // Delete the user
      await storage.deleteUser(userId);
      
      // Log the admin user deletion
      await logAdminAction(
        (req.user as any).id,
        "Admin Kullanıcı Silme",
        `Admin kullanıcı silindi: ${userBeingDeleted} (${userRole})`,
        "users",
        userId.toString(),
        req
      );
      
      res.status(200).json({ message: "Admin kullanıcı başarıyla silindi" });
    } catch (error) {
      console.error("Error deleting admin:", error);
      res.status(500).json({ message: "Admin kullanıcı silinirken bir hata oluştu" });
    }
  });

  // Delete a user (only major_admin can delete users)
  app.delete("/api/admin/delete-user/:id", requireMajorAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Make sure the user exists
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Prevent deleting yourself
      const currentUser = req.user as any;
      if (currentUser.id === userId) {
        return res.status(403).json({ message: "Kendi hesabınızı silemezsiniz" });
      }
      
      // Prevent deleting other major_admin users
      if (existingUser.role === 'major_admin') {
        return res.status(403).json({ message: "Major admin kullanıcıları silinemez" });
      }
      
      // Store user details before deletion for logging
      const userBeingDeleted = existingUser.username;
      const userRole = existingUser.role;
      
      // Delete the user
      await storage.deleteUser(userId);
      
      // Log the user deletion
      await logAdminAction(
        (req.user as any).id,
        "Kullanıcı Silme",
        `Kullanıcı silindi: ${userBeingDeleted} (${userRole})`,
        "users",
        userId.toString(),
        req
      );
      
      res.status(200).json({ message: "Kullanıcı başarıyla silindi" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ 
        message: "Kullanıcı silinirken bir hata oluştu", 
        error: (error as Error).message 
      });
    }
  });

  // Grant admin permissions to a user (only major_admin can do this)
  app.post("/api/admin/grant-admin/:id", requireMajorAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { role = "admin", permissions = ["manage_events", "manage_media", "manage_team"] } = req.body;
      
      // Validate role
      if (!["admin", "major_admin"].includes(role)) {
        return res.status(400).json({ message: "Geçersiz rol" });
      }
      
      // Make sure the user exists
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Prevent granting permissions to banned users
      if (existingUser.role === 'banned') {
        return res.status(400).json({ message: "Banlanmış kullanıcılara admin izni verilemez" });
      }
      
      // Only allow granting major_admin if the current user is major_admin
      const currentUser = req.user as any;
      if (role === "major_admin" && currentUser.role !== "major_admin") {
        return res.status(403).json({ message: "Sadece major admin kullanıcıları diğer major admin'ler oluşturabilir" });
      }
      
      // Update the user's role and permissions
      await storage.updateAdmin(userId, {
        username: existingUser.username,
        firstName: existingUser.firstName,
        lastName: existingUser.lastName,
        email: existingUser.email,
        role: role as "admin" | "major_admin",
        permissions: permissions
      });
      
      // Log the admin permission grant
      await logAdminAction(
        (req.user as any).id,
        "Admin İzni Verme",
        `Kullanıcıya admin izni verildi: ${existingUser.username} (${role})`,
        "users",
        userId.toString(),
        req
      );
      
      res.status(200).json({ message: "Admin izinleri başarıyla verildi" });
    } catch (error) {
      console.error("Error granting admin permissions:", error);
      res.status(500).json({ 
        message: "Admin izinleri verilirken bir hata oluştu", 
        error: (error as Error).message 
      });
    }
  });

  // Revoke admin permissions from a user (only major_admin can do this)
  app.post("/api/admin/revoke-admin/:id", requireMajorAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Make sure the user exists
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "Kullanıcı bulunamadı" });
      }
      
      // Prevent revoking admin from major_admin users
      if (existingUser.role === 'major_admin') {
        return res.status(400).json({ message: "Major admin kullanıcılarının yetkisi geri alınamaz" });
      }
      
      // Prevent revoking admin from regular users
      if (existingUser.role === 'user' || existingUser.role === 'banned') {
        return res.status(400).json({ message: "Bu kullanıcı zaten admin değil" });
      }
      
      // Prevent self-demotion
      const currentUser = req.user as any;
      if (currentUser.id === userId) {
        return res.status(403).json({ message: "Kendi admin yetkilerinizi geri alamazsınız" });
      }
      
      // Update the user's role back to regular user
      await storage.updateAdmin(userId, {
        username: existingUser.username,
        firstName: existingUser.firstName,
        lastName: existingUser.lastName,
        email: existingUser.email,
        role: "user" as "admin" | "major_admin",
        permissions: []
      });
      
      // Log the admin permission revocation
      await logAdminAction(
        (req.user as any).id,
        "Admin Yetkisi Geri Alma",
        `Kullanıcının admin yetkisi geri alındı: ${existingUser.username} (${existingUser.role} -> user)`,
        "users",
        userId.toString(),
        req
      );
      
      res.status(200).json({ message: "Admin yetkileri başarıyla geri alındı" });
    } catch (error) {
      console.error("Error revoking admin permissions:", error);
      res.status(500).json({ 
        message: "Admin yetkileri geri alınırken bir hata oluştu", 
        error: (error as Error).message 
      });
    }
  });

  // Operations Routes
  app.get("/api/admin/operations", requireAdmin, async (req, res) => {
    try {
      const operations = await storage.getAllOperations();
      res.json(operations);
    } catch (error) {
      console.error("Error fetching operations:", error);
      res.status(500).json({ message: "Operasyonlar getirilirken bir hata oluştu" });
    }
  });

  app.post("/api/admin/operations", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const operation = await storage.createOperation({
        ...req.body,
        createdBy: currentUser.id,
        updatedBy: currentUser.id
      });

      await logAdminAction(
        currentUser.id,
        "Operasyon Oluşturma",
        `Yeni operasyon oluşturuldu: ${operation.title}`,
        "operations",
        operation.id.toString(),
        req
      );

      res.status(201).json(operation);
    } catch (error) {
      console.error("Error creating operation:", error);
      res.status(500).json({ message: "Operasyon oluşturulurken bir hata oluştu" });
    }
  });

  app.put("/api/admin/operations/:id", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const operation = await storage.updateOperation(parseInt(req.params.id), {
        ...req.body,
        updatedBy: currentUser.id
      });

      if (!operation) {
        return res.status(404).json({ message: "Operasyon bulunamadı" });
      }

      await logAdminAction(
        currentUser.id,
        "Operasyon Güncelleme",
        `Operasyon güncellendi: ${operation.title}`,
        "operations",
        operation.id.toString(),
        req
      );

      res.json(operation);
    } catch (error) {
      console.error("Error updating operation:", error);
      res.status(500).json({ message: "Operasyon güncellenirken bir hata oluştu" });
    }
  });

  app.delete("/api/admin/operations/:id", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const operationId = parseInt(req.params.id);
      
      await storage.deleteOperation(operationId);
      
      await logAdminAction(
        currentUser.id,
        "Operasyon Silme",
        `Operasyon silindi: ID ${operationId}`,
        "operations",
        operationId.toString(),
        req
      );

      res.json({ message: "Operasyon başarıyla silindi" });
    } catch (error) {
      console.error("Error deleting operation:", error);
      res.status(500).json({ message: "Operasyon silinirken bir hata oluştu" });
    }
  });

  // News Routes
  app.get("/api/admin/news", requireAdmin, async (req, res) => {
    try {
      const newsItems = await storage.getAllNews();
      res.json(newsItems);
    } catch (error) {
      console.error("Error fetching news:", error);
      res.status(500).json({ message: "Haberler getirilirken bir hata oluştu" });
    }
  });

  app.post("/api/admin/news", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const newsItem = await storage.createNews({
        ...req.body,
        createdBy: currentUser.id,
        updatedBy: currentUser.id
      });

      await logAdminAction(
        currentUser.id,
        "Haber Oluşturma",
        `Yeni haber oluşturuldu: ${newsItem.title}`,
        "news",
        newsItem.id.toString(),
        req
      );

      res.status(201).json(newsItem);
    } catch (error) {
      console.error("Error creating news:", error);
      res.status(500).json({ message: "Haber oluşturulurken bir hata oluştu" });
    }
  });

  app.put("/api/admin/news/:id", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const newsItem = await storage.updateNews(parseInt(req.params.id), {
        ...req.body,
        updatedBy: currentUser.id
      });

      if (!newsItem) {
        return res.status(404).json({ message: "Haber bulunamadı" });
      }

      await logAdminAction(
        currentUser.id,
        "Haber Güncelleme",
        `Haber güncellendi: ${newsItem.title}`,
        "news",
        newsItem.id.toString(),
        req
      );

      res.json(newsItem);
    } catch (error) {
      console.error("Error updating news:", error);
      res.status(500).json({ message: "Haber güncellenirken bir hata oluştu" });
    }
  });

  app.delete("/api/admin/news/:id", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const newsId = parseInt(req.params.id);
      
      await storage.deleteNews(newsId);
      
      await logAdminAction(
        currentUser.id,
        "Haber Silme",
        `Haber silindi: ID ${newsId}`,
        "news",
        newsId.toString(),
        req
      );

      res.json({ message: "Haber başarıyla silindi" });
    } catch (error) {
      console.error("Error deleting news:", error);
      res.status(500).json({ message: "Haber silinirken bir hata oluştu" });
    }
  });

  // Reports Routes
  app.get("/api/admin/reports", requireAdmin, async (req, res) => {
    try {
      const reports = await storage.getAllReports();
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ message: "Raporlar getirilirken bir hata oluştu" });
    }
  });

  app.post("/api/admin/reports", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const report = await storage.createReport({
        ...req.body,
        createdBy: currentUser.id,
        updatedBy: currentUser.id
      });

      await logAdminAction(
        currentUser.id,
        "Rapor Oluşturma",
        `Yeni rapor oluşturuldu: ${report.title}`,
        "reports",
        report.id.toString(),
        req
      );

      res.status(201).json(report);
    } catch (error) {
      console.error("Error creating report:", error);
      res.status(500).json({ message: "Rapor oluşturulurken bir hata oluştu" });
    }
  });

  app.put("/api/admin/reports/:id", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const report = await storage.updateReport(parseInt(req.params.id), {
        ...req.body,
        updatedBy: currentUser.id
      });

      if (!report) {
        return res.status(404).json({ message: "Rapor bulunamadı" });
      }

      await logAdminAction(
        currentUser.id,
        "Rapor Güncelleme",
        `Rapor güncellendi: ${report.title}`,
        "reports",
        report.id.toString(),
        req
      );

      res.json(report);
    } catch (error) {
      console.error("Error updating report:", error);
      res.status(500).json({ message: "Rapor güncellenirken bir hata oluştu" });
    }
  });

  app.delete("/api/admin/reports/:id", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const reportId = parseInt(req.params.id);
      
      await storage.deleteReport(reportId);
      
      await logAdminAction(
        currentUser.id,
        "Rapor Silme",
        `Rapor silindi: ID ${reportId}`,
        "reports",
        reportId.toString(),
        req
      );

      res.json({ message: "Rapor başarıyla silindi" });
    } catch (error) {
      console.error("Error deleting report:", error);
      res.status(500).json({ message: "Rapor silinirken bir hata oluştu" });
    }
  });

  // Media URLs Routes
  app.get("/api/admin/media-urls/:entityType/:entityId", requireAdmin, async (req, res) => {
    try {
      const { entityType, entityId } = req.params;
      const mediaUrls = await storage.getMediaUrls(entityType, parseInt(entityId));
      res.json(mediaUrls);
    } catch (error) {
      console.error("Error fetching media URLs:", error);
      res.status(500).json({ message: "Medya bağlantıları getirilirken bir hata oluştu" });
    }
  });

  app.post("/api/admin/media-urls", requireAdmin, async (req, res) => {
    try {
      const mediaUrl = await storage.addMediaUrl(req.body);
      res.status(201).json(mediaUrl);
    } catch (error) {
      console.error("Error adding media URL:", error);
      res.status(500).json({ message: "Medya bağlantısı eklenirken bir hata oluştu" });
    }
  });

  app.delete("/api/admin/media-urls/:id", requireAdmin, async (req, res) => {
    try {
      await storage.deleteMediaUrl(parseInt(req.params.id));
      res.json({ message: "Medya bağlantısı başarıyla silindi" });
    } catch (error) {
      console.error("Error deleting media URL:", error);
      res.status(500).json({ message: "Medya bağlantısı silinirken bir hata oluştu" });
    }
  });

  // Media Management Routes
  app.get("/api/admin/media", requireAdmin, async (req, res) => {
    try {
      const media = await storage.getAllMedia();
      
      // Transform filePath to mediaUrl for response
      const transformedMedia = media.map((item: any) => {
        const { filePath, ...rest } = item;
        return {
          ...rest,
          mediaUrl: filePath
        };
      });
      
      res.json(transformedMedia);
    } catch (error) {
      console.error("Error fetching media:", error);
      res.status(500).json({ message: "Medya listesi getirilirken bir hata oluştu" });
    }
  });

  app.post("/api/admin/media", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const { mediaUrl, ...restBody } = req.body;
      
      // Transform mediaUrl to filePath for storage
      const mediaData: any = {
        ...restBody,
        filePath: mediaUrl,
        createdBy: currentUser.id
      };
      
      const media = await storage.createMedia(mediaData);

      // Transform back for response
      const { filePath, ...rest } = media as any;
      const response = {
        ...rest,
        mediaUrl: filePath
      };

      await logAdminAction(
        currentUser.id,
        "Medya Ekleme",
        `Yeni medya eklendi: ${media.title}`,
        "media",
        media.id.toString(),
        req
      );

      res.status(201).json(response);
    } catch (error) {
      console.error("Error creating media:", error);
      res.status(500).json({ message: "Medya oluşturulurken bir hata oluştu" });
    }
  });

  app.put("/api/admin/media/:id", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const { mediaUrl, ...restBody } = req.body;
      
      // Transform mediaUrl to filePath for storage
      const mediaData: any = {
        ...restBody,
        filePath: mediaUrl,
        updatedBy: currentUser.id
      };
      
      const media = await storage.updateMedia(parseInt(req.params.id), mediaData);

      if (!media) {
        return res.status(404).json({ message: "Medya bulunamadı" });
      }

      // Transform back for response
      const { filePath, ...rest } = media as any;
      const response = {
        ...rest,
        mediaUrl: filePath
      };

      await logAdminAction(
        currentUser.id,
        "Medya Güncelleme",
        `Medya güncellendi: ${media.title}`,
        "media",
        media.id.toString(),
        req
      );

      res.json(response);
    } catch (error) {
      console.error("Error updating media:", error);
      res.status(500).json({ message: "Medya güncellenirken bir hata oluştu" });
    }
  });

  app.delete("/api/admin/media/:id", requireAdmin, async (req, res) => {
    try {
      const currentUser = req.user as any;
      const mediaId = parseInt(req.params.id);
      
      await storage.deleteMedia(mediaId);
      
      await logAdminAction(
        currentUser.id,
        "Medya Silme",
        `Medya silindi: ID ${mediaId}`,
        "media",
        mediaId.toString(),
        req
      );

      res.json({ message: "Medya başarıyla silindi" });
    } catch (error) {
      console.error("Error deleting media:", error);
      res.status(500).json({ message: "Medya silinirken bir hata oluştu" });
    }
  });
}