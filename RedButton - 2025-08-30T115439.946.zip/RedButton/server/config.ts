// Server configuration for VPS deployment
export const config = {
  // API Configuration
  api: {
    // Base URL configuration for production
    baseUrl: process.env.API_BASE_URL || '',
    // CORS configuration
    corsOrigins: process.env.CORS_ORIGINS ? 
      process.env.CORS_ORIGINS.split(',') : 
      ['http://localhost:5000', 'http://localhost:5173'],
  },
  
  // Server Configuration
  server: {
    port: parseInt(process.env.PORT || '5000'),
    host: process.env.HOST || '0.0.0.0',
    trustProxy: process.env.TRUST_PROXY === 'true',
  },
  
  // Session Configuration
  session: {
    secret: process.env.SESSION_SECRET || 'kark-session-secret-key-2025',
    cookieSecure: process.env.COOKIE_SECURE === 'true',
    cookieSameSite: process.env.COOKIE_SAME_SITE || 'lax',
    cookieDomain: process.env.COOKIE_DOMAIN,
  },
  
  // Database Configuration
  database: {
    type: process.env.DB_TYPE || 'json',
    // MySQL configuration
    mysql: {
      host: process.env.MYSQL_HOST || 'localhost',
      port: parseInt(process.env.MYSQL_PORT || '3306'),
      user: process.env.MYSQL_USER || 'root',
      password: process.env.MYSQL_PASSWORD || '',
      database: process.env.MYSQL_DATABASE || 'kark_db',
    }
  },
  
  // Rate Limiting
  rateLimiting: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW || '900000'), // 15 minutes
    max: parseInt(process.env.RATE_LIMIT_MAX || '100'),
  }
};