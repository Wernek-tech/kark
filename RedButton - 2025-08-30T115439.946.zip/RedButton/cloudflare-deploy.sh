#!/bin/bash

# KARK Website Cloudflare VPS Deployment Script
# Automated deployment for Ubuntu VPS with Cloudflare SSL

set -e  # Exit on error

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
print_status() { echo -e "${GREEN}[✓]${NC} $1"; }
print_error() { echo -e "${RED}[✗]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[!]${NC} $1"; }
print_info() { echo -e "${BLUE}[i]${NC} $1"; }

# Header
echo -e "${BLUE}=================================================${NC}"
echo -e "${BLUE}   KARK Website Cloudflare VPS Deployment${NC}"
echo -e "${BLUE}=================================================${NC}"
echo ""

# Check if not root
if [[ $EUID -eq 0 ]]; then
   print_error "Don't run as root. Use: ./cloudflare-deploy.sh"
   exit 1
fi

# Get domain
DOMAIN=${1:-kibrisaramakurtarma.org}
APP_DIR="/var/www/kark"

print_info "Deploying for domain: $DOMAIN"
echo ""

# Step 1: System Update
print_status "Updating system packages..."
sudo apt update -qq && sudo apt upgrade -y -qq

# Step 2: Install Node.js 20
if ! command -v node &> /dev/null; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - >/dev/null 2>&1
    sudo apt-get install -y nodejs -qq
else
    print_info "Node.js $(node --version) already installed"
fi

# Step 3: Install PM2
if ! command -v pm2 &> /dev/null; then
    print_status "Installing PM2..."
    sudo npm install -g pm2 --silent
else
    print_info "PM2 already installed"
fi

# Step 4: Install NGINX
if ! command -v nginx &> /dev/null; then
    print_status "Installing NGINX..."
    sudo apt install nginx -y -qq
    sudo systemctl enable nginx
else
    print_info "NGINX already installed"
fi

# Step 5: Create directories
print_status "Creating application directory..."
sudo mkdir -p $APP_DIR
sudo chown $USER:$USER $APP_DIR
sudo mkdir -p /var/log/pm2
sudo chown $USER:$USER /var/log/pm2

# Step 6: Check for files
if [ ! -f "package.json" ]; then
    print_error "package.json not found!"
    print_warning "Please run this script from the KARK project directory"
    exit 1
fi

# Step 7: Copy files
print_status "Copying application files..."
rsync -av --exclude 'node_modules' --exclude 'dist' --exclude '.git' . $APP_DIR/

# Step 8: Install dependencies
print_status "Installing dependencies (this may take a while)..."
cd $APP_DIR
npm install --silent

# Step 9: Generate secure session secret
SESSION_SECRET=$(openssl rand -base64 32)

# Step 10: Create environment file
print_status "Creating environment configuration..."
cat > $APP_DIR/.env << EOF
# Database Configuration
DB_TYPE=json
DATABASE_URL=postgresql://user:pass@localhost:5432/kark

# Session Configuration - Auto-generated secure secret
SESSION_SECRET=$SESSION_SECRET
COOKIE_SECURE=false
COOKIE_SAME_SITE=lax
TRUST_PROXY=true

# Node Environment
NODE_ENV=production
PORT=5000
EOF

# Step 11: Build application
print_status "Building application..."
cd $APP_DIR
npm run build

# Step 12: Create PM2 config
print_status "Creating PM2 configuration..."
cat > $APP_DIR/ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'kark-website',
    script: 'dist/index.js',
    cwd: '$APP_DIR',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      SESSION_SECRET: '$SESSION_SECRET',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax',
      TRUST_PROXY: 'true',
      DB_TYPE: 'json'
    },
    node_args: '--max-old-space-size=1024',
    exec_mode: 'fork',
    log_file: '/var/log/pm2/kark-combined.log',
    out_file: '/var/log/pm2/kark-out.log',
    error_file: '/var/log/pm2/kark-error.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
};
EOF

# Step 13: Start PM2
print_status "Starting application with PM2..."
cd $APP_DIR
pm2 stop kark-website 2>/dev/null || true
pm2 delete kark-website 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Step 14: Configure NGINX
print_status "Configuring NGINX for Cloudflare..."
sudo tee /etc/nginx/sites-available/kark > /dev/null << EOF
# Cloudflare IP ranges
set_real_ip_from 173.245.48.0/20;
set_real_ip_from 103.21.244.0/22;
set_real_ip_from 103.22.200.0/22;
set_real_ip_from 103.31.4.0/22;
set_real_ip_from 141.101.64.0/18;
set_real_ip_from 108.162.192.0/18;
set_real_ip_from 190.93.240.0/20;
set_real_ip_from 188.114.96.0/20;
set_real_ip_from 197.234.240.0/22;
set_real_ip_from 198.41.128.0/17;
set_real_ip_from 162.158.0.0/15;
set_real_ip_from 104.16.0.0/12;
set_real_ip_from 172.64.0.0/13;
set_real_ip_from 131.0.72.0/22;

real_ip_header CF-Connecting-IP;

server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN www.$DOMAIN;
    
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header X-Forwarded-Host \$host;
        proxy_cache_bypass \$http_upgrade;
        
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        proxy_buffering off;
    }
    
    location /assets {
        alias $APP_DIR/dist/assets;
        expires 1y;
        add_header Cache-Control "public, immutable";
        gzip_static on;
    }
    
    location /public {
        alias $APP_DIR/public;
        expires 30d;
        add_header Cache-Control "public";
    }
    
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript application/json application/javascript application/xml+rss image/svg+xml;
}
EOF

# Step 15: Enable site
print_status "Enabling NGINX site..."
sudo ln -sf /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Step 16: Configure firewall
print_status "Configuring firewall..."
sudo ufw allow 'Nginx Full' >/dev/null 2>&1
sudo ufw allow ssh >/dev/null 2>&1
sudo ufw --force enable >/dev/null 2>&1

# Step 17: Set permissions
print_status "Setting file permissions..."
sudo chown -R $USER:$USER $APP_DIR
chmod -R 755 $APP_DIR

# Step 18: Test deployment
print_status "Testing deployment..."
sleep 3

echo ""
echo -e "${BLUE}=================================================${NC}"
echo -e "${BLUE}           Deployment Status Check${NC}"
echo -e "${BLUE}=================================================${NC}"

# Check PM2
if pm2 list | grep -q "kark-website.*online"; then
    print_status "PM2 application is running"
else
    print_error "PM2 application failed to start"
    echo "Checking logs..."
    pm2 logs kark-website --lines 10 --nostream
fi

# Check localhost
if curl -s -o /dev/null -w "%{http_code}" http://localhost:5000 | grep -q "200"; then
    print_status "Application responds on localhost:5000"
else
    print_error "Application not responding on localhost"
fi

# Check NGINX
if sudo systemctl is-active --quiet nginx; then
    print_status "NGINX is running"
else
    print_error "NGINX is not running"
fi

echo ""
echo -e "${GREEN}=================================================${NC}"
echo -e "${GREEN}       🎉 Deployment Complete! 🎉${NC}"
echo -e "${GREEN}=================================================${NC}"
echo ""
print_info "Website URL: https://$DOMAIN"
print_info "Admin Panel: https://$DOMAIN/admin"
print_info "Default Login: supermanager / admin123"
echo ""
print_warning "Important: Change default passwords immediately!"
echo ""
echo -e "${BLUE}Cloudflare Settings Required:${NC}"
echo "1. SSL/TLS Mode: Set to 'Full' or 'Full (strict)'"
echo "2. Edge Certificates: Enable 'Always Use HTTPS'"
echo "3. DNS: Ensure A record points to this server's IP"
echo ""
echo -e "${BLUE}Useful Commands:${NC}"
echo "• View logs: pm2 logs kark-website"
echo "• Check status: pm2 status"
echo "• Restart app: pm2 restart kark-website"
echo "• NGINX logs: sudo tail -f /var/log/nginx/error.log"
echo ""