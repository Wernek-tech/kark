#!/bin/bash

# VPS Working Solution - Use existing working config
echo "🔧 Using the existing working ecosystem.config.cjs..."

cd /var/www/kark

# Stop everything
pm2 stop all
pm2 delete all

# Check what files exist
echo "📁 Checking available files..."
ls -la ecosystem*.cjs
ls -la dist/

# Use the existing ecosystem.config.cjs that we know works
echo "🚀 Starting with existing ecosystem.config.cjs..."
pm2 start ecosystem.config.cjs

# Wait and test
sleep 5

echo "📊 PM2 Status:"
pm2 status

echo "🔍 Testing API:"
curl -s http://localhost:5000/api/visitor-count && echo "✅ API working!" || echo "❌ API not responding"

# Check logs if not working
if ! curl -s http://localhost:5000/api/visitor-count > /dev/null 2>&1; then
    echo "📋 Error logs:"
    pm2 logs --err --lines 20
fi

# Save if working
if curl -s http://localhost:5000/api/visitor-count > /dev/null 2>&1; then
    pm2 save
    echo "✅ Saved working configuration!"
fi

systemctl restart nginx