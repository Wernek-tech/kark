#!/bin/bash

# Deep diagnosis of the PM2/API issue
echo "🔍 Deep VPS Diagnosis..."

cd /var/www/kark

# 1. Show current PM2 status
echo "=== Current PM2 Status ==="
pm2 status

# 2. Show PM2 process details
echo -e "\n=== PM2 Process Details ==="
pm2 describe 0

# 3. Check actual running processes
echo -e "\n=== Node Processes ==="
ps aux | grep node | grep -v grep

# 4. Check port listeners
echo -e "\n=== Port 5000 Listeners ==="
ss -tlnp | grep :5000
netstat -tlnp | grep :5000 2>/dev/null

# 5. Show actual PM2 logs (not just errors)
echo -e "\n=== PM2 Output Logs ==="
pm2 logs --out --lines 30

# 6. Test running server directly
echo -e "\n=== Testing Direct Server Run ==="
pm2 stop all
timeout 10s npm start &
NPM_PID=$!
sleep 5
curl -s http://localhost:5000/api/visitor-count && echo "✅ Direct npm start works" || echo "❌ Direct npm start fails"
kill $NPM_PID 2>/dev/null
pkill -f node 2>/dev/null

# 7. Check dist folder
echo -e "\n=== Dist Folder Contents ==="
ls -la dist/

# 8. Check package.json start script
echo -e "\n=== Package.json Start Script ==="
grep -A2 -B2 '"start"' package.json

# 9. Check ecosystem.config.cjs content
echo -e "\n=== ecosystem.config.cjs Content ==="
cat ecosystem.config.cjs | head -20

# 10. Environment variables
echo -e "\n=== Environment Check ==="
echo "NODE_ENV: $NODE_ENV"
echo "PORT: $PORT"

echo -e "\n📊 Diagnosis complete. Please share the output!"