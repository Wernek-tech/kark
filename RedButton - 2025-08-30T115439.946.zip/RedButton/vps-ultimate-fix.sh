#!/bin/bash

echo "🔧 KARK Website Ultimate VPS Fix"
echo "================================"

cd /var/www/kark || exit 1

# 1. Stop PM2
echo "1. Stopping PM2..."
pm2 stop all 2>/dev/null || true
pm2 delete all 2>/dev/null || true

# 2. Fix the vite.ts imports issue by creating a production version
echo "2. Creating production-compatible vite module..."
cat > server/vite-production.ts << 'EOF'
import express from "express";
import path from "path";
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}

export async function setupVite(app: any, server: any) {
  // In production, we don't need vite middleware
  return;
}

export function serveStatic(app: any) {
  const distPath = path.resolve(process.cwd(), 'dist/public');
  app.use(express.static(distPath));
  app.use("*", (_req: any, res: any) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}
EOF

# 3. Create production index that uses the fixed vite module
echo "3. Creating production index..."
cat > server/index-vps.ts << 'EOF'
import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes.js";
import { setupVite, serveStatic, log } from "./vite-production.js";
import { adminActionLogger } from "./admin-logger.js";
import { applySecurityMiddleware } from "./middleware/security.js";
import { config } from "./config.js";
import cors from "cors";
import path from "path";
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// CORS configuration
const corsOptions = {
  origin: function (origin: string | undefined, callback: (err: Error | null, allow?: boolean) => void) {
    if (!origin) return callback(null, true);
    if (config.api.corsOrigins.includes(origin) || 
        config.api.corsOrigins.includes('*') ||
        process.env.NODE_ENV === 'development') {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['X-Total-Count'],
  maxAge: 86400
};

app.use(cors(corsOptions));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: false, limit: '50mb' }));

app.set('trust proxy', true);
applySecurityMiddleware(app);
app.use(adminActionLogger);

// Serve static files
app.use(express.static(path.join(process.cwd(), 'public')));

// Special handler for video
app.get('/xoxoxo.mp4', (req, res) => {
  const videoPath = path.resolve(process.cwd(), 'xoxoxo.mp4');
  res.setHeader('Content-Type', 'video/mp4');
  res.sendFile(videoPath);
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'production'
  });
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }
      log(logLine);
    }
  });
  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    console.error(err);
  });

  // Serve static files
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = config.server.port;
  const host = config.server.host;
  
  server.listen(port, host, () => {
    log(`serving on ${host}:${port}`);
  });
})();
EOF

# 4. Build client
echo "4. Building client..."
npm run vite build || npx vite build

# 5. Build server with fixed imports
echo "5. Building server..."
npx esbuild server/index-vps.ts \
  --platform=node \
  --format=esm \
  --bundle \
  --packages=external \
  --outfile=dist/index.js \
  --target=node20 \
  --alias:./vite='./vite-production' \
  --alias:./routes='./routes.js' \
  --alias:./admin-logger='./admin-logger.js' \
  --alias:./middleware/security='./middleware/security.js' \
  --alias:./config='./config.js'

# 6. Create PM2 ecosystem config
echo "6. Creating PM2 config..."
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: './dist/index.js',
    cwd: '/var/www/kark',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    node_args: '--experimental-specifier-resolution=node',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      HOST: '0.0.0.0',
      DATABASE_URL: process.env.DATABASE_URL,
      SESSION_SECRET: process.env.SESSION_SECRET || 'kark-session-secret-2025',
      FRONTEND_URL: 'https://kibrisaramakurtarma.org',
      CORS_ORIGIN: 'https://kibrisaramakurtarma.org'
    },
    error_file: './logs/pm2-err.log',
    out_file: './logs/pm2-out.log',
    log_file: './logs/pm2-combined.log',
    time: true,
    merge_logs: true
  }]
};
EOF

# 7. Create logs directory
echo "7. Creating logs directory..."
mkdir -p logs

# 8. NGINX configuration
echo "8. Updating NGINX..."
cat > /etc/nginx/sites-available/kark << 'EOF'
server {
    listen 80;
    listen [::]:80;
    server_name kibrisaramakurtarma.org www.kibrisaramakurtarma.org;

    # Cloudflare real IP
    set_real_ip_from 173.245.48.0/20;
    set_real_ip_from 103.21.244.0/22;
    set_real_ip_from 103.22.200.0/22;
    set_real_ip_from 103.31.4.0/22;
    set_real_ip_from 141.101.64.0/18;
    set_real_ip_from 108.162.192.0/18;
    set_real_ip_from 190.93.240.0/20;
    set_real_ip_from 188.114.96.0/20;
    set_real_ip_from 197.234.240.0/22;
    set_real_ip_from 198.41.128.0/17;
    set_real_ip_from 162.158.0.0/15;
    set_real_ip_from 104.16.0.0/13;
    set_real_ip_from 104.24.0.0/14;
    set_real_ip_from 172.64.0.0/13;
    set_real_ip_from 131.0.72.0/22;
    real_ip_header CF-Connecting-IP;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}
EOF

nginx -t && systemctl reload nginx

# 9. Start with PM2
echo "9. Starting application..."
pm2 start ecosystem.config.cjs

# 10. Save PM2 config
pm2 save

# 11. Wait and verify
echo "10. Verifying startup..."
sleep 8

# 12. Run comprehensive tests
echo "11. Running tests..."
echo "==================="

# Check if process is running
echo "Process check:"
pm2 show kark-website | grep -E "status|restarts|uptime"

# Check if port is listening
echo -e "\nPort check:"
netstat -tuln | grep :5000 || echo "Port 5000 not listening"

# Test endpoints
echo -e "\nEndpoint tests:"
for endpoint in "/api/health" "/api/visitor-count" "/api/team" "/api/settings"; do
  echo -n "Testing $endpoint: "
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:5000$endpoint)
  if [ "$STATUS" = "200" ] || [ "$STATUS" = "304" ]; then
    echo "✅ $STATUS"
  else
    echo "❌ $STATUS"
  fi
done

# Show logs
echo -e "\nRecent logs:"
pm2 logs --lines 15 --nostream

echo -e "\n✅ Ultimate fix complete!"
echo "Monitor: pm2 monit"
echo "Logs: pm2 logs -f"