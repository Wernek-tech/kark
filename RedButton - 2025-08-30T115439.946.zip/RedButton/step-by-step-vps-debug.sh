#!/bin/bash

echo "=== Step-by-Step VPS Debug Process ==="

echo "STEP 1: Basic System Check"
echo "Current directory: $(pwd)"
echo "Node version: $(node --version 2>/dev/null || echo 'Node.js not found')"
echo "NPM version: $(npm --version 2>/dev/null || echo 'NPM not found')"
echo ""

echo "STEP 2: File Structure Verification"
echo "Checking essential files:"
[ -f "server/index.ts" ] && echo "✓ server/index.ts exists" || echo "✗ server/index.ts missing"
[ -f "package.json" ] && echo "✓ package.json exists" || echo "✗ package.json missing"
[ -f ".env" ] && echo "✓ .env exists" || echo "✗ .env missing"
echo ""

echo "STEP 3: Dependencies Check"
echo "Checking if tsx is available:"
which tsx >/dev/null 2>&1 && echo "✓ tsx found" || echo "✗ tsx not found - installing..."
if ! which tsx >/dev/null 2>&1; then
    npm install -g tsx
fi
echo ""

echo "STEP 4: Manual Server Test"
echo "Testing server startup manually (15 seconds)..."
echo "If you see 'serving on port 5000', the server works:"
timeout 15s tsx server/index.ts &
MANUAL_PID=$!
sleep 10
kill $MANUAL_PID 2>/dev/null || true
echo ""

echo "STEP 5: PM2 Clean Start"
echo "Stopping all PM2 processes..."
pm2 stop all 2>/dev/null || true
pm2 delete all 2>/dev/null || true

echo "Creating simple PM2 config..."
cat > ecosystem.simple.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-simple',
    script: 'tsx',
    args: 'server/index.ts',
    instances: 1,
    autorestart: true,
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DB_TYPE: 'json',
      SESSION_SECRET: 'vps-test-secret',
      TRUST_PROXY: 'true',
      COOKIE_SECURE: 'false',
      COOKIE_SAME_SITE: 'lax'
    }
  }]
}
EOF

echo "Starting PM2 with simple config..."
pm2 start ecosystem.simple.cjs

echo ""
echo "STEP 6: Results Check"
sleep 5
echo "PM2 Status:"
pm2 status
echo ""
echo "PM2 Logs (last 10 lines):"
pm2 logs kark-simple --lines 10 2>/dev/null || echo "No logs available"
echo ""
echo "Port Test:"
curl -s http://localhost:5000 | head -3 2>/dev/null || echo "Server not responding"

echo ""
echo "=== Debug Complete ==="
echo "If you see 'serving on port 5000' above, the server is working."
echo "If not, there's a deeper issue with Node.js/TypeScript on your VPS."