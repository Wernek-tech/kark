// Production server configuration for KARK website
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import your existing server setup
import('../server/index.js').then((serverModule) => {
  const app = serverModule.default || serverModule.app;
  
  if (app) {
    // Serve static files in production
    const distPath = path.join(__dirname, '../dist');
    app.use(express.static(distPath));
    
    // Handle client-side routing - serve index.html for all non-API routes
    app.get('*', (req, res) => {
      // Skip API routes
      if (req.path.startsWith('/api/')) {
        return res.status(404).json({ message: 'API endpoint not found' });
      }
      
      res.sendFile(path.join(distPath, 'index.html'));
    });
    
    const PORT = process.env.PORT || 3000;
    const HOST = process.env.HOST || '127.0.0.1';
    
    app.listen(PORT, HOST, () => {
      console.log(`🚀 KARK website running in production mode`);
      console.log(`📍 Server: http://${HOST}:${PORT}`);
      console.log(`🌍 Domain: kibrısaramakurtarma.org`);
      console.log(`📊 Environment: ${process.env.NODE_ENV}`);
    });
  } else {
    console.error('❌ Failed to import server application');
    process.exit(1);
  }
}).catch((error) => {
  console.error('❌ Error starting production server:', error);
  process.exit(1);
});