#!/bin/bash

# KARK Website Update Script
# Run this on your VDS when you want to update the website

set -e

APP_DIR="/var/www/kark"

echo "🔄 KARK Website Update Script"
echo "============================="

cd $APP_DIR

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}📦 Installing/updating dependencies...${NC}"
npm install

echo -e "${BLUE}🔨 Building production version...${NC}"
npm run build

echo -e "${BLUE}🔄 Restarting application...${NC}"
pm2 restart kark-website

echo -e "${BLUE}💾 Saving PM2 configuration...${NC}"
pm2 save

echo ""
echo -e "${GREEN}✅ Website updated successfully!${NC}"
echo ""
echo "📋 Status check:"
pm2 status
echo ""
echo "🌐 Your website should now be live at: http://kibrısaramakurtarma.org"