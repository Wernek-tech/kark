# KARK Website VDS Deployment Guide

## Server Information
- **IP Address**: 212.192.29.193
- **Domain**: kibrısaramakurtarma.org
- **Cloudflare**: Enabled (handles HTTPS automatically)

## Quick Deployment Steps

### 1. Connect to Your VDS
```bash
ssh root@212.192.29.193
# or
ssh your-username@212.192.29.193
```

### 2. Upload Your Website Files
Upload the entire project to `/var/www/kark/` directory:

```bash
# Create directory
sudo mkdir -p /var/www/kark
sudo chown -R $USER:$USER /var/www/kark

# Upload files (from your local machine)
scp -r . username@212.192.29.193:/var/www/kark/
```

### 3. Run the Deployment Script
```bash
cd /var/www/kark
chmod +x deploy/build-and-deploy.sh
./deploy/build-and-deploy.sh
```

## Manual Setup (if needed)

### Install Node.js and npm
```bash
# Install Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install global packages
sudo npm install -g pm2 npx

# Verify installation
node --version
npm --version
npx --version
```

### Install and Configure Nginx
```bash
# Install Nginx
sudo apt-get update
sudo apt-get install -y nginx

# Copy configuration
sudo cp deploy/nginx-cloudflare.conf /etc/nginx/sites-available/kark

# Enable site
sudo ln -s /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test and reload
sudo nginx -t
sudo systemctl reload nginx
```

### Deploy Application
```bash
cd /var/www/kark

# Install dependencies
npm install

# Build for production
npm run build

# Start with PM2
cp deploy/ecosystem.config.js .
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

## Useful Commands

### Application Management
```bash
# Check status
pm2 status
pm2 logs kark-website

# Restart application
pm2 restart kark-website

# Stop application
pm2 stop kark-website

# Update application
cd /var/www/kark
git pull  # if using git
npm install
npm run build
pm2 restart kark-website
```

### Server Management
```bash
# Check Nginx status
sudo systemctl status nginx

# Reload Nginx configuration
sudo nginx -t
sudo systemctl reload nginx

# Check server resources
htop
df -h
free -h
```

### Health Monitoring
```bash
# Run health check
node deploy/health-check.js

# Check if website is accessible
curl -I http://127.0.0.1:3000/health
curl -I http://kibrısaramakurtarma.org
```

## Troubleshooting

### Website Not Loading
1. Check PM2 process: `pm2 status`
2. Check logs: `pm2 logs kark-website`
3. Restart: `pm2 restart kark-website`

### Nginx Errors
1. Check configuration: `sudo nginx -t`
2. Check status: `sudo systemctl status nginx`
3. Check logs: `sudo tail -f /var/log/nginx/error.log`

### Cloudflare Issues
- Ensure Nginx is configured for Cloudflare proxy
- Check that real IP headers are properly set
- Verify SSL mode is set to "Flexible" or "Full" in Cloudflare

### Port Issues
- Application runs on port 3000 (internal)
- Nginx forwards from port 80 to port 3000
- Cloudflare handles HTTPS (port 443)

## Security Notes
- Firewall allows only SSH, HTTP, and HTTPS
- Application runs on localhost (127.0.0.1) for security
- Nginx handles public access and forwards to application
- Cloudflare provides DDoS protection and SSL