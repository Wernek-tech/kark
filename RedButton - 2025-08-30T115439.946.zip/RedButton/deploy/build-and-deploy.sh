#!/bin/bash

# KARK Website Deployment Script for Linux VDS
# Run this script on your VDS at 212.192.29.193

set -e  # Exit on any error

echo "🚀 KARK Website Deployment Script"
echo "=================================="

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
DOMAIN="kibrısaramakurtarma.org"
APP_DIR="/var/www/kark"
SERVICE_USER="www-data"

echo -e "${BLUE}📋 Configuration:${NC}"
echo "Domain: $DOMAIN"
echo "App Directory: $APP_DIR"
echo "IP: 212.192.29.193"
echo ""

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install Node.js and npm if not present
install_nodejs() {
    echo -e "${YELLOW}📦 Installing Node.js and npm...${NC}"
    
    # Install Node.js 20.x
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
    
    # Verify installation
    node --version
    npm --version
    
    # Install global packages
    sudo npm install -g pm2 npx
    
    echo -e "${GREEN}✅ Node.js and npm installed successfully${NC}"
}

# Function to install Nginx if not present
install_nginx() {
    echo -e "${YELLOW}📦 Installing Nginx...${NC}"
    
    sudo apt-get update
    sudo apt-get install -y nginx
    
    # Start and enable Nginx
    sudo systemctl start nginx
    sudo systemctl enable nginx
    
    echo -e "${GREEN}✅ Nginx installed and started${NC}"
}

# Function to setup firewall
setup_firewall() {
    echo -e "${YELLOW}🔥 Configuring firewall...${NC}"
    
    # Allow SSH, HTTP, and HTTPS
    sudo ufw allow ssh
    sudo ufw allow 'Nginx Full'
    sudo ufw --force enable
    
    echo -e "${GREEN}✅ Firewall configured${NC}"
}

# Main deployment function
deploy_website() {
    echo -e "${YELLOW}🏗️  Deploying KARK website...${NC}"
    
    # Create app directory
    sudo mkdir -p $APP_DIR
    sudo chown -R $USER:$USER $APP_DIR
    
    # Navigate to app directory
    cd $APP_DIR
    
    # If this is a fresh deployment, clone or copy your code here
    # For now, we'll assume the code is already in this directory
    
    echo -e "${BLUE}📦 Installing dependencies...${NC}"
    npm install
    
    echo -e "${BLUE}🔨 Building production version...${NC}"
    npm run build
    
    echo -e "${BLUE}⚙️  Setting up PM2 process manager...${NC}"
    
    # Stop existing PM2 processes
    pm2 stop kark-website || true
    pm2 delete kark-website || true
    
    # Start the application with PM2
    pm2 start npm --name "kark-website" -- run start:prod
    
    # Save PM2 configuration
    pm2 save
    pm2 startup
    
    echo -e "${GREEN}✅ Website deployed successfully${NC}"
}

# Function to configure Nginx
configure_nginx() {
    echo -e "${YELLOW}⚙️  Configuring Nginx...${NC}"
    
    # Copy Nginx configuration
    sudo cp nginx-cloudflare.conf /etc/nginx/sites-available/kark
    
    # Create symlink if it doesn't exist
    if [ ! -L /etc/nginx/sites-enabled/kark ]; then
        sudo ln -s /etc/nginx/sites-available/kark /etc/nginx/sites-enabled/
    fi
    
    # Remove default Nginx site
    sudo rm -f /etc/nginx/sites-enabled/default
    
    # Test Nginx configuration
    sudo nginx -t
    
    # Reload Nginx
    sudo systemctl reload nginx
    
    echo -e "${GREEN}✅ Nginx configured for Cloudflare${NC}"
}

# Main execution
main() {
    echo -e "${BLUE}🔍 Checking system requirements...${NC}"
    
    # Check if running as root (not recommended)
    if [ "$EUID" -eq 0 ]; then
        echo -e "${RED}❌ Please don't run this script as root${NC}"
        echo "Run as regular user with sudo privileges"
        exit 1
    fi
    
    # Install Node.js if not present
    if ! command_exists node || ! command_exists npm; then
        install_nodejs
    else
        echo -e "${GREEN}✅ Node.js and npm are already installed${NC}"
        node --version
        npm --version
    fi
    
    # Install global packages if needed
    if ! command_exists pm2; then
        sudo npm install -g pm2
    fi
    if ! command_exists npx; then
        sudo npm install -g npx
    fi
    
    # Install Nginx if not present
    if ! command_exists nginx; then
        install_nginx
    else
        echo -e "${GREEN}✅ Nginx is already installed${NC}"
    fi
    
    # Setup firewall
    setup_firewall
    
    # Deploy the website
    deploy_website
    
    # Configure Nginx
    configure_nginx
    
    echo ""
    echo -e "${GREEN}🎉 Deployment completed successfully!${NC}"
    echo ""
    echo -e "${BLUE}📋 Next steps:${NC}"
    echo "1. Your website should now be accessible at http://$DOMAIN"
    echo "2. Cloudflare will handle HTTPS automatically"
    echo "3. Check PM2 status: pm2 status"
    echo "4. Check Nginx status: sudo systemctl status nginx"
    echo "5. View application logs: pm2 logs kark-website"
    echo ""
    echo -e "${YELLOW}🔧 Useful commands:${NC}"
    echo "- Restart website: pm2 restart kark-website"
    echo "- Stop website: pm2 stop kark-website"
    echo "- View logs: pm2 logs kark-website"
    echo "- Update website: git pull && npm install && npm run build && pm2 restart kark-website"
}

# Run main function
main "$@"