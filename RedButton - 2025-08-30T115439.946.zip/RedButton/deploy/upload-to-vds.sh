#!/bin/bash

# Upload KARK Website to VDS Script
# Run this from your local machine to upload files to the VDS

set -e

# Configuration
VDS_IP="212.192.29.193"
VDS_USER="root"  # Change this if you use a different user
REMOTE_PATH="/var/www/kark"

echo "🚀 KARK Website Upload Script"
echo "============================="
echo "Target: $VDS_USER@$VDS_IP:$REMOTE_PATH"
echo ""

# Function to upload files
upload_files() {
    echo "📦 Uploading files to VDS..."
    
    # Create remote directory
    ssh $VDS_USER@$VDS_IP "mkdir -p $REMOTE_PATH && chown -R www-data:www-data $REMOTE_PATH" || {
        echo "Creating directory with current user..."
        ssh $VDS_USER@$VDS_IP "mkdir -p $REMOTE_PATH"
    }
    
    # Upload files excluding node_modules and dist
    rsync -avz --progress \
        --exclude 'node_modules' \
        --exclude 'dist' \
        --exclude '.git' \
        --exclude '*.log' \
        --exclude '.env.local' \
        . $VDS_USER@$VDS_IP:$REMOTE_PATH/
    
    echo "✅ Files uploaded successfully"
}

# Function to set permissions
set_permissions() {
    echo "🔐 Setting file permissions..."
    
    ssh $VDS_USER@$VDS_IP "
        cd $REMOTE_PATH
        
        # Make scripts executable
        chmod +x deploy/build-and-deploy.sh
        chmod +x deploy/health-check.js
        
        # Set proper ownership
        chown -R www-data:www-data $REMOTE_PATH 2>/dev/null || chown -R $USER:$USER $REMOTE_PATH
        
        echo '✅ Permissions set'
    "
}

# Function to test connection
test_connection() {
    echo "🔍 Testing connection to VDS..."
    
    if ssh -o ConnectTimeout=10 $VDS_USER@$VDS_IP "echo 'Connection successful'"; then
        echo "✅ Connection to VDS successful"
        return 0
    else
        echo "❌ Cannot connect to VDS"
        echo "Please check:"
        echo "1. VDS IP address: $VDS_IP"
        echo "2. SSH key or password authentication"
        echo "3. Firewall settings on VDS"
        return 1
    fi
}

# Main execution
main() {
    if ! test_connection; then
        exit 1
    fi
    
    upload_files
    set_permissions
    
    echo ""
    echo "🎉 Upload completed successfully!"
    echo ""
    echo "📋 Next steps:"
    echo "1. SSH to your VDS: ssh $VDS_USER@$VDS_IP"
    echo "2. Run deployment: cd $REMOTE_PATH && ./deploy/build-and-deploy.sh"
    echo "3. Your website will be available at: http://kibrısaramakurtarma.org"
    echo ""
}

# Check if rsync is installed
if ! command -v rsync >/dev/null 2>&1; then
    echo "❌ rsync is not installed. Please install it first:"
    echo "Ubuntu/Debian: sudo apt-get install rsync"
    echo "macOS: brew install rsync"
    exit 1
fi

# Run main function
main "$@"