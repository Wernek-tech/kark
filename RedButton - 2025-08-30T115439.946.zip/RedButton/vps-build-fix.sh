#!/bin/bash

echo "🔧 KARK Website VPS Build Fix"
echo "============================="

cd /var/www/kark || exit 1

# 1. Stop PM2
echo "1. Stopping PM2..."
pm2 stop all 2>/dev/null || true
pm2 delete all 2>/dev/null || true

# 2. Create production server file
echo "2. Creating production server file..."
cat > server/index-production.ts << 'EOF'
import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { adminActionLogger } from "./admin-logger";
import { applySecurityMiddleware } from "./middleware/security";
import { config } from "./config";
import cors from "cors";
import path from "path";
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Simple logging function
function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}

// CORS configuration
const corsOptions = {
  origin: function (origin: string | undefined, callback: (err: Error | null, allow?: boolean) => void) {
    if (!origin) return callback(null, true);
    if (config.api.corsOrigins.includes(origin) || 
        config.api.corsOrigins.includes('*') ||
        process.env.NODE_ENV === 'development') {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['X-Total-Count'],
  maxAge: 86400
};

app.use(cors(corsOptions));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: false, limit: '50mb' }));

app.set('trust proxy', true);
applySecurityMiddleware(app);
app.use(adminActionLogger);

// Serve static files
app.use(express.static(path.join(process.cwd(), 'public')));

// Special handler for video
app.get('/xoxoxo.mp4', (req, res) => {
  const videoPath = path.resolve(process.cwd(), 'xoxoxo.mp4');
  res.setHeader('Content-Type', 'video/mp4');
  res.sendFile(videoPath);
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'production'
  });
});

// Request logging
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }
      log(logLine);
    }
  });
  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    console.error(err);
  });

  // Serve static files in production
  const distPath = path.resolve(process.cwd(), 'dist/public');
  app.use(express.static(distPath));
  app.use("*", (_req, res) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });

  const port = config.server.port;
  const host = config.server.host;
  
  server.listen(port, host, () => {
    log(`serving on ${host}:${port}`);
  });
})();
EOF

# 3. Build client first
echo "3. Building client..."
npm run vite build

# 4. Build server with production file
echo "4. Building server..."
npx esbuild server/index-production.ts \
  --platform=node \
  --packages=external \
  --bundle \
  --format=esm \
  --outfile=dist/index.js \
  --target=node20 \
  --minify

# 5. Create PM2 ecosystem config
echo "5. Creating PM2 config..."
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'kark-website',
    script: './dist/index.js',
    cwd: '/var/www/kark',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    node_args: '--experimental-specifier-resolution=node',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      HOST: '0.0.0.0',
      DATABASE_URL: process.env.DATABASE_URL,
      SESSION_SECRET: process.env.SESSION_SECRET || 'kark-session-secret-2025',
      FRONTEND_URL: 'https://kibrisaramakurtarma.org',
      CORS_ORIGIN: 'https://kibrisaramakurtarma.org'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
};
EOF

# 6. Create logs directory
echo "6. Creating logs directory..."
mkdir -p logs

# 7. Start with PM2
echo "7. Starting application..."
pm2 start ecosystem.config.cjs

# 8. Save PM2 config
pm2 save

# 9. Wait and test
echo "8. Waiting for startup..."
sleep 5

# 10. Test endpoints
echo "9. Testing endpoints..."
echo "Health check:"
curl -s http://localhost:5000/api/health | jq . || echo "Failed"

echo -e "\nVisitor count:"
curl -s http://localhost:5000/api/visitor-count | head -c 50

echo -e "\n\nPM2 Status:"
pm2 status

echo -e "\n✅ Build fix complete!"
echo "Check logs: pm2 logs"