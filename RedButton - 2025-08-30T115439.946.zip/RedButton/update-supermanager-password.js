import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function updateSupermanagerPassword() {
    try {
        // Generate bcrypt hash for "admin123"
        const password = 'admin123';
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);
        
        console.log('Generated hash for "admin123":', hashedPassword);
        
        // Read current users.json
        const usersPath = path.join(__dirname, 'data', 'users.json');
        const usersData = JSON.parse(fs.readFileSync(usersPath, 'utf8'));
        
        // Find and update supermanager
        const supermanagerIndex = usersData.findIndex(user => user.username === 'supermanager');
        if (supermanagerIndex !== -1) {
            usersData[supermanagerIndex].password = hashedPassword;
            usersData[supermanagerIndex].email = 'superadmin@kark.org';
            
            // Write back to file
            fs.writeFileSync(usersPath, JSON.stringify(usersData, null, 2));
            console.log('Updated supermanager password in users.json');
        } else {
            console.log('Supermanager user not found');
        }
        
    } catch (error) {
        console.error('Error updating password:', error);
    }
}

updateSupermanagerPassword();