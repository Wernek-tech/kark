import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Event } from "@shared/schema";
import { formatDate, getCategoryLabel } from "@/lib/utils";

interface EventCardProps {
  event: Event;
  from?: string;
}

export default function EventCard({ event, from }: EventCardProps) {
  return (
    <Card className="event-card overflow-hidden group hover:-translate-y-1 duration-300 dark:bg-gray-800 dark:border-gray-700">
      <div className="relative w-full h-48 overflow-hidden">
        <img 
          src={event.imagePath || `https://source.unsplash.com/random/800x500/?${event.category}`} 
          alt={event.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-70"></div>
        <span className="absolute bottom-3 left-3 text-white bg-red-600 text-xs font-bold px-3 py-1 rounded-full">
          {getCategoryLabel(event.category)}
        </span>
      </div>
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-3">
          <span className="text-sm font-medium text-gray-500 dark:text-gray-400">{formatDate(event.date)}</span>
          <span className="text-sm text-gray-500 dark:text-gray-400">{event.location}</span>
        </div>
        <h3 className="text-xl font-semibold mb-2 group-hover:text-red-600 dark:group-hover:text-red-400 dark:text-white transition-colors">{event.title}</h3>
        <p className="text-gray-600 dark:text-gray-300 mb-4">
          {event.description.length > 100
            ? `${event.description.substring(0, 100)}...`
            : event.description}
        </p>
        <Link href={`/events/${event.id}${from ? `?from=${from}` : '?from=home'}`}>
          <Button className="bg-red-600 hover:bg-red-700 dark:bg-red-700 dark:hover:bg-red-800">Detaylar</Button>
        </Link>
      </CardContent>
    </Card>
  );
}
