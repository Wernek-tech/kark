import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { TeamMember } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

export default function TeamSection() {
  const { data: teamMembers, isLoading } = useQuery<TeamMember[]>({
    queryKey: ["/api/team"],
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-12 w-12 animate-spin text-secondary" />
      </div>
    );
  }

  // Yöneticileri önce göster, sonra normal üyeleri
  const featuredTeamMembers = teamMembers
    ?.sort((a, b) => {
      // Önce yöneticiler (admin), sonra normal üyeler (regular)
      if (a.memberType === 'admin' && b.memberType !== 'admin') return -1;
      if (a.memberType !== 'admin' && b.memberType === 'admin') return 1;
      return 0;
    })
    ?.slice(0, 3) || [];

  return (
    <>
      {featuredTeamMembers.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredTeamMembers.map((member) => (
            <div 
              key={member.id} 
              className={`rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 relative ${
                member.memberType === 'admin' 
                  ? 'border-2 border-purple-500 dark:border-purple-400 bg-gradient-to-br from-purple-100 via-purple-50 to-purple-100 dark:from-purple-900/30 dark:via-purple-800/20 dark:to-purple-900/30 dark:bg-gray-800' 
                  : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700'
              }`}
            >
              {member.memberType === 'admin' && (
                <div className="absolute top-2 right-2 z-10">
                  <div className="bg-purple-600 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1 shadow-lg">
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                    </svg>
                    Yönetici
                  </div>
                </div>
              )}
              <div className="aspect-square bg-gray-200 dark:bg-gray-700 relative overflow-hidden">
                {member.profilePicture || member.imagePath ? (
                  <img
                    src={member.profilePicture || member.imagePath}
                    alt={`${member.firstName} ${member.lastName}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <svg className="w-16 h-16 text-gray-400 dark:text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                    </svg>
                  </div>
                )}
              </div>
              <div className="p-6 text-center">
                <h3 className={`text-xl font-bold mb-2 ${
                  member.memberType === 'admin' 
                    ? 'text-purple-700 dark:text-purple-300' 
                    : 'text-gray-900 dark:text-white'
                }`}>
                  {member.firstName} {member.lastName}
                </h3>
                {member.position && (
                  <p className={`mb-3 ${
                    member.memberType === 'admin' 
                      ? 'text-purple-600 dark:text-purple-400 font-medium' 
                      : 'text-gray-600 dark:text-gray-300'
                  }`}>
                    {member.position}
                  </p>
                )}
                {member.specialization && (
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">{member.specialization}</p>
                )}
                {member.bio && (
                  <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mb-4">{member.bio}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-gray-500 dark:text-gray-400">Henüz ekip üyesi bulunmuyor</p>
        </div>
      )}
      
      <div className="mt-12 text-center">
        <Link href="/team">
          <Button size="lg">Tüm Ekibi Gör</Button>
        </Link>
      </div>
    </>
  );
}