import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Loader2 } from "lucide-react";

interface Activity {
  id: number;
  title: string;
  description: string;
  category: string;
  imageUrl?: string | null;
  date?: string | null;
  link?: string | null;
  displayOrder: number;
  isActive: boolean;
}

export default function ActivitiesSection() {
  // Fetch activities from API
  const { data: activities, isLoading } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  if (!activities || activities.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Henüz faaliyet eklenmemiş.</p>
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
        {activities.slice(0, 3).map((activity) => (
          <div key={activity.id} className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-100 dark:border-gray-700">
            <div className="relative">
              <img 
                className="w-full h-64 object-cover" 
                src={activity.imageUrl || "https://images.unsplash.com/photo-1584744982271-69ccbec775aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=800"}
                alt={activity.title}
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1584744982271-69ccbec775aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=800";
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-4">
                <span className="bg-primary text-white text-xs font-medium px-2.5 py-1 rounded">
                  {activity.category}
                </span>
              </div>
            </div>
            <div className="p-5">
              <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">
                {activity.title}
              </h3>
              <p className="text-gray-700 dark:text-gray-300 mb-4 line-clamp-3">
                {activity.description}
              </p>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {activity.date || ""}
                </span>
                <Link href={`/activities/${activity.id}?from=home`}>
                  <Button variant="link" className="text-secondary hover:underline p-0 h-auto font-medium flex items-center gap-1">
                    Detayları Gör
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right">
                      <path d="M5 12h14"></path>
                      <path d="m12 5 7 7-7 7"></path>
                    </svg>
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {activities.length > 3 && (
        <div className="mt-12 text-center">
          <Link href="/activities">
            <Button size="lg">Daha Fazla</Button>
          </Link>
        </div>
      )}
    </>
  );
}