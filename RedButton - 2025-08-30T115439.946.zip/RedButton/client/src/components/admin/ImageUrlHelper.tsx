import { useState } from 'react';
import { Info, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export default function ImageUrlHelper() {
  const [open, setOpen] = useState(false);

  const examples = [
    {
      service: 'ImgBB',
      wrong: 'https://ibb.co/7xCYFyGG',
      correct: 'https://i.ibb.co/7xCYFyGG/image.jpg',
      note: 'Sayfa URL\'si yerine direkt resim URL\'sini kullanın'
    },
    {
      service: 'Imgur',
      wrong: 'https://imgur.com/a/AbCdE',
      correct: 'https://i.imgur.com/AbCdE.jpg',
      note: 'Galeri URL\'si değil, direkt resim URL\'si kullanın'
    },
    {
      service: 'Google Drive',
      wrong: 'https://drive.google.com/file/d/1AbC.../view',
      correct: 'https://drive.google.com/uc?export=view&id=1AbC...',
      note: 'Paylaşım linkini direkt görüntüleme linkine çevirin'
    },
    {
      service: 'Dropbox',
      wrong: 'https://www.dropbox.com/s/abc123/image.jpg?dl=0',
      correct: 'https://dl.dropboxusercontent.com/s/abc123/image.jpg?raw=1',
      note: 'dl=0 yerine raw=1 kullanın'
    }
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-1">
          <HelpCircle className="h-4 w-4" />
          Resim URL Yardımı
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Doğru Resim URL Formatı</DialogTitle>
          <DialogDescription>
            Resimlerin görüntülenmesi için direkt resim URL'si kullanmanız gerekir.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 mt-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-start gap-2">
              <Info className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <p className="font-medium text-blue-900">Önemli:</p>
                <p className="text-sm text-blue-800">
                  Resim yükleme servislerinin sayfa linklerini değil, direkt resim linklerini kullanın.
                  URL'nin sonunda .jpg, .png, .gif veya .webp gibi bir resim uzantısı olmalıdır.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold">Popüler Servislerde Doğru URL Alma:</h3>
            
            {examples.map((example, index) => (
              <div key={index} className="border rounded-lg p-4 space-y-2">
                <h4 className="font-medium text-lg">{example.service}</h4>
                
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-red-600">❌</span>
                    <code className="text-sm bg-red-50 px-2 py-1 rounded text-red-700 break-all">
                      {example.wrong}
                    </code>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-green-600">✅</span>
                    <code className="text-sm bg-green-50 px-2 py-1 rounded text-green-700 break-all">
                      {example.correct}
                    </code>
                  </div>
                </div>
                
                <p className="text-sm text-gray-600 italic">{example.note}</p>
              </div>
            ))}
          </div>

          <div className="bg-amber-50 p-4 rounded-lg">
            <p className="text-sm text-amber-800">
              <strong>İpucu:</strong> Resim URL'sini tarayıcınızda açarak test edin. 
              Eğer sadece resim görünüyorsa (başka hiçbir şey yoksa), URL doğrudur.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}