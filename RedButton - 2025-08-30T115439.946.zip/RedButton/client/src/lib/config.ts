// Client configuration for API endpoints
export const getApiUrl = (path: string): string => {
  // In production, use the same origin as the client
  // This avoids CORS issues when deployed on VPS
  if (import.meta.env.PROD) {
    return path;
  }
  
  // In development, we might need to specify the API server
  const apiBase = import.meta.env.VITE_API_URL || '';
  return `${apiBase}${path}`;
};

// WebSocket URL configuration
export const getWsUrl = (): string => {
  if (import.meta.env.PROD) {
    // In production, use wss:// for secure connections
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${protocol}//${window.location.host}`;
  }
  
  // In development
  const wsBase = import.meta.env.VITE_WS_URL || `ws://localhost:5000`;
  return wsBase;
};

// Configuration for fetch options
export const fetchConfig = {
  credentials: 'include' as RequestCredentials,
  headers: {
    'Content-Type': 'application/json',
  },
};