import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Calendar, Clock, ArrowRight } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { formatDate } from "@/lib/utils";
import { Helmet } from "react-helmet-async";

interface News {
  id: number;
  title: string;
  summary: string;
  content: string;
  image?: string;
  publishedAt: string;
  category: string;
  featured: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function NewsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const { data: newsItems = [], isLoading } = useQuery<News[]>({
    queryKey: ["/api/news"],
  });

  // Get unique categories
  const categories = Array.from(
    new Set(newsItems.map((news) => news.category))
  );

  // Sort news by published date
  const sortedNews = [...newsItems].sort((a, b) => 
    new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  );

  // Filter news
  const filteredNews = sortedNews.filter((news) => {
    const matchesSearch =
      searchQuery === "" ||
      news.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      news.summary.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory =
      selectedCategory === "all" || news.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  // Get featured news
  const featuredNews = filteredNews.find(news => news.featured);
  const regularNews = filteredNews.filter(news => !news.featured);

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "announcement":
        return "Duyuru";
      case "press":
        return "Basın";
      case "activity":
        return "Faaliyet";
      case "general":
        return "Genel";
      default:
        return category;
    }
  };

  return (
    <>
      <Helmet>
        <title>Haberler - KARK</title>
        <meta name="description" content="Kuzey Kıbrıs Arama Kurtarma Derneği'nden haberler ve duyurular" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <main className="container mx-auto px-4 py-24">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">Haberler</h1>
            <p className="text-muted-foreground">
              Derneğimizden en güncel haberler ve duyurular
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <Input
              placeholder="Haber ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="max-w-sm"
            />
            <div className="flex gap-2">
              <Button
                variant={selectedCategory === "all" ? "default" : "outline"}
                onClick={() => setSelectedCategory("all")}
              >
                Tümü
              </Button>
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category)}
                >
                  {getCategoryLabel(category)}
                </Button>
              ))}
            </div>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : filteredNews.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <p className="text-muted-foreground">Henüz haber bulunmamaktadır.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-8">
              {/* Featured News */}
              {featuredNews && (
                <div className="mb-12">
                  <h2 className="text-2xl font-semibold mb-4">Öne Çıkan Haber</h2>
                  <Link href={`/news/${featuredNews.id}`}>
                    <Card className="hover:shadow-xl transition-shadow cursor-pointer overflow-hidden">
                      <div className="grid md:grid-cols-2 gap-6">
                        {featuredNews.image && (
                          <div className="aspect-video relative overflow-hidden md:aspect-auto">
                            <img
                              src={featuredNews.image}
                              alt={featuredNews.title}
                              className="object-cover w-full h-full"
                            />
                          </div>
                        )}
                        <div className="p-6">
                          <div className="flex items-center gap-2 mb-4">
                            <Badge variant="default">Öne Çıkan</Badge>
                            <Badge variant="outline">{getCategoryLabel(featuredNews.category)}</Badge>
                          </div>
                          <h3 className="text-2xl font-bold mb-3">{featuredNews.title}</h3>
                          <p className="text-muted-foreground mb-4 line-clamp-3">
                            {featuredNews.summary}
                          </p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                <span>{formatDate(featuredNews.publishedAt)}</span>
                              </div>
                            </div>
                            <Button variant="ghost" size="sm">
                              Devamını Oku <ArrowRight className="w-4 h-4 ml-1" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </Link>
                </div>
              )}

              {/* Regular News Grid */}
              <div>
                <h2 className="text-2xl font-semibold mb-4">Tüm Haberler</h2>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {regularNews.map((news) => (
                    <Link key={news.id} href={`/news/${news.id}`}>
                      <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                        {news.image && (
                          <div className="aspect-video relative overflow-hidden rounded-t-lg">
                            <img
                              src={news.image}
                              alt={news.title}
                              className="object-cover w-full h-full"
                            />
                          </div>
                        )}
                        <CardHeader>
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline">{getCategoryLabel(news.category)}</Badge>
                            <span className="text-sm text-muted-foreground">
                              {formatDate(news.publishedAt)}
                            </span>
                          </div>
                          <CardTitle className="line-clamp-2">{news.title}</CardTitle>
                          <CardDescription className="line-clamp-3">
                            {news.summary}
                          </CardDescription>
                        </CardHeader>
                      </Card>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>

        <Footer />
      </div>
    </>
  );
}