import { useQuery } from "@tanstack/react-query";
import { useParams, Link, useLocation } from "wouter";
import { ArrowLeft, Calendar, Info, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Helmet } from "react-helmet-async";
import { useEffect, useState } from "react";

interface Activity {
  id: number;
  title: string;
  description: string;
  category: string;
  imageUrl?: string | null;
  date?: string | null;
  link?: string | null;
  displayOrder: number;
  isActive: boolean;
}

export default function ActivityDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [location] = useLocation();
  const [backNavigation, setBackNavigation] = useState({ href: "/", text: "Ana Sayfaya Dön" });
  
  const { data: activity, isLoading, error } = useQuery<Activity>({
    queryKey: [`/api/activities/${id}`],
    enabled: !!id,
  });

  useEffect(() => {
    // Check if user came from events page by looking at URL params or referrer
    const urlParams = new URLSearchParams(window.location.search);
    const fromEvents = urlParams.get('from') === 'events';
    const fromHomepage = urlParams.get('from') === 'home';
    
    // Check document.referrer to understand where user came from
    const referrer = document.referrer;
    const cameFromEvents = referrer.includes('/events') || fromEvents;
    const cameFromHome = referrer.includes('/') && !referrer.includes('/events') && !referrer.includes('/activities') || fromHomepage;
    
    if (cameFromEvents) {
      setBackNavigation({ href: "/events", text: "Etkinliklere Dön" });
    } else {
      setBackNavigation({ href: "/", text: "Ana Sayfaya Dön" });
    }
  }, []);

  if (isLoading) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-gray-600 dark:text-gray-400">Faaliyet detayları yükleniyor...</p>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  if (error || !activity) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
          <div className="text-center">
            <div className="text-6xl mb-4">😕</div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Faaliyet Bulunamadı</h1>
            <p className="text-gray-600 dark:text-gray-400 mb-8">
              Aradığınız faaliyet bulunamadı veya kaldırılmış olabilir.
            </p>
            <Link href={backNavigation.href}>
              <Button>
                <ArrowLeft className="mr-2 h-4 w-4" />
                {backNavigation.text}
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>{activity.title} - KARK</title>
        <meta name="description" content={activity.description} />
      </Helmet>
      
      <Navbar />
      
      <main className="min-h-screen bg-gray-50 dark:bg-gray-900">
        {/* Hero Section */}
        <section className="relative h-96 bg-gradient-to-br from-primary to-secondary">
          <div className="absolute inset-0 bg-black/40"></div>
          <div className="relative container mx-auto px-4 h-full flex items-center">
            <div className="max-w-4xl">
              <Link href={backNavigation.href}>
                <Button variant="outline" className="mb-4 bg-white/10 border-white/20 text-white hover:bg-white/20">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  {backNavigation.text}
                </Button>
              </Link>
              
              <Badge variant="secondary" className="mb-4">
                {activity.category}
              </Badge>
              
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                {activity.title}
              </h1>
              
              {activity.date && (
                <div className="flex items-center gap-2 text-white/90">
                  <Calendar className="h-5 w-5" />
                  <span>{new Date(activity.date).toLocaleDateString('tr-TR')}</span>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Content Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Main Content */}
                <div className="lg:col-span-2">
                  <Card className="mb-8">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Info className="h-5 w-5" />
                        Faaliyet Açıklaması
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">
                        {activity.description}
                      </p>
                    </CardContent>
                  </Card>

                  {/* Activity Image */}
                  {activity.imageUrl && (
                    <Card className="mb-8">
                      <CardContent className="p-0">
                        <img 
                          src={activity.imageUrl} 
                          alt={activity.title}
                          className="w-full h-96 object-cover rounded-lg"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1584744982271-69ccbec775aa?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=800";
                          }}
                        />
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Faaliyet Detayları</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {activity.date && (
                        <div className="flex items-center gap-3">
                          <Calendar className="h-5 w-5 text-primary" />
                          <div>
                            <p className="font-medium">Tarih</p>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              {new Date(activity.date).toLocaleDateString('tr-TR')}
                            </p>
                          </div>
                        </div>
                      )}
                      
                      <div className="flex items-center gap-3">
                        <Tag className="h-5 w-5 text-primary" />
                        <div>
                          <p className="font-medium">Kategori</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {activity.category}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Diğer Faaliyetler</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Link href={backNavigation.href}>
                        <Button className="w-full">
                          {backNavigation.text}
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </>
  );
}