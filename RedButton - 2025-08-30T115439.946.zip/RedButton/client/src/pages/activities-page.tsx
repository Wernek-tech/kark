import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Calendar, Users, Clock } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { formatDate } from "@/lib/utils";
import { Helmet } from "react-helmet-async";
import { Activity } from "@shared/schema";

export default function ActivitiesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedYear, setSelectedYear] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const { data: activities = [], isLoading } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
  });

  // Get unique years from activities
  const years = Array.from(
    new Set(
      activities
        .filter(activity => activity.date)
        .map(activity => new Date(activity.date!).getFullYear())
    )
  ).sort((a, b) => b - a);

  // Get unique categories
  const categories = Array.from(
    new Set(activities.map((activity) => activity.category))
  );

  // Filter activities
  const filteredActivities = activities.filter((activity) => {
    const matchesSearch =
      searchQuery === "" ||
      activity.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      activity.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesYear =
      selectedYear === "all" ||
      (activity.date && new Date(activity.date).getFullYear().toString() === selectedYear);

    const matchesCategory =
      selectedCategory === "all" || activity.category === selectedCategory;

    return matchesSearch && matchesYear && matchesCategory;
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "education":
        return "bg-blue-500";
      case "training":
        return "bg-green-500";
      case "meeting":
        return "bg-purple-500";
      case "social":
        return "bg-orange-500";
      default:
        return "bg-gray-500";
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case "education":
        return "Eğitim";
      case "training":
        return "Tatbikat";
      case "meeting":
        return "Toplantı";
      case "social":
        return "Sosyal";
      default:
        return category;
    }
  };

  return (
    <>
      <Helmet>
        <title>Faaliyetler - KARK</title>
        <meta name="description" content="Kuzey Kıbrıs Arama Kurtarma Derneği'nin eğitim, tatbikat ve sosyal faaliyetleri" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <main className="container mx-auto px-4 py-24">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">Faaliyetler</h1>
            <p className="text-muted-foreground">
              Eğitim, tatbikat ve sosyal faaliyetlerimiz
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-col gap-4 mb-8">
            <Input
              placeholder="Faaliyet ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="max-w-sm"
            />
            
            {/* Year Filter */}
            <div className="flex flex-wrap gap-2">
              <span className="text-sm font-medium mr-2 self-center">Yıl:</span>
              <Button
                size="sm"
                variant={selectedYear === "all" ? "default" : "outline"}
                onClick={() => setSelectedYear("all")}
              >
                Tümü
              </Button>
              {years.map((year) => (
                <Button
                  key={year}
                  size="sm"
                  variant={selectedYear === year.toString() ? "default" : "outline"}
                  onClick={() => setSelectedYear(year.toString())}
                >
                  {year}
                </Button>
              ))}
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              <span className="text-sm font-medium mr-2 self-center">Kategori:</span>
              <Button
                size="sm"
                variant={selectedCategory === "all" ? "default" : "outline"}
                onClick={() => setSelectedCategory("all")}
              >
                Tümü
              </Button>
              {categories.map((category) => (
                <Button
                  key={category}
                  size="sm"
                  variant={selectedCategory === category ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category)}
                >
                  {getCategoryLabel(category)}
                </Button>
              ))}
            </div>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : filteredActivities.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <p className="text-muted-foreground">Henüz faaliyet bulunmamaktadır.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredActivities.map((activity) => (
                <Link key={activity.id} href={`/activities/${activity.id}`}>
                  <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                    {activity.imageUrl && (
                      <div className="aspect-video relative overflow-hidden rounded-t-lg">
                        <img
                          src={activity.imageUrl}
                          alt={activity.title}
                          className="object-cover w-full h-full"
                        />
                      </div>
                    )}
                    <CardHeader>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={getCategoryColor(activity.category)}>
                          {getCategoryLabel(activity.category)}
                        </Badge>
                        {activity.date && (
                          <span className="text-sm text-muted-foreground">
                            {formatDate(activity.date)}
                          </span>
                        )}
                      </div>
                      <CardTitle className="line-clamp-2">{activity.title}</CardTitle>
                      <CardDescription className="line-clamp-3">
                        {activity.description}
                      </CardDescription>
                    </CardHeader>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </main>

        <Footer />
      </div>
    </>
  );
}