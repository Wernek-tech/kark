import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Calendar, MapPin, Users } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { formatDate } from "@/lib/utils";
import { Helmet } from "react-helmet-async";

interface Operation {
  id: number;
  title: string;
  description: string;
  content: string;
  date: string;
  location: string;
  teamSize: number;
  image?: string;
  createdAt: string;
  updatedAt: string;
}

export default function OperationsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedYear, setSelectedYear] = useState<string>("all");

  const { data: operations = [], isLoading } = useQuery<Operation[]>({
    queryKey: ["/api/operations"],
  });

  // Get unique years from operations
  const years = Array.from(
    new Set(operations.map((op) => new Date(op.date).getFullYear()))
  )
    .filter((year) => !isNaN(year))
    .sort((a, b) => b - a);

  // Filter operations
  const filteredOperations = operations.filter((operation) => {
    const matchesSearch =
      searchQuery === "" ||
      operation.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      operation.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesYear =
      selectedYear === "all" ||
      new Date(operation.date).getFullYear().toString() === selectedYear;

    return matchesSearch && matchesYear;
  });

  return (
    <>
      <Helmet>
        <title>Operasyonlar - KARK</title>
        <meta name="description" content="Kuzey Kıbrıs Arama Kurtarma Derneği'nin gerçekleştirdiği arama kurtarma operasyonları" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <main className="container mx-auto px-4 py-24">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">Operasyonlar</h1>
            <p className="text-muted-foreground">
              Gerçekleştirdiğimiz arama kurtarma operasyonları
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <Input
              placeholder="Operasyon ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="max-w-sm"
            />
            <div className="flex gap-2">
              <Button
                variant={selectedYear === "all" ? "default" : "outline"}
                onClick={() => setSelectedYear("all")}
              >
                Tümü
              </Button>
              {years.map((year) => (
                <Button
                  key={year}
                  variant={selectedYear === year.toString() ? "default" : "outline"}
                  onClick={() => setSelectedYear(year.toString())}
                >
                  {year}
                </Button>
              ))}
            </div>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : filteredOperations.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <p className="text-muted-foreground">Henüz operasyon bulunmamaktadır.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredOperations.map((operation) => (
                <Link key={operation.id} href={`/operations/${operation.id}`}>
                  <Card className="hover:shadow-lg transition-shadow cursor-pointer h-full">
                    {operation.image && (
                      <div className="aspect-video relative overflow-hidden rounded-t-lg">
                        <img
                          src={operation.image}
                          alt={operation.title}
                          className="object-cover w-full h-full"
                        />
                      </div>
                    )}
                    <CardHeader>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="destructive">Operasyon</Badge>
                        <span className="text-sm text-muted-foreground">
                          {formatDate(operation.date)}
                        </span>
                      </div>
                      <CardTitle className="line-clamp-2">{operation.title}</CardTitle>
                      <CardDescription className="line-clamp-3">
                        {operation.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span>{operation.location}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          <span>{operation.teamSize} kişi</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </main>

        <Footer />
      </div>
    </>
  );
}