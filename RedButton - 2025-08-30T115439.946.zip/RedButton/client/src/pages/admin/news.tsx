import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Search, Edit, Trash2, Plus, Calendar, Tag, Image, AlertCircle } from "lucide-react";
import type { News } from "@shared/schema";

const newsSchema = z.object({
  title: z.string().min(3, "Başlık en az 3 karakter olmalıdır"),
  content: z.string().min(10, "İçerik en az 10 karakter olmalıdır"),
  summary: z.string().optional(),
  category: z.string().optional(),
  publishDate: z.string(),
  isPublished: z.boolean(),
  imagePath: z.string().optional()
});

type NewsFormData = z.infer<typeof newsSchema>;

export default function AdminNews() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingNews, setEditingNews] = useState<News | null>(null);
  const [deleteNewsId, setDeleteNewsId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");

  const { data: newsItems, isLoading, error } = useQuery({
    queryKey: ["/api/admin/news"],
    queryFn: async () => {
      const res = await fetch("/api/admin/news", {
        credentials: "include"
      });
      if (!res.ok) throw new Error("Haberler yüklenirken hata oluştu");
      return res.json() as Promise<News[]>;
    }
  });

  const form = useForm<NewsFormData>({
    resolver: zodResolver(newsSchema),
    defaultValues: {
      title: "",
      content: "",
      summary: "",
      category: "",
      publishDate: new Date().toISOString().split('T')[0],
      isPublished: true,
      imagePath: ""
    }
  });

  const createNewsMutation = useMutation({
    mutationFn: async (data: NewsFormData) => {
      const res = await fetch("/api/admin/news", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error("Haber oluşturulamadı");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Başarılı", description: "Haber başarıyla oluşturuldu" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/news"] });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({ title: "Hata", description: "Haber oluşturulurken hata oluştu", variant: "destructive" });
    }
  });

  const updateNewsMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: NewsFormData }) => {
      const res = await fetch(`/api/admin/news/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error("Haber güncellenemedi");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Başarılı", description: "Haber başarıyla güncellendi" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/news"] });
      setIsDialogOpen(false);
      setEditingNews(null);
      form.reset();
    },
    onError: () => {
      toast({ title: "Hata", description: "Haber güncellenirken hata oluştu", variant: "destructive" });
    }
  });

  const deleteNewsMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/admin/news/${id}`, {
        method: "DELETE",
        credentials: "include"
      });
      if (!res.ok) throw new Error("Haber silinemedi");
    },
    onSuccess: () => {
      toast({ title: "Başarılı", description: "Haber başarıyla silindi" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/news"] });
      setDeleteNewsId(null);
    },
    onError: () => {
      toast({ title: "Hata", description: "Haber silinirken hata oluştu", variant: "destructive" });
    }
  });

  const handleSubmit = (data: NewsFormData) => {
    if (editingNews) {
      updateNewsMutation.mutate({ id: editingNews.id, data });
    } else {
      createNewsMutation.mutate(data);
    }
  };

  const handleEdit = (news: News) => {
    setEditingNews(news);
    form.reset({
      title: news.title,
      content: news.content,
      summary: news.summary || "",
      category: news.category || "",
      publishDate: format(new Date(news.publishDate), "yyyy-MM-dd"),
      isPublished: news.isPublished,
      imagePath: news.imagePath || ""
    });
    setIsDialogOpen(true);
  };

  const filteredNews = newsItems?.filter(news => {
    const matchesSearch = news.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         news.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === "all" || news.category === categoryFilter;
    return matchesSearch && matchesCategory;
  }) || [];

  const categories = [...new Set(newsItems?.map(news => news.category).filter(Boolean) || [])];

  if (error) {
    return (
      <AdminLayout title="Haberler">
        <div className="flex items-center justify-center min-h-[400px]">
          <Card className="w-full max-w-md">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2 text-destructive">
                <AlertCircle className="h-5 w-5" />
                <p>Haberler yüklenirken bir hata oluştu</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Haberler">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Haber Yönetimi</h1>
            <p className="text-muted-foreground">Haberleri yönetin</p>
          </div>
          <Button
            onClick={() => {
              setEditingNews(null);
              form.reset();
              setIsDialogOpen(true);
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            Yeni Haber
          </Button>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Haber ara..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Kategori seçin" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tüm Kategoriler</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : filteredNews.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">Henüz haber bulunmuyor</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Başlık</TableHead>
                    <TableHead>Kategori</TableHead>
                    <TableHead>Yayın Tarihi</TableHead>
                    <TableHead>Durum</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredNews.map((news) => (
                    <TableRow key={news.id}>
                      <TableCell className="font-medium">
                        <div>
                          <p className="font-semibold">{news.title}</p>
                          {news.summary && (
                            <p className="text-sm text-muted-foreground line-clamp-1">{news.summary}</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {news.category && (
                          <Badge variant="outline">
                            <Tag className="h-3 w-3 mr-1" />
                            {news.category}
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          {format(new Date(news.publishDate), "dd MMMM yyyy", { locale: tr })}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={news.isPublished ? "default" : "secondary"}>
                          {news.isPublished ? "Yayında" : "Taslak"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(news)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setDeleteNewsId(news.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingNews ? "Haber Düzenle" : "Yeni Haber Oluştur"}
              </DialogTitle>
              <DialogDescription>
                {editingNews ? "Haber bilgilerini güncelleyin." : "Yeni bir haber oluşturun."}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Başlık</Label>
                <Input
                  id="title"
                  {...form.register("title")}
                  placeholder="Haber başlığı"
                />
                {form.formState.errors.title && (
                  <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="summary">Özet</Label>
                <Textarea
                  id="summary"
                  {...form.register("summary")}
                  placeholder="Kısa özet (isteğe bağlı)"
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="content">İçerik</Label>
                <Textarea
                  id="content"
                  {...form.register("content")}
                  placeholder="Haber içeriği"
                  rows={6}
                />
                {form.formState.errors.content && (
                  <p className="text-sm text-destructive">{form.formState.errors.content.message}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Kategori</Label>
                  <Input
                    id="category"
                    {...form.register("category")}
                    placeholder="Örn: Eğitim, Tatbikat"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="publishDate">Yayın Tarihi</Label>
                  <Input
                    id="publishDate"
                    type="date"
                    {...form.register("publishDate")}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="imagePath">Resim URL</Label>
                <Input
                  id="imagePath"
                  {...form.register("imagePath")}
                  placeholder="https://example.com/image.jpg"
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="isPublished"
                  checked={form.watch("isPublished")}
                  onCheckedChange={(checked) => form.setValue("isPublished", checked)}
                />
                <Label htmlFor="isPublished">Yayınla</Label>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  İptal
                </Button>
                <Button type="submit" disabled={createNewsMutation.isPending || updateNewsMutation.isPending}>
                  {editingNews ? "Güncelle" : "Oluştur"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        <AlertDialog open={!!deleteNewsId} onOpenChange={() => setDeleteNewsId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Haberi Sil</AlertDialogTitle>
              <AlertDialogDescription>
                Bu haberi silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>İptal</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => deleteNewsId && deleteNewsMutation.mutate(deleteNewsId)}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Sil
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AdminLayout>
  );
}