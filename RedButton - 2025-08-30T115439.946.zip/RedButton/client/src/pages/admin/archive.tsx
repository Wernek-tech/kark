import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Helmet } from "react-helmet-async";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { ArchiveItem, InsertArchiveItem } from "@shared/schema";
import { formatDate } from "@/lib/utils";
import { 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  EyeOff, 
  Star, 
  StarOff, 
  Calendar, 
  MapPin, 
  Users, 
  Trophy,
  Image,
  Video,
  FileText,
  Search,
  Filter
} from "lucide-react";
import ImageUrlHelper from "@/components/admin/ImageUrlHelper";
import ImageWithFallback from "@/components/ImageWithFallback";

export default function AdminArchive() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ArchiveItem | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Form state
  const [formData, setFormData] = useState<Partial<InsertArchiveItem>>({
    title: "",
    description: "",
    content: "",
    itemType: "operation",
    date: new Date(),
    location: "",
    participants: "",
    outcome: "",
    imageUrl: "",
    videoUrl: "",
    documentUrl: "",
    tags: [],
    isPublished: false,
    isFeatured: false,
  });

  // Fetch archive items
  const { data: archiveItems = [], isLoading } = useQuery<ArchiveItem[]>({
    queryKey: ["/api/admin/archive"],
    queryFn: async () => {
      const response = await fetch("/api/admin/archive");
      if (!response.ok) throw new Error("Arşiv öğeleri alınamadı");
      return response.json();
    },
  });

  // Create mutation
  const createMutation = useMutation({
    mutationFn: async (item: InsertArchiveItem) => {
      const response = await fetch("/api/admin/archive", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(item),
      });
      if (!response.ok) throw new Error("Arşiv öğesi oluşturulamadı");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/archive"] });
      setIsCreateDialogOpen(false);
      resetForm();
      toast({
        title: "Başarılı",
        description: "Arşiv öğesi başarıyla oluşturuldu",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Arşiv öğesi oluşturulurken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, item }: { id: number; item: InsertArchiveItem }) => {
      const response = await fetch(`/api/admin/archive/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(item),
      });
      if (!response.ok) throw new Error("Arşiv öğesi güncellenemedi");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/archive"] });
      setIsEditDialogOpen(false);
      setEditingItem(null);
      resetForm();
      toast({
        title: "Başarılı",
        description: "Arşiv öğesi başarıyla güncellendi",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Arşiv öğesi güncellenirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/admin/archive/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("Arşiv öğesi silinemedi");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/archive"] });
      toast({
        title: "Başarılı",
        description: "Arşiv öğesi başarıyla silindi",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Arşiv öğesi silinirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  // Toggle publish mutation
  const togglePublishMutation = useMutation({
    mutationFn: async ({ id, isPublished }: { id: number; isPublished: boolean }) => {
      const response = await fetch(`/api/admin/archive/${id}/toggle-publish`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isPublished }),
      });
      if (!response.ok) throw new Error("Yayın durumu değiştirilemedi");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/archive"] });
      toast({
        title: "Başarılı",
        description: "Yayın durumu başarıyla değiştirildi",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Yayın durumu değiştirilirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  // Toggle featured mutation
  const toggleFeaturedMutation = useMutation({
    mutationFn: async ({ id, isFeatured }: { id: number; isFeatured: boolean }) => {
      const response = await fetch(`/api/admin/archive/${id}/toggle-featured`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isFeatured }),
      });
      if (!response.ok) throw new Error("Öne çıkarma durumu değiştirilemedi");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/archive"] });
      toast({
        title: "Başarılı",
        description: "Öne çıkarma durumu başarıyla değiştirildi",
      });
    },
    onError: () => {
      toast({
        title: "Hata",
        description: "Öne çıkarma durumu değiştirilirken bir hata oluştu",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      content: "",
      itemType: "operation",
      date: new Date(),
      location: "",
      participants: "",
      outcome: "",
      imageUrl: "",
      videoUrl: "",
      documentUrl: "",
      tags: [],
      isPublished: false,
      isFeatured: false,
    });
  };

  const handleSubmit = () => {
    if (!formData.title || !formData.description) {
      toast({
        title: "Hata",
        description: "Başlık ve açıklama alanları zorunludur",
        variant: "destructive",
      });
      return;
    }

    const item: InsertArchiveItem = {
      title: formData.title!,
      description: formData.description!,
      content: formData.content || "",
      itemType: formData.itemType || "operation",
      date: formData.date || new Date(),
      location: formData.location || "",
      participants: formData.participants || "",
      outcome: formData.outcome || "",
      imageUrl: formData.imageUrl || "",
      videoUrl: formData.videoUrl || "",
      documentUrl: formData.documentUrl || "",
      tags: formData.tags || [],
      isPublished: formData.isPublished || false,
      isFeatured: formData.isFeatured || false,
    };

    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, item });
    } else {
      createMutation.mutate(item);
    }
  };

  const handleEdit = (item: ArchiveItem) => {
    setEditingItem(item);
    setFormData({
      title: item.title,
      description: item.description,
      content: item.content,
      itemType: item.itemType,
      date: item.date,
      location: item.location,
      participants: item.participants,
      outcome: item.outcome,
      imageUrl: item.imageUrl,
      videoUrl: item.videoUrl,
      documentUrl: item.documentUrl,
      tags: item.tags,
      isPublished: item.isPublished,
      isFeatured: item.isFeatured,
    });
    setIsEditDialogOpen(true);
  };

  const handleTagsChange = (value: string) => {
    const tags = value.split(",").map(tag => tag.trim()).filter(tag => tag.length > 0);
    setFormData(prev => ({ ...prev, tags }));
  };

  // Filter items
  const filteredItems = archiveItems.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === "all" || item.itemType === filterType;
    const matchesStatus = filterStatus === "all" || 
                         (filterStatus === "published" && item.isPublished) ||
                         (filterStatus === "draft" && !item.isPublished) ||
                         (filterStatus === "featured" && item.isFeatured);
    
    return matchesSearch && matchesType && matchesStatus;
  });

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "operation": return "Operasyon";
      case "training": return "Eğitim";
      case "event": return "Etkinlik";
      case "report": return "Rapor";
      case "news": return "Haber";
      default: return type;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "operation": return <Calendar className="w-4 h-4 text-blue-600" />;
      case "training": return <Users className="w-4 h-4 text-green-600" />;
      case "event": return <Calendar className="w-4 h-4 text-purple-600" />;
      case "report": return <FileText className="w-4 h-4 text-orange-600" />;
      case "news": return <FileText className="w-4 h-4 text-red-600" />;
      default: return <FileText className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <AdminLayout title="Arşiv Yönetimi">
      <Helmet>
        <title>Arşiv Yönetimi | Admin Panel</title>
      </Helmet>

      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Arşiv Yönetimi</h1>
            <p className="text-muted-foreground">
              Operasyonları, eğitimleri ve etkinlikleri arşivleyin
            </p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => { resetForm(); setIsCreateDialogOpen(true); }}>
                <Plus className="h-4 w-4 mr-2" />
                Yeni Arşiv Öğesi
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Yeni Arşiv Öğesi Oluştur</DialogTitle>
                <DialogDescription>
                  Operasyon, eğitim, etkinlik veya rapor bilgilerini girin
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Başlık *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Arşiv öğesi başlığı"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="itemType">Tür *</Label>
                    <Select value={formData.itemType} onValueChange={(value) => setFormData(prev => ({ ...prev, itemType: value as any }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Tür seçin" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="operation">Operasyon</SelectItem>
                        <SelectItem value="training">Eğitim</SelectItem>
                        <SelectItem value="event">Etkinlik</SelectItem>
                        <SelectItem value="report">Rapor</SelectItem>
                        <SelectItem value="news">Haber</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="date">Tarih *</Label>
                    <Input
                      id="date"
                      type="datetime-local"
                      value={formData.date ? new Date(formData.date).toISOString().slice(0, 16) : ""}
                      onChange={(e) => setFormData(prev => ({ ...prev, date: new Date(e.target.value) }))}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="location">Konum</Label>
                    <Input
                      id="location"
                      value={formData.location || ""}
                      onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                      placeholder="Operasyon/etkinlik konumu"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="participants">Katılımcılar</Label>
                    <Input
                      id="participants"
                      value={formData.participants || ""}
                      onChange={(e) => setFormData(prev => ({ ...prev, participants: e.target.value }))}
                      placeholder="Katılımcı sayısı veya isimleri"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="outcome">Sonuç</Label>
                    <Input
                      id="outcome"
                      value={formData.outcome || ""}
                      onChange={(e) => setFormData(prev => ({ ...prev, outcome: e.target.value }))}
                      placeholder="Operasyon/etkinlik sonucu"
                    />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="description">Açıklama *</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Kısa açıklama"
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="content">Detaylı İçerik</Label>
                    <Textarea
                      id="content"
                      value={formData.content || ""}
                      onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                      placeholder="Detaylı açıklama ve rapor"
                      rows={5}
                    />
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <Label htmlFor="imageUrl">Resim URL</Label>
                      <ImageUrlHelper />
                    </div>
                    <Input
                      id="imageUrl"
                      value={formData.imageUrl || ""}
                      onChange={(e) => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
                      placeholder="https://example.com/image.jpg"
                    />
                    {formData.imageUrl && (
                      <div className="mt-2">
                        <p className="text-xs text-muted-foreground mb-1">Önizleme:</p>
                        <ImageWithFallback
                          src={formData.imageUrl}
                          alt="Önizleme"
                          className="w-32 h-20 object-cover rounded border"
                          fallbackClassName="w-32 h-20 rounded border"
                        />
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <Label htmlFor="videoUrl">Video URL</Label>
                    <Input
                      id="videoUrl"
                      value={formData.videoUrl || ""}
                      onChange={(e) => setFormData(prev => ({ ...prev, videoUrl: e.target.value }))}
                      placeholder="https://example.com/video.mp4"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="documentUrl">Belge/Döküman URL</Label>
                    <Input
                      id="documentUrl"
                      value={formData.documentUrl || ""}
                      onChange={(e) => setFormData(prev => ({ ...prev, documentUrl: e.target.value }))}
                      placeholder="https://example.com/document.pdf"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="tags">Etiketler</Label>
                    <Input
                      id="tags"
                      value={formData.tags?.join(", ") || ""}
                      onChange={(e) => handleTagsChange(e.target.value)}
                      placeholder="etiket1, etiket2, etiket3"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Etiketleri virgülle ayırın
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-4 pt-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="isPublished"
                    checked={formData.isPublished}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isPublished: checked }))}
                  />
                  <Label htmlFor="isPublished">Hemen Yayınla</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch
                    id="isFeatured"
                    checked={formData.isFeatured}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isFeatured: checked }))}
                  />
                  <Label htmlFor="isFeatured">Öne Çıkar</Label>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => { setIsCreateDialogOpen(false); resetForm(); }}>
                  İptal
                </Button>
                <Button onClick={handleSubmit} disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Oluşturuluyor..." : "Oluştur"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filtrele ve Ara
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Ara..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger>
                  <SelectValue placeholder="Tür" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tüm Türler</SelectItem>
                  <SelectItem value="operation">Operasyon</SelectItem>
                  <SelectItem value="training">Eğitim</SelectItem>
                  <SelectItem value="event">Etkinlik</SelectItem>
                  <SelectItem value="report">Rapor</SelectItem>
                  <SelectItem value="news">Haber</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="Durum" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tüm Durumlar</SelectItem>
                  <SelectItem value="published">Yayınlı</SelectItem>
                  <SelectItem value="draft">Taslak</SelectItem>
                  <SelectItem value="featured">Öne Çıkarılmış</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchTerm("");
                  setFilterType("all");
                  setFilterStatus("all");
                }}
              >
                Temizle
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-blue-600">{archiveItems.length}</div>
              <div className="text-sm text-muted-foreground">Toplam Arşiv</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-green-600">
                {archiveItems.filter(item => item.isPublished).length}
              </div>
              <div className="text-sm text-muted-foreground">Yayınlı</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-orange-600">
                {archiveItems.filter(item => !item.isPublished).length}
              </div>
              <div className="text-sm text-muted-foreground">Taslak</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-purple-600">
                {archiveItems.filter(item => item.isFeatured).length}
              </div>
              <div className="text-sm text-muted-foreground">Öne Çıkarılmış</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-red-600">
                {archiveItems.filter(item => 
                  new Date(item.date).getFullYear() === new Date().getFullYear()
                ).length}
              </div>
              <div className="text-sm text-muted-foreground">Bu Yıl</div>
            </CardContent>
          </Card>
        </div>

        {/* Archive Items List */}
        <div className="grid grid-cols-1 gap-6">
          {isLoading ? (
            <div className="text-center py-12">
              <div className="text-muted-foreground">Yükleniyor...</div>
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-muted-foreground">
                {searchTerm || filterType !== "all" || filterStatus !== "all"
                  ? "Filtrelere uygun arşiv öğesi bulunamadı"
                  : "Henüz arşiv öğesi bulunmuyor"}
              </div>
            </div>
          ) : (
            filteredItems.map((item) => (
              <Card key={item.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Badge variant={item.isPublished ? "default" : "secondary"}>
                          {getTypeLabel(item.itemType)}
                        </Badge>
                        {item.isFeatured && (
                          <Badge variant="destructive">
                            <Star className="w-3 h-3 mr-1" />
                            Öne Çıkan
                          </Badge>
                        )}
                        {!item.isPublished && (
                          <Badge variant="outline">Taslak</Badge>
                        )}
                      </div>
                      <CardTitle className="text-xl">{item.title}</CardTitle>
                      <CardDescription>{item.description}</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => togglePublishMutation.mutate({ id: item.id, isPublished: !item.isPublished })}
                        disabled={togglePublishMutation.isPending}
                      >
                        {item.isPublished ? (
                          <>
                            <EyeOff className="w-4 h-4 mr-2" />
                            Gizle
                          </>
                        ) : (
                          <>
                            <Eye className="w-4 h-4 mr-2" />
                            Yayınla
                          </>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleFeaturedMutation.mutate({ id: item.id, isFeatured: !item.isFeatured })}
                        disabled={toggleFeaturedMutation.isPending}
                      >
                        {item.isFeatured ? (
                          <>
                            <StarOff className="w-4 h-4 mr-2" />
                            Çıkar
                          </>
                        ) : (
                          <>
                            <Star className="w-4 h-4 mr-2" />
                            Öne Çıkar
                          </>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(item)}
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Düzenle
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => deleteMutation.mutate(item.id)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Sil
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span>{formatDate(item.date)}</span>
                    </div>
                    {item.location && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-muted-foreground" />
                        <span>{item.location}</span>
                      </div>
                    )}
                    {item.participants && (
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-muted-foreground" />
                        <span>{item.participants}</span>
                      </div>
                    )}
                    {item.outcome && (
                      <div className="flex items-center gap-2">
                        <Trophy className="w-4 h-4 text-muted-foreground" />
                        <span>{item.outcome}</span>
                      </div>
                    )}
                  </div>
                  
                  {item.content && (
                    <div className="mt-4">
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {item.content}
                      </p>
                    </div>
                  )}
                  
                  <div className="flex items-center gap-2 mt-4">
                    {item.imageUrl && (
                      <Badge variant="outline">
                        <Image className="w-3 h-3 mr-1" />
                        Resim
                      </Badge>
                    )}
                    {item.videoUrl && (
                      <Badge variant="outline">
                        <Video className="w-3 h-3 mr-1" />
                        Video
                      </Badge>
                    )}
                    {item.documentUrl && (
                      <Badge variant="outline">
                        <FileText className="w-3 h-3 mr-1" />
                        Belge
                      </Badge>
                    )}
                  </div>
                  
                  {item.tags && item.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-4">
                      {item.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Arşiv Öğesini Düzenle</DialogTitle>
              <DialogDescription>
                Mevcut arşiv öğesi bilgilerini güncelleyin
              </DialogDescription>
            </DialogHeader>
            
            {/* Same form content as create dialog */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-title">Başlık *</Label>
                  <Input
                    id="edit-title"
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Arşiv öğesi başlığı"
                  />
                </div>
                
                <div>
                  <Label htmlFor="edit-itemType">Tür *</Label>
                  <Select value={formData.itemType} onValueChange={(value) => setFormData(prev => ({ ...prev, itemType: value as any }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Tür seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="operation">Operasyon</SelectItem>
                      <SelectItem value="training">Eğitim</SelectItem>
                      <SelectItem value="event">Etkinlik</SelectItem>
                      <SelectItem value="report">Rapor</SelectItem>
                      <SelectItem value="news">Haber</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="edit-date">Tarih *</Label>
                  <Input
                    id="edit-date"
                    type="datetime-local"
                    value={formData.date ? new Date(formData.date).toISOString().slice(0, 16) : ""}
                    onChange={(e) => setFormData(prev => ({ ...prev, date: new Date(e.target.value) }))}
                  />
                </div>
                
                <div>
                  <Label htmlFor="edit-location">Konum</Label>
                  <Input
                    id="edit-location"
                    value={formData.location || ""}
                    onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                    placeholder="Operasyon/etkinlik konumu"
                  />
                </div>
                
                <div>
                  <Label htmlFor="edit-participants">Katılımcılar</Label>
                  <Input
                    id="edit-participants"
                    value={formData.participants || ""}
                    onChange={(e) => setFormData(prev => ({ ...prev, participants: e.target.value }))}
                    placeholder="Katılımcı sayısı veya isimleri"
                  />
                </div>
                
                <div>
                  <Label htmlFor="edit-outcome">Sonuç</Label>
                  <Input
                    id="edit-outcome"
                    value={formData.outcome || ""}
                    onChange={(e) => setFormData(prev => ({ ...prev, outcome: e.target.value }))}
                    placeholder="Operasyon/etkinlik sonucu"
                  />
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-description">Açıklama *</Label>
                  <Textarea
                    id="edit-description"
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Kısa açıklama"
                    rows={3}
                  />
                </div>
                
                <div>
                  <Label htmlFor="edit-content">Detaylı İçerik</Label>
                  <Textarea
                    id="edit-content"
                    value={formData.content || ""}
                    onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                    placeholder="Detaylı açıklama ve rapor"
                    rows={5}
                  />
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label htmlFor="edit-imageUrl">Resim URL</Label>
                    <ImageUrlHelper />
                  </div>
                  <Input
                    id="edit-imageUrl"
                    value={formData.imageUrl || ""}
                    onChange={(e) => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
                    placeholder="https://example.com/image.jpg"
                  />
                  {formData.imageUrl && (
                    <div className="mt-2">
                      <p className="text-xs text-muted-foreground mb-1">Önizleme:</p>
                      <ImageWithFallback
                        src={formData.imageUrl}
                        alt="Önizleme"
                        className="w-32 h-20 object-cover rounded border"
                        fallbackClassName="w-32 h-20 rounded border"
                      />
                    </div>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="edit-videoUrl">Video URL</Label>
                  <Input
                    id="edit-videoUrl"
                    value={formData.videoUrl || ""}
                    onChange={(e) => setFormData(prev => ({ ...prev, videoUrl: e.target.value }))}
                    placeholder="https://example.com/video.mp4"
                  />
                </div>
                
                <div>
                  <Label htmlFor="edit-documentUrl">Belge URL</Label>
                  <Input
                    id="edit-documentUrl"
                    value={formData.documentUrl || ""}
                    onChange={(e) => setFormData(prev => ({ ...prev, documentUrl: e.target.value }))}
                    placeholder="https://example.com/document.pdf"
                  />
                </div>
                
                <div>
                  <Label htmlFor="edit-tags">Etiketler</Label>
                  <Input
                    id="edit-tags"
                    value={formData.tags?.join(", ") || ""}
                    onChange={(e) => handleTagsChange(e.target.value)}
                    placeholder="etiket1, etiket2, etiket3"
                  />
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="edit-isPublished"
                      checked={formData.isPublished}
                      onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isPublished: checked }))}
                    />
                    <Label htmlFor="edit-isPublished">Yayınla</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="edit-isFeatured"
                      checked={formData.isFeatured}
                      onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isFeatured: checked }))}
                    />
                    <Label htmlFor="edit-isFeatured">Öne Çıkar</Label>
                  </div>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                İptal
              </Button>
              <Button onClick={handleSubmit} disabled={updateMutation.isPending}>
                {updateMutation.isPending ? "Güncelleniyor..." : "Güncelle"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}