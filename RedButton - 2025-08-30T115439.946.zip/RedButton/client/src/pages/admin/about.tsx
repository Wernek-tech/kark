import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Loader2, Save, History, Users, Target, Eye, Plus, Trash, Edit } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

// Form schemas for different sections
const mainContentSchema = z.object({
  title: z.string().min(1, "Başlık gereklidir"),
  subtitle: z.string().min(1, "Alt başlık gereklidir"),
  whoWeAre: z.string().min(1, "Biz Kimiz metni gereklidir"),
  whoWeAreDetails: z.string().min(1, "Detaylı açıklama gereklidir"),
  mission: z.string().min(1, "Misyon metni gereklidir"),
  vision: z.string().min(1, "Vizyon metni gereklidir"),
  mainImage: z.string().url("Geçerli bir URL giriniz").optional().or(z.literal("")),
  secondaryImage: z.string().url("Geçerli bir URL giriniz").optional().or(z.literal("")),
});

const valueSchema = z.object({
  title: z.string().min(1, "Başlık gereklidir"),
  description: z.string().min(1, "Açıklama gereklidir"),
  icon: z.string().optional(),
});

const historyItemSchema = z.object({
  year: z.string().min(1, "Yıl gereklidir"),
  title: z.string().min(1, "Başlık gereklidir"),
  description: z.string().min(1, "Açıklama gereklidir"),
});

const footerContentSchema = z.object({
  joinUsTitle: z.string().min(1, "Başlık gereklidir"),
  joinUsDescription: z.string().min(1, "Açıklama gereklidir"),
  joinUsButtonText: z.string().min(1, "Buton metni gereklidir"),
  applicationFormUrl: z.string().url("Geçerli bir başvuru formu URL'si giriniz").min(1, "Başvuru formu URL'si gereklidir"),
});

type MainContentFormValues = z.infer<typeof mainContentSchema>;
type ValueFormValues = z.infer<typeof valueSchema>;
type HistoryItemFormValues = z.infer<typeof historyItemSchema>;
type FooterContentFormValues = z.infer<typeof footerContentSchema>;

// Define the structure for about us content
interface AboutUsContent {
  mainContent: MainContentFormValues;
  values: ValueFormValues[];
  history: HistoryItemFormValues[];
  footerContent: FooterContentFormValues;
}

// Values Editor Component
function ValuesEditor({ 
  values, 
  onSave, 
  isLoading 
}: { 
  values: ValueFormValues[], 
  onSave: (values: ValueFormValues[]) => void,
  isLoading: boolean 
}) {
  const [editingValues, setEditingValues] = useState<ValueFormValues[]>(values);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  useEffect(() => {
    setEditingValues(values);
  }, [values]);
  
  const form = useForm<ValueFormValues>({
    resolver: zodResolver(valueSchema),
    defaultValues: {
      title: "",
      description: "",
      icon: "",
    },
  });

  const handleEdit = (index: number) => {
    form.reset(editingValues[index]);
    setEditingIndex(index);
    setIsDialogOpen(true);
  };

  const handleAdd = () => {
    if (editingValues.length >= 3) {
      return; // Max 3 values
    }
    form.reset({ title: "", description: "", icon: "" });
    setEditingIndex(null);
    setIsDialogOpen(true);
  };

  const handleSaveValue = (data: ValueFormValues) => {
    const newValues = [...editingValues];
    
    if (editingIndex !== null) {
      newValues[editingIndex] = data;
    } else {
      newValues.push(data);
    }
    
    setEditingValues(newValues);
    setIsDialogOpen(false);
    form.reset();
  };

  const handleDelete = (index: number) => {
    const newValues = editingValues.filter((_, i) => i !== index);
    setEditingValues(newValues);
  };

  const handleSaveAll = () => {
    onSave(editingValues);
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-4">
        {editingValues.map((value, index) => (
          <div key={index} className="p-4 border rounded-lg">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <h4 className="font-semibold">{value.title}</h4>
                <p className="text-sm text-gray-600 mt-1">{value.description}</p>
                {value.icon && (
                  <p className="text-xs text-gray-500 mt-2">İkon: {value.icon}</p>
                )}
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleEdit(index)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => handleDelete(index)}
                >
                  <Trash className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {editingValues.length < 3 && (
        <Button
          variant="outline"
          onClick={handleAdd}
          className="w-full"
        >
          <Plus className="h-4 w-4 mr-2" />
          Yeni Değer Ekle
        </Button>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingIndex !== null ? "Değeri Düzenle" : "Yeni Değer Ekle"}
            </DialogTitle>
            <DialogDescription>
              Kurumsal değerinizi tanımlayın
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSaveValue)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Başlık</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Örn: İnsan Odaklılık" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Açıklama</FormLabel>
                    <FormControl>
                      <Textarea {...field} rows={3} placeholder="Bu değerin açıklaması..." />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="icon"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>İkon (SVG kodu - opsiyonel)</FormLabel>
                    <FormControl>
                      <Textarea {...field} rows={3} placeholder='<svg xmlns="http://www.w3.org/2000/svg"...' />
                    </FormControl>
                    <FormDescription>
                      SVG ikon kodu girebilirsiniz (opsiyonel)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="submit">Kaydet</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Button 
        onClick={handleSaveAll} 
        disabled={isLoading}
        className="w-full"
      >
        {isLoading ? (
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        ) : (
          <Save className="mr-2 h-4 w-4" />
        )}
        Tüm Değerleri Kaydet
      </Button>
    </div>
  );
}

// Timeline interface for API
interface TimelineItem {
  id: number;
  year: number;
  title: string;
  description: string;
  itemType: string;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

// History Editor Component - Updated to use Timeline API
function HistoryEditor({ 
  isLoading 
}: { 
  isLoading: boolean 
}) {
  const [timelineItems, setTimelineItems] = useState<TimelineItem[]>([]);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [timelineLoading, setTimelineLoading] = useState(true);
  const { toast } = useToast();
  
  const form = useForm<{
    year: number;
    title: string;
    description: string;
    itemType: string;
  }>({
    resolver: zodResolver(z.object({
      year: z.number().min(1900, "Geçerli bir yıl giriniz").max(2100, "Geçerli bir yıl giriniz"),
      title: z.string().min(1, "Başlık gereklidir"),
      description: z.string().min(1, "Açıklama gereklidir"),
      itemType: z.string().min(1, "Tür seçiniz"),
    })),
    defaultValues: {
      year: new Date().getFullYear(),
      title: "",
      description: "",
      itemType: "milestone",
    },
  });

  const itemTypes = [
    { value: 'milestone', label: 'Kilometre Taşı' },
    { value: 'achievement', label: 'Başarı' },
    { value: 'establishment', label: 'Kuruluş' },
    { value: 'expansion', label: 'Genişleme' },
    { value: 'partnership', label: 'İş Birliği' },
  ];

  useEffect(() => {
    fetchTimelineItems();
  }, []);

  const fetchTimelineItems = async () => {
    try {
      const response = await fetch('/api/timeline');
      if (response.ok) {
        const data = await response.json();
        setTimelineItems(data.sort((a: TimelineItem, b: TimelineItem) => a.year - b.year));
      }
    } catch (error) {
      console.error('Error fetching timeline items:', error);
      toast({
        title: "Hata",
        description: "Tarihçe öğeleri yüklenirken hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setTimelineLoading(false);
    }
  };

  const handleEdit = (index: number) => {
    const item = timelineItems[index];
    form.reset({
      year: item.year,
      title: item.title,
      description: item.description,
      itemType: item.itemType,
    });
    setEditingIndex(index);
    setIsDialogOpen(true);
  };

  const handleAdd = () => {
    form.reset({ 
      year: new Date().getFullYear(), 
      title: "", 
      description: "", 
      itemType: "milestone" 
    });
    setEditingIndex(null);
    setIsDialogOpen(true);
  };

  const handleSaveItem = async (data: { year: number; title: string; description: string; itemType: string }) => {
    try {
      const payload = {
        ...data,
        isActive: true,
        sortOrder: timelineItems.length + 1,
      };

      if (editingIndex !== null) {
        // Update existing item
        const item = timelineItems[editingIndex];
        const response = await fetch(`/api/admin/timeline/${item.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify(payload),
        });

        if (!response.ok) throw new Error('Güncelleme başarısız');
      } else {
        // Create new item
        const response = await fetch('/api/admin/timeline', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify(payload),
        });

        if (!response.ok) throw new Error('Ekleme başarısız');
      }

      await fetchTimelineItems();
      setIsDialogOpen(false);
      form.reset();
      
      toast({
        title: "Başarılı",
        description: editingIndex !== null ? "Tarihçe güncellendi." : "Yeni tarihçe eklendi.",
      });
    } catch (error) {
      toast({
        title: "Hata",
        description: "İşlem sırasında hata oluştu.",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (index: number) => {
    if (!confirm('Bu tarihçe öğesini silmek istediğinizden emin misiniz?')) {
      return;
    }

    try {
      const item = timelineItems[index];
      const response = await fetch(`/api/admin/timeline/${item.id}`, {
        method: 'DELETE',
        credentials: 'include',
      });

      if (!response.ok) throw new Error('Silme başarısız');

      await fetchTimelineItems();
      toast({
        title: "Başarılı",
        description: "Tarihçe öğesi silindi.",
      });
    } catch (error) {
      toast({
        title: "Hata",
        description: "Silme işlemi sırasında hata oluştu.",
        variant: "destructive",
      });
    }
  };

  if (timelineLoading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Tarihçe yükleniyor...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid gap-4">
        {timelineItems.map((item, index) => (
          <div key={item.id} className="p-4 border rounded-lg">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-bold text-blue-600">{item.year}</span>
                  <span className="font-semibold">{item.title}</span>
                  <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                    {itemTypes.find(t => t.value === item.itemType)?.label || item.itemType}
                  </span>
                </div>
                <p className="text-sm text-gray-600">{item.description}</p>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleEdit(index)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => handleDelete(index)}
                >
                  <Trash className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Button
        variant="outline"
        onClick={handleAdd}
        className="w-full"
      >
        <Plus className="h-4 w-4 mr-2" />
        Yeni Tarihçe Ekle
      </Button>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingIndex !== null ? "Tarihçe Düzenle" : "Yeni Tarihçe Ekle"}
            </DialogTitle>
            <DialogDescription>
              Kurumun tarihinde önemli bir anı ekleyin
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSaveItem)} className="space-y-4">
              <FormField
                control={form.control}
                name="year"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Yıl</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number"
                        value={field.value || ''}
                        onChange={e => field.onChange(parseInt(e.target.value) || '')}
                        placeholder="Örn: 2015" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Başlık</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Örn: Kuruluş" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Açıklama</FormLabel>
                    <FormControl>
                      <Textarea {...field} rows={3} placeholder="Bu dönemde neler oldu..." />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="itemType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tür</FormLabel>
                    <FormControl>
                      <select 
                        {...field} 
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        {itemTypes.map((type) => (
                          <option key={type.value} value={type.value}>
                            {type.label}
                          </option>
                        ))}
                      </select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="submit">Kaydet</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function AdminAboutPage() {
  const [activeTab, setActiveTab] = useState("main");
  const { toast } = useToast();

  // Fetch about us content
  const { data: aboutContent, isLoading } = useQuery<AboutUsContent>({
    queryKey: ["/api/about"],
    queryFn: async () => {
      // First, try to get existing about content from settings
      const settings = await apiRequest("GET", "/api/settings");
      const settingsData = await settings.json();
      
      // Parse about content from settings
      const aboutSetting = settingsData.find((s: any) => s.key === "about.content");
      if (aboutSetting && aboutSetting.value) {
        return JSON.parse(aboutSetting.value);
      }
      
      // Return default content if none exists
      return {
        mainContent: {
          title: "Hakkımızda",
          subtitle: "KARK Arama Kurtarma Derneği'nin hikayesi ve misyonu",
          whoWeAre: "Biz Kimiz?",
          whoWeAreDetails: "KARK (Kuzey Kıbrıs Arama Kurtarma), 2015 yılında Kuzey Kıbrıs Türk Cumhuriyeti'nde kurulmuş, kar amacı gütmeyen bir sivil toplum kuruluşudur.",
          mission: "Kuzey Kıbrıs Türk Cumhuriyeti'nde ve ihtiyaç duyulan her yerde, afet ve acil durumlarda hayat kurtarmak.",
          vision: "KKTC'de afet ve acil durum yönetiminde öncü, uluslararası alanda tanınan ve güvenilen bir organizasyon olmak.",
          mainImage: "",
          secondaryImage: "",
        },
        values: [
          {
            title: "İnsan Odaklılık",
            description: "Her faaliyetimizin merkezinde insan hayatını ve onurunu korumak yer alır.",
            icon: "heart"
          },
          {
            title: "Profesyonellik",
            description: "Sürekli eğitim ve gelişim ile en yüksek standartları korumaya çalışırız.",
            icon: "briefcase"
          },
          {
            title: "Dayanışma",
            description: "Takım çalışması ve işbirliği tüm faaliyetlerimizin temelidir.",
            icon: "users"
          }
        ],
        history: [
          {
            year: "2015",
            title: "Kuruluş",
            description: "KARK, bir grup gönüllü tarafından resmen kuruldu."
          },
          {
            year: "2017",
            title: "İlk Önemli Operasyon",
            description: "Girne Dağları'nda kaybolan üç dağcının başarılı kurtarma operasyonu."
          },
          {
            year: "2019",
            title: "Uluslararası İşbirliği",
            description: "AFAD ile işbirliği anlaşması imzalandı."
          },
          {
            year: "2023",
            title: "Bugün",
            description: "50'den fazla aktif gönüllü üyesi ile hizmet vermektedir."
          }
        ],
        footerContent: {
          joinUsTitle: "Bize Katılın",
          joinUsDescription: "KARK, toplumun her kesiminden gönüllülere açıktır.",
          joinUsButtonText: "Gönüllü Olmak İçin Başvurun",
          applicationFormUrl: "https://form.example.com/volunteer-application"
        }
      };
    },
  });

  // Forms for each section
  const mainForm = useForm<MainContentFormValues>({
    resolver: zodResolver(mainContentSchema),
    defaultValues: {
      title: "",
      subtitle: "",
      whoWeAre: "",
      whoWeAreDetails: "",
      mission: "",
      vision: "",
      mainImage: "",
      secondaryImage: "",
      ...(aboutContent?.mainContent || {})
    },
  });

  const footerForm = useForm<FooterContentFormValues>({
    resolver: zodResolver(footerContentSchema),
    defaultValues: {
      joinUsTitle: "",
      joinUsDescription: "",
      joinUsButtonText: "",
      applicationFormUrl: "",
      ...(aboutContent?.footerContent || {})
    },
  });
  
  // Update form values when aboutContent changes
  useEffect(() => {
    if (aboutContent?.mainContent) {
      mainForm.reset(aboutContent.mainContent);
    }
  }, [aboutContent?.mainContent]);
  
  useEffect(() => {
    if (aboutContent?.footerContent) {
      footerForm.reset(aboutContent.footerContent);
    }
  }, [aboutContent?.footerContent]);

  // Update content mutation
  const updateContentMutation = useMutation({
    mutationFn: async (data: AboutUsContent) => {
      const res = await apiRequest("PUT", "/api/settings", {
        "about.content": JSON.stringify(data)
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/about"] });
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Başarılı",
        description: "Hakkımızda içeriği güncellendi.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: `İçerik güncellenirken bir hata oluştu: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle main content save
  const handleMainContentSave = async (values: MainContentFormValues) => {
    if (!aboutContent) return;
    
    const updatedContent: AboutUsContent = {
      ...aboutContent,
      mainContent: values,
    };
    
    updateContentMutation.mutate(updatedContent);
  };

  // Handle footer content save
  const handleFooterContentSave = async (values: FooterContentFormValues) => {
    if (!aboutContent) return;
    
    const updatedContent: AboutUsContent = {
      ...aboutContent,
      footerContent: values,
    };
    
    updateContentMutation.mutate(updatedContent);
  };

  if (isLoading) {
    return (
      <AdminLayout title="Hakkımızda Yönetimi">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <>
      <Helmet>
        <title>Hakkımızda Yönetimi | KARK Admin</title>
      </Helmet>
      
      <AdminLayout title="Hakkımızda Yönetimi">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="main">Ana İçerik</TabsTrigger>
            <TabsTrigger value="values">Değerlerimiz</TabsTrigger>
            <TabsTrigger value="history">Tarihçe</TabsTrigger>
            <TabsTrigger value="footer">Alt Bölüm</TabsTrigger>
          </TabsList>

          {/* Main Content Tab */}
          <TabsContent value="main">
            <Card>
              <CardHeader>
                <CardTitle>Ana İçerik</CardTitle>
                <CardDescription>
                  Hakkımızda sayfasının ana içeriğini düzenleyin
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...mainForm}>
                  <form onSubmit={mainForm.handleSubmit(handleMainContentSave)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={mainForm.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Sayfa Başlığı</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={mainForm.control}
                        name="subtitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Alt Başlık</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={mainForm.control}
                      name="whoWeAre"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Biz Kimiz Başlığı</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={mainForm.control}
                      name="whoWeAreDetails"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Biz Kimiz Açıklaması</FormLabel>
                          <FormControl>
                            <Textarea {...field} rows={6} />
                          </FormControl>
                          <FormDescription>
                            Dernek hakkında detaylı bilgi
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={mainForm.control}
                      name="mission"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Misyonumuz</FormLabel>
                          <FormControl>
                            <Textarea {...field} rows={4} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={mainForm.control}
                      name="vision"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Vizyonumuz</FormLabel>
                          <FormControl>
                            <Textarea {...field} rows={4} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={mainForm.control}
                        name="mainImage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Ana Görsel URL</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="https://..." />
                            </FormControl>
                            <FormDescription>
                              Sayfanın üst kısmında görünecek ana görsel
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={mainForm.control}
                        name="secondaryImage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>İkinci Görsel URL</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="https://..." />
                            </FormControl>
                            <FormDescription>
                              Sayfada görünecek ikinci görsel
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <Button type="submit" disabled={updateContentMutation.isPending}>
                      {updateContentMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Save className="mr-2 h-4 w-4" />
                      )}
                      Kaydet
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Values Tab */}
          <TabsContent value="values">
            <Card>
              <CardHeader>
                <CardTitle>Değerlerimiz</CardTitle>
                <CardDescription>
                  Kurumsal değerlerinizi düzenleyin (3 adet değer girebilirsiniz)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ValuesEditor 
                  values={aboutContent?.values || []}
                  onSave={(values) => {
                    if (!aboutContent) return;
                    const updatedContent: AboutUsContent = {
                      ...aboutContent,
                      values,
                    };
                    updateContentMutation.mutate(updatedContent);
                  }}
                  isLoading={updateContentMutation.isPending}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Tarihçe</CardTitle>
                <CardDescription>
                  Kurumun tarihsel gelişimini düzenleyin
                </CardDescription>
              </CardHeader>
              <CardContent>
                <HistoryEditor 
                  isLoading={updateContentMutation.isPending}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Footer Content Tab */}
          <TabsContent value="footer">
            <Card>
              <CardHeader>
                <CardTitle>Alt Bölüm</CardTitle>
                <CardDescription>
                  Sayfanın alt kısmındaki "Bize Katılın" bölümünü düzenleyin
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...footerForm}>
                  <form onSubmit={footerForm.handleSubmit(handleFooterContentSave)} className="space-y-4">
                    <FormField
                      control={footerForm.control}
                      name="joinUsTitle"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Başlık</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={footerForm.control}
                      name="joinUsDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Açıklama</FormLabel>
                          <FormControl>
                            <Textarea {...field} rows={3} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={footerForm.control}
                        name="joinUsButtonText"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Buton Metni</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={footerForm.control}
                        name="applicationFormUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Başvuru Formu URL'si</FormLabel>
                            <FormControl>
                              <Input {...field} type="url" placeholder="https://form.example.com/basvuru" />
                            </FormControl>
                            <FormDescription>
                              Gönüllü başvuru formunun bulunduğu URL
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <Button type="submit" disabled={updateContentMutation.isPending}>
                      {updateContentMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Save className="mr-2 h-4 w-4" />
                      )}
                      Kaydet
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </AdminLayout>
    </>
  );
}