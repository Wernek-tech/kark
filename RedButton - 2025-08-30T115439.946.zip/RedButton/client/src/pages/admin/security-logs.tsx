import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/fixed-select";
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { Shield, FileText, Users, Calendar, Image, Settings, Heart, AlertTriangle } from 'lucide-react';

interface AdminLog {
  id: number;
  userId: number;
  action: string;
  details?: string;
  ipAddress?: string;
  userAgent?: string;
  resourceType?: string;
  resourceId?: string;
  timestamp: string;
}

interface AdminLogsResponse {
  logs: AdminLog[];
  pagination: {
    total: number;
    limit: number;
    offset: number;
  };
}

// Function to generate chart data from logs
function generateChartData(logs: AdminLog[]) {
  // Group logs by day
  const logsByDay: Record<string, { date: string; count: number }> = {};
  
  logs.forEach(log => {
    const date = format(new Date(log.timestamp), 'yyyy-MM-dd');
    if (!logsByDay[date]) {
      logsByDay[date] = { 
        date: format(new Date(log.timestamp), 'd MMM', { locale: tr }), 
        count: 0 
      };
    }
    logsByDay[date].count++;
  });
  
  // Convert to array for chart
  return Object.values(logsByDay).sort((a, b) => {
    return new Date(a.date).getTime() - new Date(b.date).getTime();
  });
}

// Resource type colors for the chart
const resourceTypeColors: Record<string, string> = {
  "events": "#8884d8",
  "media": "#82ca9d",
  "users": "#ffc658",
  "team": "#ff8042",
  "settings": "#0088FE",
  "sliders": "#00C49F",
  "donations": "#FFBB28",
  "default": "#FF8042"
};

// Helper function to get resource icon
const getResourceIcon = (resourceType: string | null | undefined) => {
  switch (resourceType) {
    case 'events':
      return <Calendar className="h-4 w-4 text-blue-500" />;
    case 'media':
      return <Image className="h-4 w-4 text-purple-500" />;
    case 'team':
      return <Users className="h-4 w-4 text-green-500" />;
    case 'settings':
      return <Settings className="h-4 w-4 text-gray-500" />;
    case 'users':
      return <Users className="h-4 w-4 text-orange-500" />;
    case 'donations':
      return <Heart className="h-4 w-4 text-red-500" />;
    default:
      return <FileText className="h-4 w-4 text-gray-500" />;
  }
};

// Helper function to format action type
const formatAction = (action: string) => {
  if (action.startsWith('GET')) {
    return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Görüntüleme</Badge>;
  } else if (action.startsWith('POST')) {
    return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Ekleme</Badge>;
  } else if (action.startsWith('PUT') || action.startsWith('PATCH')) {
    return <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">Güncelleme</Badge>;
  } else if (action.startsWith('DELETE')) {
    return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Silme</Badge>;
  }
  return <Badge variant="outline">{action}</Badge>;
};

// Color scheme for pie chart
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export default function SecurityLogsPage() {
  const [limit, setLimit] = useState(25);
  const [offset, setOffset] = useState(0);
  const [resourceType, setResourceType] = useState<string>("all");
  
  const { data, isLoading, isError } = useQuery<AdminLogsResponse>({
    queryKey: ['/api/admin-logs', limit, offset, resourceType],
    retry: false,
  });
  
  const handleNextPage = () => {
    if (data && offset + limit < data.pagination.total) {
      setOffset(offset + limit);
    }
  };

  const handlePrevPage = () => {
    if (offset - limit >= 0) {
      setOffset(offset - limit);
    }
  };
  
  // Data for activity over time chart
  const dailyActivityData = data?.logs ? generateChartData(data.logs) : [];
  
  // Data for action types pie chart
  const actionTypeData = React.useMemo(() => {
    if (!data?.logs || data.logs.length === 0) return [];
    
    const actionCounts: Record<string, number> = {};
    data.logs.forEach(log => {
      const actionType = log.action.split(' ')[0]; // GET, POST, PUT, DELETE
      actionCounts[actionType] = (actionCounts[actionType] || 0) + 1;
    });
    
    return Object.entries(actionCounts).map(([name, value]) => ({ name, value }));
  }, [data?.logs]);
  
  // Data for resource distribution chart
  const resourceDistributionData = React.useMemo(() => {
    if (!data?.logs || data.logs.length === 0) return [];
    
    const resourceCounts: Record<string, number> = {};
    data.logs.forEach(log => {
      const resource = log.resourceType || 'other';
      resourceCounts[resource] = (resourceCounts[resource] || 0) + 1;
    });
    
    return Object.entries(resourceCounts).map(([name, value]) => ({ name, value }));
  }, [data?.logs]);
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight mb-1">Güvenlik Kayıtları</h2>
          <p className="text-muted-foreground">Tüm yönetici aktivitelerinin güvenlik izlemeleri</p>
        </div>
        <Shield className="h-8 w-8 text-secondary" />
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-indigo-50 to-white dark:from-indigo-950 dark:to-gray-900 shadow-md border-indigo-100 dark:border-indigo-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium text-indigo-800 dark:text-indigo-300">Toplam İşlem</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-indigo-900 dark:text-indigo-100">{data?.pagination.total || 0}</div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-blue-50 to-white dark:from-blue-950 dark:to-gray-900 shadow-md border-blue-100 dark:border-blue-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium text-blue-800 dark:text-blue-300">En Aktif Kaynak</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-900 dark:text-blue-100">
              {resourceDistributionData.length > 0 
                ? resourceDistributionData.sort((a, b) => b.value - a.value)[0].name 
                : '-'}
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-br from-emerald-50 to-white dark:from-emerald-950 dark:to-gray-900 shadow-md border-emerald-100 dark:border-emerald-900">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium text-emerald-800 dark:text-emerald-300">Tehlikeli İşlemler</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-emerald-900 dark:text-emerald-100">
              {actionTypeData.find(item => item.name === 'DELETE')?.value || 0}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Activity Over Time Chart */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="text-lg">Zaman İçinde Aktivite</CardTitle>
            <CardDescription>Admin panelindeki günlük aktivite</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={dailyActivityData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 10,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="count" name="İşlem Sayısı" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      
        {/* Resource Distribution Pie Chart */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="text-lg">Kaynak Dağılımı</CardTitle>
            <CardDescription>Erişilen kaynak tiplerinin dağılımı</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={resourceDistributionData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {resourceDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend />
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Data Table */}
      <Card className="shadow-md">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-lg">Detaylı Güvenlik Kayıtları</CardTitle>
              <CardDescription>Tüm yönetici işlemleri</CardDescription>
            </div>
            <Select value={resourceType} onValueChange={setResourceType}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Tüm Kaynaklar" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tüm Kaynaklar</SelectItem>
                <SelectItem value="events">Etkinlikler</SelectItem>
                <SelectItem value="media">Medya</SelectItem>
                <SelectItem value="team">Takım</SelectItem>
                <SelectItem value="settings">Ayarlar</SelectItem>
                <SelectItem value="sliders">Slider</SelectItem>
                <SelectItem value="users">Kullanıcılar</SelectItem>
                <SelectItem value="donations">Bağışlar</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : isError ? (
            <Alert variant="destructive" className="mb-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Hata</AlertTitle>
              <AlertDescription>Kayıtlar yüklenirken bir hata oluştu.</AlertDescription>
            </Alert>
          ) : (
            <>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="w-[60px]">ID</TableHead>
                      <TableHead className="w-[100px]">Kullanıcı</TableHead>
                      <TableHead className="w-[120px]">İşlem Tipi</TableHead>
                      <TableHead>İşlem Detayı</TableHead>
                      <TableHead className="w-[120px]">Kaynak</TableHead>
                      <TableHead className="w-[160px]">Tarih</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data?.logs.map((log) => (
                      <TableRow key={log.id} className="hover:bg-muted/30">
                        <TableCell className="font-medium">{log.id}</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-xs">
                            {log.userId === 2 ? "Supermanager" : "Admin"}
                          </Badge>
                        </TableCell>
                        <TableCell>{formatAction(log.action)}</TableCell>
                        <TableCell>{log.details || log.action}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {getResourceIcon(log.resourceType)}
                            <span>{log.resourceType || 'Diğer'}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {format(new Date(log.timestamp), 'dd.MM.yyyy HH:mm')}
                        </TableCell>
                      </TableRow>
                    ))}
                    {data?.logs.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                          <div className="flex flex-col items-center justify-center space-y-2">
                            <FileText className="h-8 w-8 text-muted" />
                            <p>Henüz kayıt bulunmuyor</p>
                            <p className="text-xs text-muted-foreground">Yönetici işlemleri burada gösterilecek</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
              
              <div className="flex items-center justify-between mt-6">
                <div className="text-sm text-muted-foreground">
                  Toplam <strong>{data?.pagination.total || 0}</strong> kayıttan <strong>{offset + 1}</strong>-<strong>{Math.min(offset + limit, data?.pagination.total || 0)}</strong> arası gösteriliyor
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handlePrevPage}
                    disabled={offset === 0}
                  >
                    Önceki Sayfa
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleNextPage}
                    disabled={offset + limit >= (data?.pagination.total || 0)}
                  >
                    Sonraki Sayfa
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}