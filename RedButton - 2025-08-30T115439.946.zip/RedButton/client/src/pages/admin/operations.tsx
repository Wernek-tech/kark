import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Edit, Trash2, Plus, Calendar, MapPin, Users, AlertCircle, X } from "lucide-react";
import type { Operation, TeamMember } from "@shared/schema";

const operationSchema = z.object({
  title: z.string().min(3, "Başlık en az 3 karakter olmalıdır"),
  description: z.string().min(10, "Açıklama en az 10 karakter olmalıdır"),
  operationDate: z.string(),
  location: z.string().min(3, "Konum en az 3 karakter olmalıdır"),
  status: z.enum(["ongoing", "completed", "cancelled"]),
  teamMembers: z.string().optional(),
  imagePath: z.string().optional()
});

type OperationFormData = z.infer<typeof operationSchema>;

export default function AdminOperations() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingOperation, setEditingOperation] = useState<Operation | null>(null);
  const [deleteOperationId, setDeleteOperationId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [photoUrls, setPhotoUrls] = useState<string[]>([""]);
  
  // Team member selection states
  const [selectedTeamMembers, setSelectedTeamMembers] = useState<TeamMember[]>([]);
  const [teamMemberSearch, setTeamMemberSearch] = useState("");
  const [showTeamMemberDropdown, setShowTeamMemberDropdown] = useState(false);
  
  // Functions to manage photo URLs
  const addPhotoUrl = () => {
    setPhotoUrls([...photoUrls, ""]);
  };
  
  const removePhotoUrl = (index: number) => {
    setPhotoUrls(photoUrls.filter((_, i) => i !== index));
  };
  
  const updatePhotoUrl = (index: number, value: string) => {
    const newUrls = [...photoUrls];
    newUrls[index] = value;
    setPhotoUrls(newUrls);
  };

  const { data: operations, isLoading, error } = useQuery({
    queryKey: ["/api/admin/operations"],
    queryFn: async () => {
      const res = await fetch("/api/admin/operations", {
        credentials: "include"
      });
      if (!res.ok) throw new Error("Operasyonlar yüklenirken hata oluştu");
      return res.json() as Promise<Operation[]>;
    }
  });

  // Team members query for autocomplete
  const { data: teamMembers } = useQuery<TeamMember[]>({
    queryKey: ["/api/team"],
    queryFn: async () => {
      const res = await fetch("/api/team", {
        credentials: "include"
      });
      if (!res.ok) throw new Error("Ekip üyeleri yüklenirken hata oluştu");
      return res.json();
    }
  });

  const form = useForm<OperationFormData>({
    resolver: zodResolver(operationSchema),
    defaultValues: {
      title: "",
      description: "",
      operationDate: new Date().toISOString().split('T')[0],
      location: "",
      status: "completed",
      teamMembers: "",
      imagePath: ""
    }
  });

  // Team member helper functions
  const addTeamMember = (member: TeamMember) => {
    if (!selectedTeamMembers.find(m => m.id === member.id)) {
      const newSelection = [...selectedTeamMembers, member];
      setSelectedTeamMembers(newSelection);
      // Update form with comma-separated names
      const teamMemberNames = newSelection.map(m => `${m.firstName} ${m.lastName}`).join(", ");
      form.setValue("teamMembers", teamMemberNames);
    }
    setTeamMemberSearch("");
    setShowTeamMemberDropdown(false);
  };

  const removeTeamMember = (memberId: number) => {
    const newSelection = selectedTeamMembers.filter(m => m.id !== memberId);
    setSelectedTeamMembers(newSelection);
    const teamMemberNames = newSelection.map(m => `${m.firstName} ${m.lastName}`).join(", ");
    form.setValue("teamMembers", teamMemberNames);
  };

  // Filter team members based on search
  const filteredTeamMembers = teamMembers?.filter(member => 
    !selectedTeamMembers.find(selected => selected.id === member.id) &&
    (`${member.firstName} ${member.lastName}`.toLowerCase().includes(teamMemberSearch.toLowerCase()) ||
     member.position?.toLowerCase().includes(teamMemberSearch.toLowerCase()))
  ) || [];

  const createMutation = useMutation({
    mutationFn: async (data: OperationFormData) => {
      const res = await fetch("/api/admin/operations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include"
      });
      if (!res.ok) throw new Error("Operasyon oluşturulurken hata oluştu");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/operations"] });
      toast({ title: "Operasyon başarıyla oluşturuldu" });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({ 
        title: "Hata", 
        description: "Operasyon oluşturulurken bir hata oluştu",
        variant: "destructive"
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: OperationFormData }) => {
      const res = await fetch(`/api/admin/operations/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include"
      });
      if (!res.ok) throw new Error("Operasyon güncellenirken hata oluştu");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/operations"] });
      toast({ title: "Operasyon başarıyla güncellendi" });
      setIsDialogOpen(false);
      setEditingOperation(null);
      form.reset();
    },
    onError: () => {
      toast({ 
        title: "Hata", 
        description: "Operasyon güncellenirken bir hata oluştu",
        variant: "destructive"
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/admin/operations/${id}`, {
        method: "DELETE",
        credentials: "include"
      });
      if (!res.ok) throw new Error("Operasyon silinirken hata oluştu");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/operations"] });
      toast({ title: "Operasyon başarıyla silindi" });
      setDeleteOperationId(null);
    },
    onError: () => {
      toast({ 
        title: "Hata", 
        description: "Operasyon silinirken bir hata oluştu",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (data: OperationFormData) => {
    if (editingOperation) {
      updateMutation.mutate({ id: editingOperation.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (operation: Operation) => {
    setEditingOperation(operation);
    
    // Parse existing team members if available
    if (operation.teamMembers && teamMembers) {
      const memberNames = operation.teamMembers.split(", ");
      const existingMembers = teamMembers.filter(member => 
        memberNames.some(name => name === `${member.firstName} ${member.lastName}`)
      );
      setSelectedTeamMembers(existingMembers);
    } else {
      setSelectedTeamMembers([]);
    }
    
    form.reset({
      title: operation.title,
      description: operation.description,
      operationDate: new Date(operation.operationDate).toISOString().split('T')[0],
      location: operation.location,
      status: operation.status,
      teamMembers: operation.teamMembers || "",
      imagePath: operation.imagePath || ""
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    setDeleteOperationId(id);
  };

  const filteredOperations = operations?.filter(operation =>
    operation.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    operation.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
    operation.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ongoing":
        return "bg-yellow-500";
      case "completed":
        return "bg-green-500";
      case "cancelled":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "ongoing":
        return "Devam Ediyor";
      case "completed":
        return "Tamamlandı";
      case "cancelled":
        return "İptal Edildi";
      default:
        return status;
    }
  };

  if (error) {
    return (
      <AdminLayout title="Operasyonlar">
        <div className="flex items-center justify-center min-h-[400px]">
          <Card className="w-full max-w-md">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2 text-destructive">
                <AlertCircle className="h-5 w-5" />
                <p>Operasyonlar yüklenirken bir hata oluştu</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Operasyonlar">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Operasyon Yönetimi</h1>
            <p className="text-muted-foreground">Arama kurtarma operasyonlarını yönetin</p>
          </div>
          <Button
            onClick={() => {
              setEditingOperation(null);
              setSelectedTeamMembers([]);
              setTeamMemberSearch("");
              form.reset();
              setIsDialogOpen(true);
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            Yeni Operasyon
          </Button>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Search className="h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Operasyon ara..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="max-w-sm"
              />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : filteredOperations?.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                Henüz operasyon bulunmuyor
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Başlık</TableHead>
                      <TableHead>Tarih</TableHead>
                      <TableHead>Konum</TableHead>
                      <TableHead>Durum</TableHead>
                      <TableHead>Ekip</TableHead>
                      <TableHead className="text-right">İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredOperations?.map((operation) => (
                      <TableRow key={operation.id}>
                        <TableCell className="font-medium">
                          {operation.title}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1 text-sm">
                            <Calendar className="h-3 w-3" />
                            <span>
                              {format(new Date(operation.operationDate), "d MMMM yyyy", { locale: tr })}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-1 text-sm">
                            <MapPin className="h-3 w-3" />
                            <span>{operation.location}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${getStatusColor(operation.status)} text-white`}>
                            {getStatusText(operation.status)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {operation.teamMembers && (
                            <div className="flex items-center space-x-1 text-sm">
                              <Users className="h-3 w-3" />
                              <span>{operation.teamMembers.split(',').length} kişi</span>
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(operation)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(operation.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingOperation ? "Operasyon Düzenle" : "Yeni Operasyon"}
              </DialogTitle>
              <DialogDescription>
                Operasyon bilgilerini girin
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Başlık *</Label>
                  <Input
                    id="title"
                    {...form.register("title")}
                    placeholder="Operasyon başlığı"
                  />
                  {form.formState.errors.title && (
                    <p className="text-sm text-destructive">
                      {form.formState.errors.title.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="operationDate">Tarih *</Label>
                  <Input
                    id="operationDate"
                    type="date"
                    {...form.register("operationDate")}
                  />
                  {form.formState.errors.operationDate && (
                    <p className="text-sm text-destructive">
                      {form.formState.errors.operationDate.message}
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="location">Konum *</Label>
                  <Input
                    id="location"
                    {...form.register("location")}
                    placeholder="Operasyon konumu"
                  />
                  {form.formState.errors.location && (
                    <p className="text-sm text-destructive">
                      {form.formState.errors.location.message}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="status">Durum *</Label>
                  <Select
                    value={form.watch("status")}
                    onValueChange={(value) => form.setValue("status", value as any)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Durum seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ongoing">Devam Ediyor</SelectItem>
                      <SelectItem value="completed">Tamamlandı</SelectItem>
                      <SelectItem value="cancelled">İptal Edildi</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.status && (
                    <p className="text-sm text-destructive">
                      {form.formState.errors.status.message}
                    </p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Açıklama *</Label>
                <Textarea
                  id="description"
                  {...form.register("description")}
                  placeholder="Operasyon detayları"
                  rows={4}
                />
                {form.formState.errors.description && (
                  <p className="text-sm text-destructive">
                    {form.formState.errors.description.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="teamMembers">Ekip Üyeleri</Label>
                
                {/* Selected Team Members Tags */}
                {selectedTeamMembers.length > 0 && (
                  <div className="flex flex-wrap gap-2 p-2 border rounded-md bg-gray-50">
                    {selectedTeamMembers.map((member) => (
                      <Badge
                        key={member.id}
                        variant="secondary"
                        className="flex items-center gap-1 px-3 py-1"
                      >
                        <span>{member.firstName} {member.lastName}</span>
                        <button
                          type="button"
                          onClick={() => removeTeamMember(member.id)}
                          className="ml-1 hover:text-red-600"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
                
                {/* Team Member Search Input */}
                <div className="relative">
                  <Input
                    placeholder="Ekip üyesi ara ve ekle..."
                    value={teamMemberSearch}
                    onChange={(e) => {
                      setTeamMemberSearch(e.target.value);
                      setShowTeamMemberDropdown(e.target.value.length > 0);
                    }}
                    onFocus={() => setShowTeamMemberDropdown(teamMemberSearch.length > 0)}
                    className="w-full"
                  />
                  
                  {/* Team Member Dropdown */}
                  {showTeamMemberDropdown && filteredTeamMembers.length > 0 && (
                    <div className="absolute top-full left-0 right-0 mt-1 bg-white border rounded-md shadow-lg z-50 max-h-40 overflow-y-auto">
                      {filteredTeamMembers.slice(0, 5).map((member) => (
                        <button
                          key={member.id}
                          type="button"
                          onClick={() => addTeamMember(member)}
                          className="w-full px-3 py-2 text-left hover:bg-gray-100 flex items-center gap-2"
                        >
                          <Users className="h-4 w-4 text-gray-400" />
                          <div>
                            <div className="font-medium">{member.firstName} {member.lastName}</div>
                            {member.position && (
                              <div className="text-sm text-gray-500">{member.position}</div>
                            )}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                
                {/* Hidden input to store the comma-separated names for form submission */}
                <Input
                  type="hidden"
                  {...form.register("teamMembers")}
                />
              </div>

              <div className="space-y-2">
                <Label>Fotoğraf URL'leri</Label>
                <div className="space-y-2">
                  {photoUrls.map((url, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        placeholder="https://example.com/image.jpg"
                        value={url}
                        onChange={(e) => updatePhotoUrl(index, e.target.value)}
                      />
                      {photoUrls.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removePhotoUrl(index)}
                        >
                          <X className="h-4 w-4 text-red-500" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addPhotoUrl}
                    className="w-full bg-red-500 text-white hover:bg-red-600 border-red-500"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Fotoğraf URL'si Ekle
                  </Button>
                </div>
              </div>

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsDialogOpen(false);
                    setEditingOperation(null);
                    form.reset();
                  }}
                >
                  İptal
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                >
                  {createMutation.isPending || updateMutation.isPending
                    ? "Kaydediliyor..."
                    : editingOperation
                    ? "Güncelle"
                    : "Oluştur"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        <AlertDialog
          open={deleteOperationId !== null}
          onOpenChange={(open) => !open && setDeleteOperationId(null)}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Operasyonu Sil</AlertDialogTitle>
              <AlertDialogDescription>
                Bu operasyonu silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>İptal</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => deleteOperationId && deleteMutation.mutate(deleteOperationId)}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Sil
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AdminLayout>
  );
}