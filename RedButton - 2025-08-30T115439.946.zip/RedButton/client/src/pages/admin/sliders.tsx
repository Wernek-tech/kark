import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { MoveUp, MoveDown, MoreHorizontal, Trash2, PlusCircle, X, Pencil, ExternalLink, Eye } from "lucide-react";
import { HeroSlider, InsertHeroSlider } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Helmet } from "react-helmet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Form validation schema
const formSchema = z.object({
  title: z.string().min(3, "Başlık en az 3 karakter olmalıdır"),
  description: z.string().min(3, "Açıklama en az 3 karakter olmalıdır"),
  buttonText: z.string().min(1, "Buton metni gereklidir"),
  buttonLink: z.string().min(1, "Buton linki gereklidir"),
  imageUrl: z.string().url("Geçerli bir URL giriniz"),
  isActive: z.boolean().default(true),
  order: z.number().int().min(0).default(0),
});

export default function AdminSliders() {
  const { toast } = useToast();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedSliderId, setSelectedSliderId] = useState<number | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  
  // Get all sliders
  const { data: sliders = [], isLoading, refetch } = useQuery<HeroSlider[]>({
    queryKey: ["/api/hero-sliders"],
  });
  
  // Get single slider details for editing
  const { data: selectedSlider, isLoading: isLoadingSlider } = useQuery<HeroSlider>({
    queryKey: ["/api/hero-sliders", selectedSliderId],
    enabled: selectedSliderId !== null && isEditDialogOpen,
  });
  
  // Form for create/edit
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      buttonText: "Detaylar",
      buttonLink: "/",
      imageUrl: "",
      isActive: true,
      order: 0,
    },
  });
  
  // Reset form when creating new
  const handleOpenCreateDialog = () => {
    form.reset({
      title: "",
      description: "",
      buttonText: "Detaylar",
      buttonLink: "/",
      imageUrl: "",
      isActive: true,
      order: 0,
    });
    setImagePreview(null);
    setIsCreateDialogOpen(true);
  };
  
  // Fill form with slider data when editing
  const handleOpenEditDialog = (sliderId: number) => {
    setSelectedSliderId(sliderId);
    setIsEditDialogOpen(true);
    
    // Find the slider in the already loaded data (without waiting for the query)
    const sliderToEdit = sliders.find(s => s.id === sliderId);
    if (sliderToEdit) {
      form.reset({
        title: sliderToEdit.title,
        description: sliderToEdit.description || "",
        buttonText: sliderToEdit.buttonText || "Detaylar", 
        buttonLink: sliderToEdit.buttonLink || "/",
        imageUrl: sliderToEdit.imageUrl,
        isActive: sliderToEdit.isActive,
        order: sliderToEdit.order,
      });
      setImagePreview(sliderToEdit.imageUrl);
    }
  };
  
  // Handle delete
  const handleOpenDeleteDialog = (sliderId: number) => {
    setSelectedSliderId(sliderId);
    setIsDeleteDialogOpen(true);
  };
  
  // Handle image URL change
  const handleImageUrlChange = (url: string) => {
    setImagePreview(url);
  };
  
  // Create slider mutation
  const createSliderMutation = useMutation({
    mutationFn: async (data: InsertHeroSlider) => {
      const res = await apiRequest("POST", "/api/hero-sliders", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Slider eklendi",
        description: "Yeni slider başarıyla eklendi.",
      });
      setIsCreateDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/hero-sliders"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Slider eklenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Update slider mutation
  const updateSliderMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: InsertHeroSlider }) => {
      const res = await apiRequest("PUT", `/api/hero-sliders/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Slider güncellendi",
        description: "Slider başarıyla güncellendi.",
      });
      setIsEditDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/hero-sliders"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Slider güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Delete slider mutation
  const deleteSliderMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/hero-sliders/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Slider silindi",
        description: "Slider başarıyla silindi.",
      });
      setIsDeleteDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/hero-sliders"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Slider silinirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Update order mutations
  const updateOrderMutation = useMutation({
    mutationFn: async ({ id, newOrder }: { id: number, newOrder: number }) => {
      await apiRequest("PUT", `/api/hero-sliders/${id}/order`, { order: newOrder });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/hero-sliders"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: error.message || "Sıralama güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });
  
  // Move slider up or down
  const handleMoveSlider = (sliderId: number, currentOrder: number, direction: "up" | "down") => {
    const newOrder = direction === "up" ? currentOrder - 1 : currentOrder + 1;
    updateOrderMutation.mutate({ id: sliderId, newOrder });
  };
  
  // Create slider handler
  const onCreateSubmit = (values: z.infer<typeof formSchema>) => {
    createSliderMutation.mutate(values);
  };
  
  // Update slider handler
  const onUpdateSubmit = (values: z.infer<typeof formSchema>) => {
    if (selectedSliderId) {
      updateSliderMutation.mutate({ id: selectedSliderId, data: values });
    }
  };
  
  // Delete slider handler
  const onDeleteConfirm = () => {
    if (selectedSliderId) {
      deleteSliderMutation.mutate(selectedSliderId);
    }
  };
  
  return (
    <>
      <Helmet>
        <title>Slider Yönetimi - Admin Panel</title>
      </Helmet>
      
      <AdminLayout title="Slider Yönetimi">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold">Ana Sayfa Slider Ayarları</h2>
              <p className="text-muted-foreground mt-1">
                Ana sayfadaki slider bölümünde görüntülenecek içerikleri yönetin
              </p>
            </div>
            <Button onClick={handleOpenCreateDialog}>
              <PlusCircle className="h-4 w-4 mr-2" />
              Yeni Slider Ekle
            </Button>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Slider Listesi</CardTitle>
              <CardDescription>
                Sliderlar görüntülenme sırasına göre listelenmektedir. Sıralamayı değiştirmek için okları kullanabilirsiniz.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">Yükleniyor...</div>
              ) : sliders.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  Henüz eklenmiş slider bulunmamaktadır. "Yeni Slider Ekle" butonunu kullanarak slider ekleyebilirsiniz.
                </div>
              ) : (
                <Table>
                  <TableCaption>Toplam {sliders.length} slider</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-16 text-center">Sıra</TableHead>
                      <TableHead className="w-14 text-center">Durum</TableHead>
                      <TableHead className="w-24">Resim</TableHead>
                      <TableHead>Başlık</TableHead>
                      <TableHead>Buton</TableHead>
                      <TableHead className="text-right">İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sliders.map((slider) => (
                      <TableRow key={slider.id}>
                        <TableCell className="text-center">
                          <div className="flex flex-col items-center">
                            <span className="font-mono text-lg font-bold mb-1">{slider.order}</span>
                            <div className="flex gap-1">
                              <Button
                                variant="outline" 
                                size="sm"
                                className="h-7 w-7 p-0"
                                onClick={() => handleMoveSlider(slider.id, slider.order, "up")}
                                disabled={slider.order === 1}
                              >
                                <MoveUp className="h-3 w-3" />
                              </Button>
                              <Button
                                variant="outline" 
                                size="sm"
                                className="h-7 w-7 p-0"
                                onClick={() => handleMoveSlider(slider.id, slider.order, "down")}
                                disabled={slider.order === sliders.length}
                              >
                                <MoveDown className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-center">
                          <div className="flex justify-center">
                            <div className={`h-3 w-3 rounded-full ${slider.isActive ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="relative h-12 w-20 rounded overflow-hidden">
                            <img
                              src={slider.imageUrl}
                              alt={slider.title}
                              className="h-full w-full object-cover"
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{slider.title}</div>
                          {slider.description && (
                            <div className="text-xs text-muted-foreground line-clamp-1">
                              {slider.description}
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            {slider.buttonText || "Detaylar"}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {slider.buttonLink || "/"}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                              <DropdownMenuLabel>İşlemler</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => handleOpenEditDialog(slider.id)}>
                                <Pencil className="h-4 w-4 mr-2" />
                                Düzenle
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleOpenDeleteDialog(slider.id)} className="text-red-600">
                                <Trash2 className="h-4 w-4 mr-2" />
                                Sil
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Yeni Slider Oluşturma Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Yeni Slider Oluştur</DialogTitle>
              <DialogDescription>
                Ana sayfada gösterilecek yeni bir slider ekleyin. Tüm alanları eksiksiz doldurun.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onCreateSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Başlık</FormLabel>
                          <FormControl>
                            <Input placeholder="Slider başlığı" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Açıklama</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Slider açıklaması"
                              rows={3}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="buttonText"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Buton Metni</FormLabel>
                            <FormControl>
                              <Input placeholder="Detaylar" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="buttonLink"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Buton Linki</FormLabel>
                            <FormControl>
                              <Input placeholder="/sayfa-linki" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="isActive"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Aktif</FormLabel>
                            <FormDescription>
                              Slider ana sayfada gösterilsin mi?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="imageUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Görsel URL</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="https://example.com/image.jpg" 
                              {...field} 
                              onChange={(e) => {
                                field.onChange(e);
                                handleImageUrlChange(e.target.value);
                              }}
                            />
                          </FormControl>
                          <FormDescription>
                            Yüksek çözünürlüklü, 1920x1080 veya benzer boyutlarda görsel kullanın
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="mt-2">
                      <div className="text-sm font-medium mb-2">Görsel Önizleme</div>
                      {imagePreview ? (
                        <div className="relative w-full aspect-[16/9] bg-gray-100 rounded-md overflow-hidden">
                          <img
                            src={imagePreview}
                            alt="Önizleme"
                            className="h-full w-full object-cover"
                            onError={() => setImagePreview(null)}
                          />
                        </div>
                      ) : (
                        <div className="w-full aspect-[16/9] bg-gray-100 rounded-md flex items-center justify-center">
                          <p className="text-gray-400 text-sm">Görsel URL girildiğinde önizleme burada görünecek</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    İptal
                  </Button>
                  <Button type="submit" disabled={createSliderMutation.isPending}>
                    {createSliderMutation.isPending ? "Ekleniyor..." : "Slider Ekle"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
        
        {/* Slider Düzenleme Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Slider Düzenle</DialogTitle>
              <DialogDescription>
                Slider bilgilerini güncelleyin.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onUpdateSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Başlık</FormLabel>
                          <FormControl>
                            <Input placeholder="Slider başlığı" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Açıklama</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Slider açıklaması"
                              rows={3}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="buttonText"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Buton Metni</FormLabel>
                            <FormControl>
                              <Input placeholder="Detaylar" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="buttonLink"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Buton Linki</FormLabel>
                            <FormControl>
                              <Input placeholder="/sayfa-linki" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="isActive"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Aktif</FormLabel>
                            <FormDescription>
                              Slider ana sayfada gösterilsin mi?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="imageUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Görsel URL</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="https://example.com/image.jpg" 
                              {...field} 
                              onChange={(e) => {
                                field.onChange(e);
                                handleImageUrlChange(e.target.value);
                              }}
                            />
                          </FormControl>
                          <FormDescription>
                            Yüksek çözünürlüklü, 1920x1080 veya benzer boyutlarda görsel kullanın
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="mt-2">
                      <div className="text-sm font-medium mb-2">Görsel Önizleme</div>
                      {imagePreview ? (
                        <div className="relative w-full aspect-[16/9] bg-gray-100 rounded-md overflow-hidden">
                          <img
                            src={imagePreview}
                            alt="Önizleme"
                            className="h-full w-full object-cover"
                            onError={() => setImagePreview(null)}
                          />
                        </div>
                      ) : (
                        <div className="w-full aspect-[16/9] bg-gray-100 rounded-md flex items-center justify-center">
                          <p className="text-gray-400 text-sm">Görsel URL girildiğinde önizleme burada görünecek</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                    İptal
                  </Button>
                  <Button type="submit" disabled={updateSliderMutation.isPending}>
                    {updateSliderMutation.isPending ? "Güncelleniyor..." : "Kaydet"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
        
        {/* Slider Silme Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Slider'ı Sil</DialogTitle>
              <DialogDescription>
                Bu slider'ı silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
              </DialogDescription>
            </DialogHeader>
            
            <div className="pt-4 pb-6">
              <p className="text-destructive font-medium">
                Bu işlem geri alınamaz ve slider kalıcı olarak silinecektir.
              </p>
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsDeleteDialogOpen(false)}
              >
                İptal
              </Button>
              <Button 
                type="button" 
                variant="destructive" 
                onClick={onDeleteConfirm}
                disabled={deleteSliderMutation.isPending}
              >
                {deleteSliderMutation.isPending ? "Siliniyor..." : "Sil"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </AdminLayout>
    </>
  );
}