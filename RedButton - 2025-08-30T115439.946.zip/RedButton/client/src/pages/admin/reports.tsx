import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Edit, Trash2, Plus, Calendar, FileText, Lock, AlertCircle } from "lucide-react";
import type { Report } from "@shared/schema";

const reportSchema = z.object({
  title: z.string().min(3, "Başlık en az 3 karakter olmalıdır"),
  content: z.string().min(10, "İçerik en az 10 karakter olmalıdır"),
  reportDate: z.string(),
  reportType: z.string().min(2, "Rapor tipi en az 2 karakter olmalıdır"),
  accessLevel: z.enum(["public", "members", "admin"])
});

type ReportFormData = z.infer<typeof reportSchema>;

export default function AdminReports() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingReport, setEditingReport] = useState<Report | null>(null);
  const [deleteReportId, setDeleteReportId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [accessFilter, setAccessFilter] = useState<string>("all");

  const { data: reports, isLoading, error } = useQuery({
    queryKey: ["/api/admin/reports"],
    queryFn: async () => {
      const res = await fetch("/api/admin/reports", {
        credentials: "include"
      });
      if (!res.ok) throw new Error("Raporlar yüklenirken hata oluştu");
      return res.json() as Promise<Report[]>;
    }
  });

  const form = useForm<ReportFormData>({
    resolver: zodResolver(reportSchema),
    defaultValues: {
      title: "",
      content: "",
      reportDate: new Date().toISOString().split('T')[0],
      reportType: "",
      accessLevel: "public"
    }
  });

  const createReportMutation = useMutation({
    mutationFn: async (data: ReportFormData) => {
      const res = await fetch("/api/admin/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error("Rapor oluşturulamadı");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Başarılı", description: "Rapor başarıyla oluşturuldu" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/reports"] });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({ title: "Hata", description: "Rapor oluşturulurken hata oluştu", variant: "destructive" });
    }
  });

  const updateReportMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: ReportFormData }) => {
      const res = await fetch(`/api/admin/reports/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error("Rapor güncellenemedi");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Başarılı", description: "Rapor başarıyla güncellendi" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/reports"] });
      setIsDialogOpen(false);
      setEditingReport(null);
      form.reset();
    },
    onError: () => {
      toast({ title: "Hata", description: "Rapor güncellenirken hata oluştu", variant: "destructive" });
    }
  });

  const deleteReportMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/admin/reports/${id}`, {
        method: "DELETE",
        credentials: "include"
      });
      if (!res.ok) throw new Error("Rapor silinemedi");
    },
    onSuccess: () => {
      toast({ title: "Başarılı", description: "Rapor başarıyla silindi" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/reports"] });
      setDeleteReportId(null);
    },
    onError: () => {
      toast({ title: "Hata", description: "Rapor silinirken hata oluştu", variant: "destructive" });
    }
  });

  const handleSubmit = (data: ReportFormData) => {
    if (editingReport) {
      updateReportMutation.mutate({ id: editingReport.id, data });
    } else {
      createReportMutation.mutate(data);
    }
  };

  const handleEdit = (report: Report) => {
    setEditingReport(report);
    form.reset({
      title: report.title,
      content: report.content,
      reportDate: format(new Date(report.reportDate), "yyyy-MM-dd"),
      reportType: report.reportType,
      accessLevel: report.accessLevel
    });
    setIsDialogOpen(true);
  };

  const filteredReports = reports?.filter(report => {
    const matchesSearch = report.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         report.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === "all" || report.reportType === typeFilter;
    const matchesAccess = accessFilter === "all" || report.accessLevel === accessFilter;
    return matchesSearch && matchesType && matchesAccess;
  }) || [];

  const reportTypes = [...new Set(reports?.map(report => report.reportType) || [])];

  const getAccessLevelBadge = (level: string) => {
    switch(level) {
      case "public":
        return <Badge variant="default">Herkese Açık</Badge>;
      case "members":
        return <Badge variant="secondary">Üyelere Özel</Badge>;
      case "admin":
        return (
          <Badge variant="destructive">
            <Lock className="h-3 w-3 mr-1" />
            Yöneticilere Özel
          </Badge>
        );
      default:
        return <Badge variant="outline">{level}</Badge>;
    }
  };

  if (error) {
    return (
      <AdminLayout title="Raporlar">
        <div className="flex items-center justify-center min-h-[400px]">
          <Card className="w-full max-w-md">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2 text-destructive">
                <AlertCircle className="h-5 w-5" />
                <p>Raporlar yüklenirken bir hata oluştu</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title="Raporlar">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Rapor Yönetimi</h1>
            <p className="text-muted-foreground">Faaliyet raporlarını yönetin</p>
          </div>
          <Button
            onClick={() => {
              setEditingReport(null);
              form.reset();
              setIsDialogOpen(true);
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            Yeni Rapor
          </Button>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Rapor ara..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Rapor tipi" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tüm Tipler</SelectItem>
                  {reportTypes.map(type => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={accessFilter} onValueChange={setAccessFilter}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Erişim seviyesi" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tüm Seviyeler</SelectItem>
                  <SelectItem value="public">Herkese Açık</SelectItem>
                  <SelectItem value="members">Üyelere Özel</SelectItem>
                  <SelectItem value="admin">Yöneticilere Özel</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : filteredReports.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">Henüz rapor bulunmuyor</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Başlık</TableHead>
                    <TableHead>Rapor Tipi</TableHead>
                    <TableHead>Tarih</TableHead>
                    <TableHead>Erişim</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReports.map((report) => (
                    <TableRow key={report.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          {report.title}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{report.reportType}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          {format(new Date(report.reportDate), "dd MMMM yyyy", { locale: tr })}
                        </div>
                      </TableCell>
                      <TableCell>
                        {getAccessLevelBadge(report.accessLevel)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(report)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setDeleteReportId(report.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingReport ? "Rapor Düzenle" : "Yeni Rapor Oluştur"}
              </DialogTitle>
              <DialogDescription>
                {editingReport ? "Rapor bilgilerini güncelleyin." : "Yeni bir faaliyet raporu oluşturun."}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Başlık</Label>
                <Input
                  id="title"
                  {...form.register("title")}
                  placeholder="Rapor başlığı"
                />
                {form.formState.errors.title && (
                  <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="content">İçerik</Label>
                <Textarea
                  id="content"
                  {...form.register("content")}
                  placeholder="Rapor içeriği"
                  rows={8}
                />
                {form.formState.errors.content && (
                  <p className="text-sm text-destructive">{form.formState.errors.content.message}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="reportType">Rapor Tipi</Label>
                  <Input
                    id="reportType"
                    {...form.register("reportType")}
                    placeholder="Örn: Aylık Faaliyet, Yıllık Rapor"
                  />
                  {form.formState.errors.reportType && (
                    <p className="text-sm text-destructive">{form.formState.errors.reportType.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reportDate">Rapor Tarihi</Label>
                  <Input
                    id="reportDate"
                    type="date"
                    {...form.register("reportDate")}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="accessLevel">Erişim Seviyesi</Label>
                <Select
                  value={form.watch("accessLevel")}
                  onValueChange={(value: "public" | "members" | "admin") => form.setValue("accessLevel", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Erişim seviyesi seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="public">Herkese Açık</SelectItem>
                    <SelectItem value="members">Üyelere Özel</SelectItem>
                    <SelectItem value="admin">Yöneticilere Özel</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  İptal
                </Button>
                <Button type="submit" disabled={createReportMutation.isPending || updateReportMutation.isPending}>
                  {editingReport ? "Güncelle" : "Oluştur"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        <AlertDialog open={!!deleteReportId} onOpenChange={() => setDeleteReportId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Raporu Sil</AlertDialogTitle>
              <AlertDialogDescription>
                Bu raporu silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>İptal</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => deleteReportId && deleteReportMutation.mutate(deleteReportId)}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Sil
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AdminLayout>
  );
}