import { Helmet } from "react-helmet-async";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Setting } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface TimelineItem {
  id: number;
  year: number;
  title: string;
  description: string;
  itemType: string;
  isActive: boolean;
  sortOrder: number;
}

export default function AboutPage() {
  const [timelineItems, setTimelineItems] = useState<TimelineItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [aboutContent, setAboutContent] = useState<any>(null);
  const { toast } = useToast();
  
  const { data: settings } = useQuery<Setting[]>({
    queryKey: ["/api/settings"],
  });

  // Helper function to get setting value
  const getSettingValue = (key: string, fallback: string = ""): string => {
    const setting = settings?.find(s => s.key === key);
    return setting?.value || fallback;
  };
  
  // Parse about content from settings
  useEffect(() => {
    if (settings) {
      const aboutSetting = settings.find(s => s.key === "about.content");
      if (aboutSetting && aboutSetting.value) {
        try {
          const parsedContent = JSON.parse(aboutSetting.value);
          setAboutContent(parsedContent);
        } catch (error) {
          console.error('Error parsing about content:', error);
        }
      }
    }
  }, [settings]);

  useEffect(() => {
    const fetchTimelineItems = async () => {
      try {
        const response = await fetch('/api/timeline');
        if (response.ok) {
          const data = await response.json();
          setTimelineItems(data.sort((a: TimelineItem, b: TimelineItem) => a.year - b.year));
        }
      } catch (error) {
        console.error('Error fetching timeline items:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTimelineItems();
  }, []);
  return (
    <>
      <Helmet>
        <title>Hakkımızda | KARK Arama Kurtarma</title>
        <meta name="description" content="KARK Arama Kurtarma Derneği hakkında bilgi edinin. Misyonumuz, vizyonumuz ve değerlerimizi öğrenin." />
      </Helmet>
      
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <div className="flex justify-center">
              <h1 className="section-title">{aboutContent?.mainContent?.title || "Hakkımızda"}</h1>
            </div>
            <p className="section-description">{aboutContent?.mainContent?.subtitle || "KARK Arama Kurtarma Derneği'nin hikayesi ve misyonu"}</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div>
              <div className="aspect-w-16 aspect-h-9 mb-8 overflow-hidden rounded-lg shadow-lg">
                <img 
                  src="https://images.unsplash.com/photo-1624894510591-41806b95a599?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                  alt="KARK Arama Kurtarma Ekibi" 
                  className="object-cover w-full h-full"
                />
              </div>
              
              <div className="aspect-w-16 aspect-h-9 overflow-hidden rounded-lg shadow-lg">
                <img 
                  src="https://images.unsplash.com/photo-1610498605110-8320436cbf6f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
                  alt="Arama Kurtarma Operasyonu" 
                  className="object-cover w-full h-full"
                />
              </div>
            </div>
            
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold mb-4 dark:text-white">{aboutContent?.mainContent?.whoWeAre || getSettingValue("about.who_we_are_title", "Biz Kimiz?")}</h2>
                <p className="text-primary dark:text-gray-300 mb-4">
                  {aboutContent?.mainContent?.whoWeAreDetails || getSettingValue("about.who_we_are_details", "")}
                </p>
                <p className="text-primary dark:text-gray-300">
                  {aboutContent?.mainContent?.whoWeAreExtra || getSettingValue("about.who_we_are_extra", "")}
                </p>
              </div>
              
              <div>
                <h2 className="text-2xl font-bold mb-4 dark:text-white">{aboutContent?.mainContent?.missionTitle || getSettingValue("about.mission_title", "Misyonumuz")}</h2>
                <p className="text-primary dark:text-gray-300">
                  {aboutContent?.mainContent?.mission || getSettingValue("about.mission_text", "")}
                </p>
              </div>
              
              <div>
                <h2 className="text-2xl font-bold mb-4 dark:text-white">{aboutContent?.mainContent?.visionTitle || getSettingValue("about.vision_title", "Vizyonumuz")}</h2>
                <p className="text-primary dark:text-gray-300">
                  {aboutContent?.mainContent?.vision || getSettingValue("about.vision_text", "")}
                </p>
              </div>
            </div>
          </div>
          
          <div className="mb-16">
            <h2 className="text-2xl font-bold mb-6 text-center dark:text-white">{aboutContent?.valuesTitle || getSettingValue("about.values_title", "Değerlerimiz")}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {aboutContent?.values?.map((value: any, index: number) => (
                <div key={index} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow dark:shadow-blue-900/20">
                  {value.icon && (
                    <div className="text-secondary text-3xl mb-4 flex justify-center" dangerouslySetInnerHTML={{ __html: value.icon }} />
                  )}
                  <h3 className="text-xl font-semibold mb-2 text-center dark:text-white">{value.title}</h3>
                  <p className="text-primary dark:text-gray-300 text-center">
                    {value.description}
                  </p>
                </div>
              )) || (
                <>
                  <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow dark:shadow-blue-900/20">
                    <div className="text-secondary text-3xl mb-4 flex justify-center" dangerouslySetInnerHTML={{ __html: getSettingValue("about.value1_icon", '') }} />
                    <h3 className="text-xl font-semibold mb-2 text-center dark:text-white">{getSettingValue("about.value1_title", "")}</h3>
                    <p className="text-primary dark:text-gray-300 text-center">
                      {getSettingValue("about.value1_description", "")}
                    </p>
                  </div>
                  
                  <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow dark:shadow-blue-900/20">
                    <div className="text-secondary text-3xl mb-4 flex justify-center" dangerouslySetInnerHTML={{ __html: getSettingValue("about.value2_icon", '') }} />
                    <h3 className="text-xl font-semibold mb-2 text-center dark:text-white">{getSettingValue("about.value2_title", "")}</h3>
                    <p className="text-primary dark:text-gray-300 text-center">
                      {getSettingValue("about.value2_description", "")}
                    </p>
                  </div>
                  
                  <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow dark:shadow-blue-900/20">
                    <div className="text-secondary text-3xl mb-4 flex justify-center" dangerouslySetInnerHTML={{ __html: getSettingValue("about.value3_icon", '') }} />
                    <h3 className="text-xl font-semibold mb-2 text-center dark:text-white">{getSettingValue("about.value3_title", "")}</h3>
                    <p className="text-primary dark:text-gray-300 text-center">
                      {getSettingValue("about.value3_description", "")}
                    </p>
                  </div>
                </>
              )}
            </div>
          </div>
          
          <div className="mb-16">
            <h2 className="text-2xl font-bold mb-8 text-center dark:text-white">{aboutContent?.timelineTitle || getSettingValue("about.timeline_title", "Tarihçemiz")}</h2>
            {loading ? (
              <div className="text-center py-8">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-secondary"></div>
                <p className="mt-2 text-primary dark:text-gray-300">Tarihçe yükleniyor...</p>
              </div>
            ) : timelineItems.length > 0 ? (
              <div className="relative border-l-4 border-secondary pl-8 ml-4 pb-8">
                {timelineItems.map((item, index) => (
                  <div key={item.id} className={`${index < timelineItems.length - 1 ? 'mb-10' : ''} relative`}>
                    <div className="absolute -left-[41px] top-0 bg-secondary rounded-full w-6 h-6 border-4 border-white dark:border-gray-900"></div>
                    <h3 className="text-xl font-bold mb-2 dark:text-white">
                      {item.year} - {item.title}
                    </h3>
                    <p className="text-primary dark:text-gray-300">
                      {item.description}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-primary dark:text-gray-300">Henüz tarihçe bilgisi bulunmamaktadır.</p>
              </div>
            )}
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-800 p-8 rounded-lg shadow-md mb-16 dark:shadow-blue-900/20">
            <h2 className="text-2xl font-bold mb-6 text-center dark:text-white">{aboutContent?.footerContent?.joinUsTitle || getSettingValue("about.join_us_title", "Bize Katılın")}</h2>
            <p className="text-primary dark:text-gray-300 text-center mb-8">
              {aboutContent?.footerContent?.joinUsDescription || getSettingValue("about.join_us_description", "")}
            </p>
            <div className="flex justify-center">
              <button 
                onClick={() => {
                  const url = aboutContent?.footerContent?.applicationFormUrl || aboutContent?.footerContent?.joinUsButtonLink || "/contact";
                  window.open(url, '_blank');
                  // Show success message after a short delay
                  setTimeout(() => {
                    toast({
                      title: "Başarılı!",
                      description: "Başvurunuz başarıyla alınmıştır. En kısa sürede sizinle iletişime geçeceğiz.",
                    });
                  }, 2000);
                }}
                className="bg-secondary hover:bg-blue-700 text-white font-bold py-3 px-8 rounded transition-colors duration-300"
              >
                {aboutContent?.footerContent?.joinUsButtonText || getSettingValue("about.join_us_button_text", "Gönüllü Olmak İçin Başvurun")}
              </button>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </>
  );
}