import { useState } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Link } from "wouter";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import PhotoViewer from "@/components/modals/PhotoViewer";
import ImageWithFallback from "@/components/ImageWithFallback";
import { Album, MediaItem } from "@shared/schema";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";

export default function PhotoAlbumDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [photoIndex, setPhotoIndex] = useState(0);
  const [isPhotoViewerOpen, setIsPhotoViewerOpen] = useState(false);

  const { data: album, isLoading: isLoadingAlbum } = useQuery<Album>({
    queryKey: [`/api/albums/${id}`],
  });

  const { data: photos, isLoading: isLoadingPhotos } = useQuery<MediaItem[]>({
    queryKey: [`/api/albums/${id}/photos`],
  });

  const handlePhotoClick = (index: number) => {
    setPhotoIndex(index);
    setIsPhotoViewerOpen(true);
  };

  const handleClosePhotoViewer = () => {
    setIsPhotoViewerOpen(false);
  };

  const getPhotosForViewer = () => {
    if (!photos) return [];
    
    return photos.map((photo) => ({
      id: photo.id,
      filePath: photo.filePath,
      title: photo.title
    }));
  };

  const isLoading = isLoadingAlbum || isLoadingPhotos;

  if (isLoading) {
    return (
      <>
        <Navbar />
        <main className="content-container">
          <div className="flex justify-center py-12">
            <Loader2 className="h-12 w-12 animate-spin text-secondary" />
          </div>
        </main>
        <Footer />
      </>
    );
  }

  if (!album) {
    return (
      <>
        <Navbar />
        <main className="content-container">
          <div className="container mx-auto px-4 text-center py-12">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Albüm Bulunamadı
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mb-8">
              Aradığınız albüm mevcut değil veya kaldırılmış.
            </p>
            <Link href="/photos">
              <Button>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Geri Dön
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>{album.title} | Fotoğraf Galerisi</title>
        <meta name="description" content={album.description || `${album.title} fotoğraf albümü`} />
      </Helmet>
      
      <Navbar />
      
      <main className="content-container">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-8">
            <Link href="/photos">
              <Button variant="outline" className="mb-4">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Fotoğraf Galerisine Dön
              </Button>
            </Link>
            
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              {album.title}
            </h1>
            
            {album.description && (
              <p className="text-lg text-gray-600 dark:text-gray-400 mb-4">
                {album.description}
              </p>
            )}
            
            <div className="text-sm text-gray-500 dark:text-gray-400">
              {photos?.length || 0} fotoğraf
            </div>
          </div>
          
          {/* Photo Grid */}
          {photos && photos.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {photos.map((photo, index) => (
                <div 
                  key={photo.id} 
                  className="cursor-pointer group"
                  onClick={() => handlePhotoClick(index)}
                >
                  <div className="relative overflow-hidden rounded-lg shadow-md group-hover:shadow-lg transition-shadow">
                    <ImageWithFallback 
                      src={photo.filePath} 
                      alt={photo.title} 
                      className="w-full h-64 object-cover gallery-item group-hover:scale-105 transition-transform duration-300"
                      fallbackClassName="w-full h-64"
                    />
                    
                    {/* Overlay with photo title */}
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-opacity flex items-end p-4">
                      <span className="text-white font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                        {photo.title}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500 dark:text-gray-400">
                Bu albümde henüz fotoğraf bulunmuyor.
              </p>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
      
      <PhotoViewer 
        isOpen={isPhotoViewerOpen} 
        photos={getPhotosForViewer()} 
        initialIndex={photoIndex} 
        onClose={handleClosePhotoViewer} 
      />
    </>
  );
}