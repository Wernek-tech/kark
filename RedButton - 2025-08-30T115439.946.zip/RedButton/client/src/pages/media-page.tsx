import { useState } from "react";
import { Link } from "wouter";
import { Play, Image, Grid, List } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Helmet } from "react-helmet-async";

export default function MediaPage() {
  const [view, setView] = useState<"grid" | "list">("grid");

  return (
    <>
      <Helmet>
        <title>Medya - KARK</title>
        <meta name="description" content="Kuzey Kıbrıs Arama Kurtarma Derneği fotoğraf ve video galerisi" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <main className="container mx-auto px-4 py-24">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">Medya</h1>
            <p className="text-muted-foreground">
              Fotoğraf ve video galerimiz
            </p>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-between items-center mb-6">
              <TabsList>
                <TabsTrigger value="all">Tümü</TabsTrigger>
                <TabsTrigger value="photos">Fotoğraflar</TabsTrigger>
                <TabsTrigger value="videos">Videolar</TabsTrigger>
              </TabsList>
              
              <div className="flex gap-2">
                <Button
                  variant={view === "grid" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setView("grid")}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={view === "list" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setView("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <TabsContent value="all" className="space-y-8">
              <div>
                <h2 className="text-2xl font-semibold mb-4">Son Eklenenler</h2>
                <div className={view === "grid" ? "grid gap-6 md:grid-cols-2 lg:grid-cols-3" : "space-y-4"}>
                  <Link href="/photos">
                    <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="p-3 bg-primary/10 rounded-lg">
                            <Image className="w-6 h-6 text-primary" />
                          </div>
                          <span className="text-sm text-muted-foreground">Fotoğraf Albümleri</span>
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Fotoğraf Galerisi</h3>
                        <p className="text-muted-foreground">
                          Etkinlik ve operasyonlarımızdan fotoğraflar
                        </p>
                      </CardContent>
                    </Card>
                  </Link>

                  <Link href="/videos">
                    <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="p-3 bg-primary/10 rounded-lg">
                            <Play className="w-6 h-6 text-primary" />
                          </div>
                          <span className="text-sm text-muted-foreground">Video Koleksiyonu</span>
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Video Galerisi</h3>
                        <p className="text-muted-foreground">
                          Eğitim videoları ve etkinlik kayıtları
                        </p>
                      </CardContent>
                    </Card>
                  </Link>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="photos">
              <div className="text-center py-12">
                <Image className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground mb-4">
                  Fotoğraf albümlerimizi görmek için tıklayın
                </p>
                <Link href="/photos">
                  <Button>Fotoğraf Albümlerini Görüntüle</Button>
                </Link>
              </div>
            </TabsContent>

            <TabsContent value="videos">
              <div className="text-center py-12">
                <Play className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground mb-4">
                  Video koleksiyonumuzu görmek için tıklayın
                </p>
                <Link href="/videos">
                  <Button>Videoları Görüntüle</Button>
                </Link>
              </div>
            </TabsContent>
          </Tabs>
        </main>

        <Footer />
      </div>
    </>
  );
}