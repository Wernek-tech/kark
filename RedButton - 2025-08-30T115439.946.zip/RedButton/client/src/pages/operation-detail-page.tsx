import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet-async";
import { motion } from "framer-motion";
import { Calendar, MapPin, Users, Clock, ArrowLeft } from "lucide-react";
import { format } from "date-fns";
import { tr } from "date-fns/locale";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

interface Operation {
  id: number;
  title: string;
  description: string;
  operationDate: string;
  location?: string;
  status: 'completed' | 'ongoing';
  type?: string;
  image_url?: string;
  content?: string;
  duration?: string;
  team_size?: number;
  rescued_count?: number;
  area_covered?: string;
}

export default function OperationDetailPage() {
  const { id } = useParams();

  const { data: operation, isLoading, error } = useQuery<Operation>({
    queryKey: [`/api/operations/${id}`],
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen pt-24 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
        <Footer />
      </>
    );
  }

  if (error || !operation) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen pt-24 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Operasyon bulunamadı</h2>
            <Link href="/operations">
              <Button>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Operasyonlara Dön
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>{operation.title} - KARK</title>
        <meta name="description" content={operation.description} />
      </Helmet>

      <Navbar />

      <main className="min-h-screen pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Back Button */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <Link href="/operations">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Operasyonlara Dön
              </Button>
            </Link>
          </motion.div>

          {/* Operation Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-12"
          >
            <div className="flex items-start justify-between flex-wrap gap-4 mb-6">
              <div>
                <h1 className="text-4xl font-bold mb-4">{operation.title}</h1>
                <div className="flex flex-wrap gap-4 text-muted-foreground">
                  {operation.operationDate && (
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      <span>{format(new Date(operation.operationDate), "d MMMM yyyy", { locale: tr })}</span>
                    </div>
                  )}
                  {operation.duration && (
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      <span>{operation.duration}</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex gap-2">
                <Badge variant={operation.status === 'completed' ? 'default' : 'secondary'}>
                  {operation.status === 'completed' ? 'Tamamlandı' : 'Devam Ediyor'}
                </Badge>
                <Badge variant="outline">{operation.type || 'Arama Kurtarma'}</Badge>
              </div>
            </div>
          </motion.div>

          {/* Main Content */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Left Column - Main Content */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="lg:col-span-2"
            >
              {/* Cover Image */}
              {operation.image_url && (
                <Card className="mb-8 overflow-hidden">
                  <img
                    src={operation.image_url}
                    alt={operation.title}
                    className="w-full h-[400px] object-cover"
                  />
                </Card>
              )}

              {/* Description */}
              <Card className="mb-8">
                <CardContent className="pt-6">
                  <h2 className="text-2xl font-bold mb-4">Operasyon Detayları</h2>
                  <div className="prose prose-lg dark:prose-invert max-w-none">
                    <p className="whitespace-pre-wrap">{operation.description}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Additional Content */}
              {operation.content && (
                <Card>
                  <CardContent className="pt-6">
                    <div className="prose prose-lg dark:prose-invert max-w-none">
                      <div dangerouslySetInnerHTML={{ __html: operation.content }} />
                    </div>
                  </CardContent>
                </Card>
              )}
            </motion.div>

            {/* Right Column - Details */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              {/* Operation Info */}
              <Card className="mb-6">
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-4">Operasyon Bilgileri</h3>
                  <div className="space-y-4">
                    {operation.location && (
                      <div className="flex items-start gap-3">
                        <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
                        <div>
                          <p className="text-sm text-muted-foreground">Konum</p>
                          <p className="font-medium">{operation.location}</p>
                        </div>
                      </div>
                    )}
                    {operation.team_size && (
                      <div className="flex items-start gap-3">
                        <Users className="h-5 w-5 text-muted-foreground mt-0.5" />
                        <div>
                          <p className="text-sm text-muted-foreground">Ekip Büyüklüğü</p>
                          <p className="font-medium">{operation.team_size} Kişi</p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Statistics */}
              {(operation.rescued_count || operation.area_covered) && (
                <Card>
                  <CardContent className="pt-6">
                    <h3 className="font-semibold mb-4">İstatistikler</h3>
                    <div className="space-y-4">
                      {operation.rescued_count && (
                        <div>
                          <p className="text-sm text-muted-foreground">Kurtarılan Kişi</p>
                          <p className="text-2xl font-bold text-primary">{operation.rescued_count}</p>
                        </div>
                      )}
                      {operation.area_covered && (
                        <div>
                          <p className="text-sm text-muted-foreground">Taranan Alan</p>
                          <p className="text-2xl font-bold">{operation.area_covered}</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </motion.div>
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
}