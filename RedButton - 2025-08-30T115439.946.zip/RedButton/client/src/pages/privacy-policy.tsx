import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Card } from "@/components/ui/card";
import { Shield, Eye, Lock, Users, Database, Mail, Globe, FileText } from "lucide-react";

export function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8 mt-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center">Gizlilik Politikası</h1>
          
          <Card className="p-6 md:p-8 mb-8">
            <div className="flex items-center gap-3 mb-6">
              <Shield className="h-8 w-8 text-primary" />
              <h2 className="text-2xl font-semibold">Şeffaflık İlkemiz</h2>
            </div>
            <p className="text-muted-foreground mb-4">
              Kuzey Kıbrıs Arama Kurtarma (KARK) olarak, gönüllülerimizin, destekçilerimizin ve web sitemizi 
              ziyaret eden herkesin gizliliğine saygı duyuyor ve koruyoruz. Bu politika, bir sivil toplum 
              kuruluşu olarak şeffaflık ilkemiz doğrultusunda hazırlanmıştır.
            </p>
          </Card>

          <div className="grid gap-6">
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <Eye className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-semibold">Hangi Bilgileri Topluyoruz?</h3>
              </div>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <div>
                    <strong>İletişim Bilgileri:</strong> Bize ulaştığınızda paylaştığınız ad, e-posta ve telefon bilgileri
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <div>
                    <strong>Gönüllü Başvuruları:</strong> Gönüllü olmak için doldurduğunuz formlardaki bilgiler
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <div>
                    <strong>Bağış Bilgileri:</strong> Bağış yaparken ilettiğiniz kimlik ve iletişim bilgileri
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <div>
                    <strong>Web Sitesi Kullanımı:</strong> Ziyaret istatistikleri (anonim olarak)
                  </div>
                </li>
              </ul>
            </Card>

            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <Lock className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-semibold">Bilgileri Nasıl Kullanıyoruz?</h3>
              </div>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Arama kurtarma faaliyetlerimizi organize etmek için
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Gönüllülerimizle iletişim kurmak ve eğitimler düzenlemek için
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Acil durumlarda hızlı müdahale ekipleri oluşturmak için
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Etkinlik ve eğitimlerimiz hakkında bilgilendirme yapmak için
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Yasal yükümlülüklerimizi yerine getirmek için
                </li>
              </ul>
            </Card>

            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <Users className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-semibold">Bilgileri Kimlerle Paylaşıyoruz?</h3>
              </div>
              <div className="space-y-3 text-muted-foreground">
                <p>KARK olarak, kişisel bilgilerinizi <strong>asla</strong> ticari amaçlarla paylaşmayız veya satmayız.</p>
                <p>Bilgileriniz yalnızca şu durumlarda paylaşılabilir:</p>
                <ul className="space-y-2 mt-2">
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    Resmi makamların yasal talepleri doğrultusunda
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    Arama kurtarma operasyonları sırasında can güvenliği için gerekli olduğunda
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    Sizin açık izninizle
                  </li>
                </ul>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <Database className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-semibold">Veri Güvenliği</h3>
              </div>
              <p className="text-muted-foreground mb-3">
                Kişisel bilgilerinizi korumak için şu önlemleri alıyoruz:
              </p>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Tüm hassas bilgiler şifreli olarak saklanır
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Yalnızca yetkili gönüllüler bilgilere erişebilir
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Düzenli güvenlik güncellemeleri yapılır
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Gönüllülerimize veri gizliliği eğitimi verilir
                </li>
              </ul>
            </Card>

            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <Globe className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-semibold">Çerezler ve İzleme</h3>
              </div>
              <p className="text-muted-foreground mb-3">
                Web sitemizde yalnızca temel işlevsellik için gerekli çerezler kullanılır:
              </p>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Oturum yönetimi için güvenlik çerezleri
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Anonim ziyaretçi istatistikleri
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Üçüncü taraf takip kodları kullanmıyoruz
                </li>
              </ul>
            </Card>

            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <FileText className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-semibold">Haklarınız</h3>
              </div>
              <p className="text-muted-foreground mb-3">
                Kişisel bilgilerinizle ilgili şu haklara sahipsiniz:
              </p>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Hangi bilgilerinizi sakladığımızı öğrenme hakkı
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Bilgilerinizin düzeltilmesini isteme hakkı
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  Bilgilerinizin silinmesini talep etme hakkı
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  E-posta listesinden çıkma hakkı
                </li>
              </ul>
            </Card>

            <Card className="p-6 bg-primary/5">
              <div className="flex items-center gap-3 mb-4">
                <Mail className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-semibold">İletişim</h3>
              </div>
              <p className="text-muted-foreground mb-3">
                Gizlilik politikamız hakkında sorularınız veya kişisel bilgilerinizle ilgili talepleriniz için 
                bizimle iletişime geçebilirsiniz:
              </p>
              <div className="space-y-2 text-muted-foreground">
                <p><strong>E-posta:</strong> info@kibrisaramakurtarma.org</p>
                <p><strong>Telefon:</strong> +90 533 123 45 67</p>
                <p><strong>Adres:</strong> Lefkoşa, KKTC</p>
              </div>
            </Card>

            <Card className="p-6 border-primary/20">
              <p className="text-sm text-muted-foreground text-center">
                Bu gizlilik politikası en son <strong>5 Temmuz 2025</strong> tarihinde güncellenmiştir.
                <br />
                Politikamızda yapılan değişiklikler bu sayfada yayınlanacaktır.
              </p>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}