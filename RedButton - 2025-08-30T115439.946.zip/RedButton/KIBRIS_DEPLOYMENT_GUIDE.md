# KARK Website Deployment Guide for kibrisaramakurtarma.org

## Server Information
- **Domain:** kibrisaramakurtarma.org, www.kibrisaramakurtarma.org
- **Server IP:** 193.31.31.171
- **Application Port:** 5000 (internal)
- **Public Ports:** 80 (HTTP), 443 (HTTPS)

## DNS Configuration (Complete First)

Before starting deployment, ensure your domain DNS is configured:

```
A Record: kibrisaramakurtarma.org → 193.31.31.171
A Record: www.kibrisaramakurtarma.org → 193.31.31.171
```

Wait for DNS propagation (can take up to 24 hours).

## Step 1: Server Setup

Connect to your VPS server:
```bash
ssh root@193.31.31.171
```

Update system and install required software:
```bash
# Update system
apt update && apt upgrade -y

# Install nginx
apt install nginx -y

# Install Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs

# Install PM2 for process management
npm install -g pm2

# Install git (if needed for deployment)
apt install git -y
```

## Step 2: Deploy KARK Website

Create directory and upload your files:
```bash
# Create application directory
mkdir -p /var/www/kark
cd /var/www/kark

# Upload your KARK website files here
# Option 1: Use scp from your local machine
# scp -r /path/to/your/kark/* root@193.31.31.171:/var/www/kark/

# Option 2: Use git clone (if you have a repository)
# git clone https://github.com/your-username/kark-website.git .

# If your files are in a nested directory (like karksite/RedButtonSimulator/), move them:
# Example: mv karksite/RedButtonSimulator/* . && rm -rf karksite/

# For your current setup with nested folders:
cd /var/www/kark/karksite/RedButtonSimulator
cp -r * /var/www/kark/
cd /var/www/kark
rm -rf karksite/

# Install dependencies
npm install

# Build for production
npm run build
```

## Step 3: Configure NGINX

Copy and configure nginx:
```bash
# Copy nginx configuration
cp /var/www/kark/nginx.conf /etc/nginx/sites-available/kibrisaramakurtarma

# Enable the site
ln -s /etc/nginx/sites-available/kibrisaramakurtarma /etc/nginx/sites-enabled/

# Remove default nginx site
rm /etc/nginx/sites-enabled/default

# Test nginx configuration
nginx -t

# If test passes, restart nginx
systemctl restart nginx
systemctl enable nginx
```

## Step 4: Set up SSL Certificate

Install and configure Let's Encrypt:
```bash
# Install certbot
apt install certbot python3-certbot-nginx -y

# Get SSL certificate for your domain
certbot --nginx -d kibrisaramakurtarma.org -d www.kibrisaramakurtarma.org

# Follow the prompts and select redirect option
```

## Step 5: Start KARK Application

Configure and start with PM2:
```bash
cd /var/www/kark

# Start application with PM2
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Set PM2 to start on server boot
pm2 startup systemd
# Follow the command output instructions

# Check if application is running
pm2 status
```

## Step 6: Configure Firewall

```bash
# Configure UFW firewall
ufw allow ssh
ufw allow 'Nginx Full'
ufw enable

# Check firewall status
ufw status
```

## Step 7: Verify Deployment

Test your website:
```bash
# Test HTTP redirect
curl -I http://kibrisaramakurtarma.org

# Test HTTPS
curl -I https://kibrisaramakurtarma.org

# Check application logs
pm2 logs kark-website

# Check nginx logs
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

## File Permissions and Security

```bash
# Set correct ownership
chown -R www-data:www-data /var/www/kark

# Set secure permissions
chmod -R 755 /var/www/kark
chmod -R 644 /var/www/kark/data/*.json

# Secure nginx configuration
chown root:root /etc/nginx/sites-available/kibrisaramakurtarma
chmod 644 /etc/nginx/sites-available/kibrisaramakurtarma
```

## Monitoring and Maintenance

```bash
# Check application status
pm2 status
pm2 monit

# Restart application if needed
pm2 restart kark-website

# Update SSL certificate (auto-renewal)
certbot renew --dry-run

# Check nginx status
systemctl status nginx

# Reload nginx configuration
nginx -s reload
```

## Troubleshooting

### Domain not resolving:
```bash
# Check DNS propagation
nslookup kibrisaramakurtarma.org
dig kibrisaramakurtarma.org
```

### Application not starting:
```bash
# Check PM2 logs
pm2 logs kark-website

# Manual test
cd /var/www/kark
npm start
```

### SSL certificate issues:
```bash
# Check certificate status
certbot certificates

# Renew manually if needed
certbot renew
```

### Port conflicts:
```bash
# Check what's using port 5000
netstat -tulpn | grep :5000
ss -tlpn | grep :5000
```

## Final URLs

After successful deployment:
- **Main site:** https://kibrisaramakurtarma.org
- **WWW redirect:** https://www.kibrisaramakurtarma.org
- **Admin panel:** https://kibrisaramakurtarma.org/admin

Your KARK website will be live and accessible worldwide!